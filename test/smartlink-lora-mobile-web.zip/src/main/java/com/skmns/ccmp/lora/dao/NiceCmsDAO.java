package com.skmns.ccmp.lora.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.lora.model.DeliveryPlace;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.model.NiceCmsCar;
import com.skmns.ccmp.lora.model.Site;

@Repository
public class NiceCmsDAO {
	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = NiceCmsDAO.class.getPackage().getName() + ".";
	
	public List<Map<String, Object>> usp_nicecms_FundCenterList() throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_FundCenterList");
	}

	public List<Map<String, Object>> usp_nicecms_CashTransportTeamList(long fundCenterId) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_CashTransportTeamList", fundCenterId);
	}
	
	public Map<String, Object> usp_nicecms_CashTransportTeam(long cashTransportTeamId) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_CashTransportTeam", cashTransportTeamId);
	}

	public List<Map<String, Object>> usp_nicecms_CarList(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_CarList", param);
	}

	public List<Map<String, Object>> usp_nicecms_SiteList(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_SiteList", param);
	}
	
	public Map<String, Object> usp_nicecms_DeliveryPlanCar(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryPlanCar", param);
	}

	public Map<String, Object> usp_nicecms_DeliveryPlanAdd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryPlanAdd", param);
	}
	
	public int usp_nicecms_DeliveryPlanSiteAdd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryPlanSiteAdd", param);
	}
	
	public List<Map<String, Object>> usp_nicecms_DeliveryPlanPlaceList(long deliveryPlanId) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_DeliveryPlanPlaceList", deliveryPlanId);
	}
	
	public int usp_nicecms_DeliveryPlanTmapAdd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryPlanTmapAdd", param);
	}
	
	public int usp_nicecms_DeliveryPlanTmapCoordAdd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryPlanTmapCoordAdd", param);
	}
	
	public int usp_nicecms_DeliveryPlanUpd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryPlanUpd", param);
	}
	
	public int usp_nicecms_DeliveryPlanSiteUpd(long deliveryPlanId) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryPlanSiteUpd", deliveryPlanId);
	}
	
	public List<Map<String, Object>> usp_nicecms_DeliveryPlanList(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_DeliveryPlanList", param);
	}
	
	public List<Map<String, Object>> usp_nicecms_DeliveryPlanSiteList(long deliveryPlanId) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_DeliveryPlanSiteList", deliveryPlanId);
	}
	
	public List<Map<String, Object>> usp_nicecms_DeliveryPlanDel(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_DeliveryPlanDel", param);
	}
	
	public List<Map<String, Object>> usp_nicecms_DeliveryList(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_DeliveryList", param);
	}
	
	public List<Map<String, Object>> usp_nicecms_DeliveryResult(String deliveryDate) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_DeliveryResult", deliveryDate);
	}
	
	public int usp_nicecms_DeliveryResultUpd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryResultUpd", param);
	}

	public int usp_nicecms_DeliveryTmapAdd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryTmapAdd", param);
	}
	
	public int usp_nicecms_DeliveryTmapCoordAdd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryTmapCoordAdd", param);
	}

	public Map<String, Object> usp_nicecms_DeliveryTmapUpd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_DeliveryTmapUpd", param);
	}
	
	public Map<String, Object> usp_nicecms_TmapOption(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_TmapOption", param);
	}
	
	public int usp_nicecms_TmapOptionAdd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_TmapOptionAdd", param);
	}
	
	public int usp_nicecms_TmapOptionUpd(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_TmapOptionUpd", param);
	}
	
	public Member usp_nicecms_Login(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_Login", param);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * 추가작업 시작
	 */
	public List<Map<String, Object>> usp_nicecms_ManageCarlist(Map<String, Object> param) throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_ManageCarlist", param);
	}

	public List<Map<String, Object>> usp_nicecms_CarModellist(Map<String, Object> param)  throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_CarModellist", param);
	}

	public String usp_nicecms_ManageCarSave(NiceCmsCar niceCmsCar)  throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageCarSave", niceCmsCar);
	}

	public String usp_nicecms_ManageCarUpdate(NiceCmsCar niceCmsCar) throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageCarUpdate", niceCmsCar);
	}

	
	
	
	public List<Map<String, Object>> usp_nicecms_ManageSiteList(Map<String, Object> param)  throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_ManageSiteList", param);
	}

	public List<Map<String, Object>> usp_nicecms_ManageDeliveryplaceList(Map<String, Object> param)  throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_ManageDeliveryplaceList", param);
	}

	public List<Map<String, Object>> usp_nicecms_ManageDlvPlaceCycleList(Map<String, Object> param)  throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_ManageDlvPlaceCycleList", param);
	}	

	public void usp_nicecms_ManageLoraLogGpsUpdate(Map<String, Object> param)  throws Throwable {
		this.sqlSession.selectList(NS + "usp_nicecms_ManageLoraLogGpsUpdate", param);
	}
	
	public String usp_nicecms_ManageSiteSave(Site site)  throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageSiteSave", site);
	}

	public void usp_nicecms_ManageSiteXlsSave()  throws Throwable {
		this.sqlSession.selectList(NS + "usp_nicecms_ManageSiteXlsSave");
	}	
	
	public String usp_nicecms_ManageSiteUpdate(Site site)  throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageSiteUpdate", site);
	}

	public String usp_nicecms_ManageSiteDlvPlaceUpdate(Map<String, Object> param)  throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageSiteDlvPlaceUpdate", param);
	}

	public void usp_nicecms_ManageSiteDlvPlaceUpdateClear(Map<String, Object> param)  throws Throwable {
		this.sqlSession.selectList(NS + "usp_nicecms_ManageSiteDlvPlaceUpdateClear", param);
	}

	public String usp_nicecms_ManageDlvPlaceSave(DeliveryPlace deliveryPlace)  throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageDlvPlaceSave", deliveryPlace);
	}

	public String usp_nicecms_ManageDlvPlaceUpdate(DeliveryPlace deliveryPlace)  throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageDlvPlaceUpdate", deliveryPlace);
	}

	public String usp_nicecms_ManageDlvPlaceDelete(Map<String, Object> param)  throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageDlvPlaceDelete", param);
	}

	public void usp_nicecms_ManageSiteDelete(Map<String, Object> param)  throws Throwable {
		this.sqlSession.selectList(NS + "usp_nicecms_ManageSiteDelete", param);
	}

	public String usp_nicecms_ManageSiteOrderUpdate(Map<String, Object> param)  throws Throwable {
		return this.sqlSession.selectOne(NS + "usp_nicecms_ManageSiteOrderUpdate", param);
	}

	public List<Map<String, Object>> usp_nicecms_poiList(String carid)  throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_poiList", carid);
	}

	public List<Map<String, Object>> usp_nicecms_poiList2(String carid)  throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_poiList2", carid);
	}

	public List<Map<String, Object>> usp_nicecms_ManageDeliveryPlanPlaceList(String planid)  throws Throwable {
		return this.sqlSession.selectList(NS + "usp_nicecms_ManageDeliveryPlanPlaceList", planid);
	}
	/**
	 * 추가작업 종료
	 */
	
}

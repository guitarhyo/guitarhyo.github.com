package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

import com.skmns.ccmp.lora.model.api.ResDriveInfo;

@Alias(value = "DriveInfo")
public class DriveInfo extends ResDriveInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2838713703036500104L;
	
	private String onGpsDt; // 시동 ON Gps 일시
	private String offGpsDt; // 시동 OFF Gps 일시
	private float onLat; // 시동 ON시 위도
	private float onLon; // 시동 ON시 경도
	private float offLat; // 시동 OFF시 위도
	private float offLon; // 시동 OFF시 경도
	private int corpId; // 고객사 ID
	private String devEui; // Lora DEV EUI
	private int devId; 
	private int drvrId; // 운전자(회원) ID
	private int drvSts = -1; // 주행 상태(1: 주행 중, 0: 주행 완료)
	private int usgTyp; // 운행 용도 (1: 업무용, 2: 출퇴근용, 3: 개인용)
	private int carId;//차아이디
	
	private String insDt;
	private String updDt;
	
	private String searchDt; //검색 일시
	private String stDt; //검색 일시
	private String edDt; //검색 일시

	
	
	public String getStDt() {
		return stDt;
	}

	public void setStDt(String stDt) {
		this.stDt = stDt;
	}

	public String getEdDt() {
		return edDt;
	}

	public void setEdDt(String edDt) {
		this.edDt = edDt;
	}

	public String getOnGpsDt() {
		return onGpsDt;
	}

	public void setOnGpsDt(String onGpsDt) {
		this.onGpsDt = onGpsDt;
	}

	public String getOffGpsDt() {
		return offGpsDt;
	}

	public void setOffGpsDt(String offGpsDt) {
		this.offGpsDt = offGpsDt;
	}

	public float getOnLat() {
		return onLat;
	}

	public void setOnLat(float onLat) {
		this.onLat = onLat;
	}

	public float getOnLon() {
		return onLon;
	}

	public void setOnLon(float onLon) {
		this.onLon = onLon;
	}

	public float getOffLat() {
		return offLat;
	}

	public void setOffLat(float offLat) {
		this.offLat = offLat;
	}

	public float getOffLon() {
		return offLon;
	}

	public void setOffLon(float offLon) {
		this.offLon = offLon;
	}

	public int getCorpId() {
		return corpId;
	}

	public void setCorpId(int corpId) {
		this.corpId = corpId;
	}

	public String getDevEui() {
		return devEui;
	}

	public void setDevEui(String devEui) {
		this.devEui = devEui;
	}

	public int getDevId() {
		return devId;
	}

	public void setDevId(int devId) {
		this.devId = devId;
	}

	public int getDrvrId() {
		return drvrId;
	}

	public void setDrvrId(int drvrId) {
		this.drvrId = drvrId;
	}

	public int getDrvSts() {
		return drvSts;
	}

	public void setDrvSts(int drvSts) {
		this.drvSts = drvSts;
	}

	public int getUsgTyp() {
		return usgTyp;
	}

	public void setUsgTyp(int usgTyp) {
		this.usgTyp = usgTyp;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getInsDt() {
		return insDt;
	}

	public void setInsDt(String insDt) {
		this.insDt = insDt;
	}

	public String getUpdDt() {
		return updDt;
	}

	public void setUpdDt(String updDt) {
		this.updDt = updDt;
	}

	public String getSearchDt() {
		return searchDt;
	}

	public void setSearchDt(String searchDt) {
		this.searchDt = searchDt;
	}

	
}

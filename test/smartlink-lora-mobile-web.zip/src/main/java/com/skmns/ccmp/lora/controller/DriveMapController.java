package com.skmns.ccmp.lora.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.model.DriveMap;
import com.skmns.ccmp.lora.service.DriveMapService;

@Controller
public class DriveMapController {
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private MessageSourceAccessor msa;

	@Autowired
	private DriveMapService driveMapService;

	/**
	 * 메인
	 *
	 * @return
	 */
	@RequestMapping("/web/driveMap/locationLink")
	public String locationLink(final HttpServletRequest request,final DriveMap driveMap) {
		return "/web/driveMap/locationLink";
	}
	
	
	@RequestMapping("/web/driveMap/location")
	public String location(final HttpServletRequest request,final DriveMap driveMap) {
		ObjectMapper mapper = new ObjectMapper();

		DriveMap ret	=	this.driveMapService.selectAuthKeyCheck(driveMap);
		
		if(100 == ret.getCode()){
			try {
				driveMap.setCoId(ret.getCoId());
				if(driveMap.getSearchDt() != null && !"".equals(driveMap.getSearchDt())){
					driveMap.setStartDt(driveMap.getSearchDt());
					driveMap.setEndDt(driveMap.getSearchDt());
					request.setAttribute("searchDt", driveMap.getSearchDt());
				}
				driveMap.setCarNumber(URLDecoder.decode(driveMap.getCarNumber(), "UTF-8") );
			} catch (UnsupportedEncodingException e1) {
				request.setAttribute("errorMsg","서버 오류");
				return "/web/driveMap/error";
			}
			String strJsonList = "";
			List<DriveMap> list =  this.driveMapService.selectDriveMapList(driveMap);
			try {
				strJsonList = 	mapper.writeValueAsString(list);
			ArrayNode jsonList =	mapper.readValue(strJsonList, ArrayNode.class); 
			request.setAttribute("driveMapList", jsonList);
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("driveMapList", null);
			}
			

			return "/web/driveMap/location";
		}else{
			request.setAttribute("errorMsg", ret.getMessage());
			return "/web/driveMap/error";
		}
		
	
	}

	@RequestMapping("/web/driveMap/gps")
	@ResponseBody
	public List<DriveMap> gps(final HttpServletRequest request,final DriveMap driveMap) {

		List<DriveMap> list =  this.driveMapService.selectDriveGpsList(driveMap);

		return list;
	}
	
}

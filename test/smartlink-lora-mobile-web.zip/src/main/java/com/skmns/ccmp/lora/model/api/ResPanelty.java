package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResPanelty")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResPanelty implements Serializable {
	


	/**
	 * 
	 */
	private static final long serialVersionUID = 1716468703654737531L;
	private BigDecimal drvId;
	private Integer drvrId;
	private Integer carId;
	private String carNum;
	private Integer penalty;
	private String evtDt;
	private String comment;
	
	
	
	
	public BigDecimal getDrvId() {
		return drvId;
	}
	public void setDrvId(BigDecimal drvId) {
		this.drvId = drvId;
	}
	public Integer getDrvrId() {
		return drvrId;
	}
	public void setDrvrId(Integer drvrId) {
		this.drvrId = drvrId;
	}
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public Integer getPenalty() {
		return penalty;
	}
	public void setPenalty(Integer penalty) {
		this.penalty = penalty;
	}
	public String getEvtDt() {
		return evtDt;
	}
	public void setEvtDt(String evtDt) {
		this.evtDt = evtDt;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	
	
	
}
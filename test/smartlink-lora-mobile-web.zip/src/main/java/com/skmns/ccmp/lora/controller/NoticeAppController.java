package com.skmns.ccmp.lora.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.model.Notice;
import com.skmns.ccmp.lora.model.Paging;
import com.skmns.ccmp.lora.service.NoticeService;

@Controller
@RequestMapping("/app/cs")
public class NoticeAppController {
	private static final Logger logger = LoggerFactory.getLogger(NoticeAppController.class);
	private String jspPath = "/app/cs";

	@Autowired
	private NoticeService noticeService;

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private SessionManager sessionManager;

	@RequestMapping({ "/notice", "/notice/list" })
	public String noticeList(@RequestParam(required = false) final String searchNoticeId) throws Exception {
		logger.debug("notice page start");

		this.request.setAttribute("searchNoticeId", searchNoticeId);

		return this.jspPath + "/notice";
	}

	@RequestMapping("/notice/search")
	@ResponseBody
	public List<Notice> searchNoticeList(final Paging paging) throws CommonResponseException {
		Map<String, Object> map = new HashMap<>();

		Notice notice = new Notice();

		if (this.sessionManager.isLogin(this.request)) {
			notice.setCorpId(this.sessionManager.getMember(this.request).getCorpId());
		} else {
			notice.setCorpId("0");
		}
		notice.setDevice("MOBILE");
		notice.setIsMainOpen("0");
		map.put("Notice", notice);
		map.put("Paging", paging);

		List<Notice> result = this.noticeService.selectNoticeList(map);
		for (int i = 0; i < result.size(); i++) {
			result.get(i).setSubject(result.get(i).getSubject().replace("\n", "<br/>"));
			result.get(i).setNotice(result.get(i).getNotice().replace("\n", "<br/>"));
		}
		logger.debug("data : {}", result);

		return result;
	}
}

package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "Site")
public class Site implements Serializable {

	/**
	 * 2018.10.24 jgc add
	 */
	private static final long serialVersionUID = -1147603409427607114L;
	
	private int siteId = 0;
	private String siteOrder = "1";
	private String siteCode = "";
	private String siteName = "";
	private String siteAddress = "";
	private String siteLat = "";
	private String siteLon = "";
	private String siteDesc = "";
	private int cashTransportTeamId = 0;
	private int deliveryPlaceId = 0;
	private String pCd = "";
	private String timeLimit;
	private String avgWorkTime = "5";
	private int workMon = 0;
	private int workTue = 0;
	private int workWed = 0;
	private int workThu = 0;
	private int workFri = 0;
	private int workSat = 0;
	private int workSun = 0;
	private int workHoliday = 0;
	private String corpName = "";
	private String uId = "";
	private String teamCode = ""; //엑셀업로드시 필요
	private String teamName = ""; //엑셀업로드시 필요
	private String machineNo = "-";
	private int isCreateDeliveryPlace = 0;
	private String deliveryPlaceAuto = "";
	
	public int getSiteId() {
		return siteId;
	}
	public void setSiteId(int siteId) {
		this.siteId = siteId;
	}
	public String getSiteOrder() {
		return siteOrder;
	}
	public void setSiteOrder(String siteOrder) {
		this.siteOrder = siteOrder;
	}
	public String getSiteCode() {
		return siteCode;
	}
	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getSiteAddress() {
		return siteAddress;
	}
	public void setSiteAddress(String siteAddress) {
		this.siteAddress = siteAddress;
	}
	public String getSiteLat() {
		return siteLat;
	}
	public void setSiteLat(String siteLat) {
		this.siteLat = siteLat;
	}
	public String getSiteLon() {
		return siteLon;
	}
	public void setSiteLon(String siteLon) {
		this.siteLon = siteLon;
	}
	public String getSiteDesc() {
		return siteDesc;
	}
	public void setSiteDesc(String siteDesc) {
		this.siteDesc = siteDesc;
	}
	public int getCashTransportTeamId() {
		return cashTransportTeamId;
	}
	public void setCashTransportTeamId(int cashTransportTeamId) {
		this.cashTransportTeamId = cashTransportTeamId;
	}
	public int getDeliveryPlaceId() {
		return deliveryPlaceId;
	}
	public void setDeliveryPlaceId(int deliveryPlaceId) {
		this.deliveryPlaceId = deliveryPlaceId;
	}
	public String getpCd() {
		return pCd;
	}
	public void setpCd(String pCd) {
		this.pCd = pCd;
	}
	public String getTimeLimit() {
		return timeLimit;
	}
	public void setTimeLimit(String timeLimit) {
		this.timeLimit = timeLimit;
	}
	public String getAvgWorkTime() {
		return avgWorkTime;
	}
	public void setAvgWorkTime(String avgWorkTime) {
		this.avgWorkTime = avgWorkTime;
	}
	public int getWorkMon() {
		return workMon;
	}
	public void setWorkMon(int workMon) {
		this.workMon = workMon;
	}
	public int getWorkTue() {
		return workTue;
	}
	public void setWorkTue(int workTue) {
		this.workTue = workTue;
	}
	public int getWorkWed() {
		return workWed;
	}
	public void setWorkWed(int workWed) {
		this.workWed = workWed;
	}
	public int getWorkThu() {
		return workThu;
	}
	public void setWorkThu(int workThu) {
		this.workThu = workThu;
	}
	public int getWorkFri() {
		return workFri;
	}
	public void setWorkFri(int workFri) {
		this.workFri = workFri;
	}
	public int getWorkSat() {
		return workSat;
	}
	public void setWorkSat(int workSat) {
		this.workSat = workSat;
	}
	public int getWorkSun() {
		return workSun;
	}
	public void setWorkSun(int workSun) {
		this.workSun = workSun;
	}
	public int getWorkHoliday() {
		return workHoliday;
	}
	public void setWorkHoliday(int workHoliday) {
		this.workHoliday = workHoliday;
	}
	public String getCorpName() {
		return corpName;
	}
	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
	public String getTeamCode() {
		return teamCode;
	}
	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getMachineNo() {
		return machineNo;
	}
	public void setMachineNo(String machineNo) {
		this.machineNo = machineNo;
	}
	public int getIsCreateDeliveryPlace() {
		return isCreateDeliveryPlace;
	}
	public void setIsCreateDeliveryPlace(int isCreateDeliveryPlace) {
		this.isCreateDeliveryPlace = isCreateDeliveryPlace;
	}
	public String getDeliveryPlaceAuto() {
		return deliveryPlaceAuto;
	}
	public void setDeliveryPlaceAuto(String deliveryPlaceAuto) {
		this.deliveryPlaceAuto = deliveryPlaceAuto;
	}
}

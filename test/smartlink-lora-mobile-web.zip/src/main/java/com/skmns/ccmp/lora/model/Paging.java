package com.skmns.ccmp.lora.model;

import org.apache.ibatis.type.Alias;

@Alias(value = "Paging")
public class Paging {

	/** 현재 페이지 */
	private int pageNum = 1;

	/** 화면에 보여질 데이터 수 */
	private int pageRows = 10;

	public int getPageNum() {
		return this.pageNum;
	}

	public void setPageNum(final int pageNum) {
		this.pageNum = pageNum;
	}

	public int getPageRows() {
		return this.pageRows;
	}

	public void setPageRows(final int pageRows) {
		this.pageRows = pageRows;
	}

}
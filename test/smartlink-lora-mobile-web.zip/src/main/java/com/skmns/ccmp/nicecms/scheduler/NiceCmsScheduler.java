package com.skmns.ccmp.nicecms.scheduler;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.skmns.ccmp.common.TmapApiManager;
import com.skmns.ccmp.lora.dao.NiceCmsDAO;

@Component
public class NiceCmsScheduler {
	@Autowired
	private NiceCmsDAO dao;
	
	@Autowired
	private TmapApiManager tmapApi;
	
	@Autowired
	private MessageSourceAccessor msa;

	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	private String getTmapDate(String deliveryDate) {
		String repDate = deliveryDate.replace("-", "");
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date delivery = sdf.parse(repDate);
			Date now = new Date();
			
			if ( !delivery.after(now) ) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(now);
				
				int nowWeek = cal.get(Calendar.DAY_OF_WEEK);
				
				cal.setTime(delivery);
				
				int deliveryWeek = cal.get(Calendar.DAY_OF_WEEK);
				
				int diffDay = deliveryWeek - nowWeek;
				
				if ( diffDay <= 0 ) {
					diffDay += 7;
				}
				
				delivery.setTime(now.getTime() + diffDay * 86400000);
				
				repDate = sdf.format(delivery);
			}
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
		
		return repDate;
	}

	@Scheduled(cron="* * * * * *")
	public void tick() {
		String schedule = msa.getMessage("nicecms.delivery.result.schedule");
		logger.trace("schedule = {}", schedule);
		
		if ( schedule == null || !schedule.equals("true") ) return;
		
		String fix = msa.getMessage("nicecms.delivery.result.schedule.fix");
		logger.trace("fix = {}", fix);
		
		if ( fix != null && fix.equals("true") ) {
			String fixTime = msa.getMessage("nicecms.delivery.result.schedule.fix.time");
			logger.trace("fixTime = {}", fixTime);
		}

		String deliveryFix = msa.getMessage("nicecms.delivery.result.schedule.delivery.fix");
		logger.trace("deliveryFix = {}", deliveryFix);
		
		if ( deliveryFix != null && deliveryFix.equals("true") ) {
			String deliveryDate = msa.getMessage("nicecms.delivery.result.schedule.delivery.date");
			logger.trace("deliveryDate = {}", deliveryDate);
		}
	}
	
	@Scheduled(cron="* * * * * *")
	public void deliveryResult() {
		//String searchOption = "2";

		List<Map<String, Object>> list =  null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String now = sdf.format( new Date( new Date().getTime() ) );
		String yesterday = sdf.format( new Date( new Date().getTime() - 86400 * 1000 ) ).substring(0, 10);
		
		try {
			String schedule = msa.getMessage("nicecms.delivery.result.schedule");
			
			if ( schedule == null || !schedule.equals("true") ) return;
			
			String fix = msa.getMessage("nicecms.delivery.result.schedule.fix");
			
			if ( fix != null && fix.equals("true") ) {
				String fixTime = msa.getMessage("nicecms.delivery.result.schedule.fix.time");
				
				if ( fixTime == null || fixTime.length() != 8 || !fixTime.equals( now.substring(11) ) ) {
					return;
				}
			} else if ( !now.substring(11).equals("00:10:00") ) {
				return;
			}

			String deliveryFix = msa.getMessage("nicecms.delivery.result.schedule.delivery.fix");
			
			if ( deliveryFix != null && deliveryFix.equals("true") ) {
				String date = msa.getMessage("nicecms.delivery.result.schedule.delivery.date");
				
				if ( date != null ) {
					logger.info("deliveryResult : {}", date);
					
					list = dao.usp_nicecms_DeliveryResult(date);
				} else {
					logger.info("deliveryResult : {}", yesterday);
					
					list = dao.usp_nicecms_DeliveryResult(yesterday);
				}
			} else {
				logger.info("deliveryResult : {}", yesterday);
				
				list = dao.usp_nicecms_DeliveryResult(yesterday);
			}
			
			long preDeliveryId = 0;
			ArrayNode viaPoints = null;
			ObjectNode req = null;
			int workTime = 0;
			String departureDt = null;
			String prevLat = "";
			String prevLon = "";
			int pointCount = 0;
			int totalDistance = 0;
			int totalTime = 0;
			int featuresIndex = 0;
			
			for ( Map<String, Object> map : list ) {
				long deliveryId = (long) map.get("DELIVERY_ID");
				double complianceRatio = (double) map.get("COMPLIANCE_RATIO");
				
				if ( complianceRatio == 1 ) continue;
				
				if ( preDeliveryId != deliveryId ) {
					if ( req != null ) {
						routeSequential(preDeliveryId, req, workTime, totalDistance, totalTime, featuresIndex, true);
					}
					
					departureDt = map.get("DEPARTURE_DT").toString().replace("-", "").replace(":", "").replace(" ", "");
					viaPoints = new ArrayNode(JsonNodeFactory.instance);
					
Map<String, Object> param = new HashMap<>();
param.put("DELIVERY_PLAN_ID", (long) map.get("DELIVERY_PLAN_ID"));

Map<String, Object> option = dao.usp_nicecms_TmapOption(param);
int searchOption = (int) option.get("searchOptionResult");
					
					req = (ObjectNode) new ObjectNode(JsonNodeFactory.instance)
							.put("startName", "Departure")
							.put("startX", map.get("startLon").toString())
							.put("startY", map.get("startLat").toString())
							.put("startTime", getTmapDate(departureDt.substring(0, 8)) + departureDt.substring(8, 12))
							.put("endName", "Arrive")
							.put("endX", map.get("finishLon").toString())
							.put("endY", map.get("finishLat").toString())
							.put("searchOption", searchOption)
							.set("viaPoints", viaPoints)
							;
					
					preDeliveryId = deliveryId;
					workTime = 0;
					totalDistance = 0;
					totalTime = 0;
					pointCount = 0;
					featuresIndex = 0;
				}
				
				++pointCount;
				
				if ( pointCount == 31 ) {
					req.put("endX", map.get("LON").toString())
						.put("endY", map.get("LAT").toString())
						;
					
					Map<String, Object> retMap = routeSequential(preDeliveryId, req, workTime, totalDistance, totalTime, featuresIndex, false);
					
					totalDistance = (int) retMap.get("totalDistance");
					totalTime = (int) retMap.get("totalTime");
					featuresIndex = (int) retMap.get("featuresIndex");
					
					viaPoints = new ArrayNode(JsonNodeFactory.instance);
					
Map<String, Object> param = new HashMap<>();
param.put("DELIVERY_PLAN_ID", (long) map.get("DELIVERY_PLAN_ID"));

Map<String, Object> option = dao.usp_nicecms_TmapOption(param);
int searchOption = (int) option.get("searchOptionResult");
					
					req = (ObjectNode) new ObjectNode(JsonNodeFactory.instance)
							.put("startName", "Departure")
							.put("startX", prevLon)
							.put("startY", prevLat)
							.put("startTime", retMap.get("completeTime").toString().replace("-", "").replace(":", "").replace(" ", "").substring(0, 12))
							.put("endName", "Arrive")
							.put("endX", map.get("finishLon").toString())
							.put("endY", map.get("finishLat").toString())
							.put("searchOption", searchOption)
							.set("viaPoints", viaPoints)
							;
				}
				
				workTime += (int) map.get("workTime");
				
				ObjectNode viaPoint = new ObjectNode(JsonNodeFactory.instance)
						.put("viaPointId", map.get("DELIVERY_PLACE_ID").toString())
						.put("viaPointName", "test")
						.put("viaX", map.get("LON").toString())
						.put("viaY", map.get("LAT").toString())
						.put("viaTime", (int) map.get("workTime"))
						;
						
				viaPoints.add(viaPoint);
				
				prevLat = map.get("LAT").toString();
				prevLon = map.get("LON").toString();
			} // for
			
			routeSequential(preDeliveryId, req, workTime, totalDistance, totalTime, featuresIndex, true);
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
	}
	
	private Map<String, Object> routeSequential(long deliveryId, ObjectNode req, int workTime, int prevTotalDistance, int prevTotalTime, int featuresIndex, boolean isLast) throws Throwable {
		Map<String, Object> retMap = new HashMap<>();
		int baseIndex = featuresIndex;
		String baseDateTime = req.get("startTime").textValue();
		String startDateTime = null;
		
		if ( req == null ) return null;
		
		JsonNode res = tmapApi.routeSequential(req.toString());
		
		Thread.sleep(1000);

		if ( res.get("error") != null ) {
			return null;
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		SimpleDateFormat sdft = new SimpleDateFormat("yyyyMMdd HH:mm:ss");

		JsonNode properties = res.get("properties");
		String totalDistance = properties.get("totalDistance").textValue(); 
		String totalTime = properties.get("totalTime").textValue();
		
		Map<String, Object> param = new HashMap<>();
		param.put("DELIVERY_ID", deliveryId);
		
		int totalMoveTime = 0;
		
		ArrayNode features = (ArrayNode) res.get("features");
		String retTime = null;
		
		for ( JsonNode feature : features ) {
			properties = feature.get("properties");
			String viaPointId = properties.get("viaPointId").textValue();
			String arriveTime = properties.get("arriveTime").textValue();
			String completeTime = properties.get("completeTime").textValue();
			String distance = properties.get("distance").textValue();
			String pointType = properties.get("pointType").textValue(); 
			String time = null;
			
			if ( pointType.equals("S") ) {
				startDateTime = arriveTime;
				
				if ( prevTotalTime > 0 ) {
					continue;
				}
			}
			
			if ( pointType.equals("E") ) {
				if ( !isLast ) {
					if ( properties.has("time") ) {
						time = properties.get("time").textValue();
						
						prevTotalDistance -= Integer.parseInt(distance);
						prevTotalTime -= Float.parseFloat(time);
					}
					
					continue;
				}
			} else {
				retTime = completeTime;
			}
			
			++featuresIndex;

			if ( properties.has("time") ) {
				time = properties.get("time").textValue();
				totalMoveTime += Integer.parseInt(time);
			}
			
			param.put("TMAP_INDEX", featuresIndex);
			param.put("TMAP_ARRIVE_TIME", sdft.format( sdf.parse(arriveTime) ) );
			param.put("TMAP_COMPLETE_TIME", sdft.format( sdf.parse(completeTime) ) );
			param.put("TMAP_DISTANCE", distance);
			param.put("TMAP_TIME", time);
			param.put("DELIVERY_PLACE_ID", viaPointId);
			
			dao.usp_nicecms_DeliveryTmapAdd(param);

			JsonNode geometry = feature.get("geometry");
			String type = geometry.get("type").textValue(); 
			ArrayNode coordinates = (ArrayNode) geometry.get("coordinates");
			int coordIndex = 0;
			
			if ( type.equals("Point") ) {
				// 중복 방지를 위해 Point 에서만 합산
				totalMoveTime += Integer.parseInt( properties.get("deliveryTime").textValue() );
				totalMoveTime += Integer.parseInt( properties.get("waitTime").textValue() );

				++coordIndex;
				
				double lon = coordinates.get(0).doubleValue();
				double lat = coordinates.get(1).doubleValue();
				
				param.put("TMAP_COORD_INDEX", coordIndex);
				param.put("TMAP_LAT", lat);
				param.put("TMAP_LON", lon);
				
				dao.usp_nicecms_DeliveryTmapCoordAdd(param);
			} else if ( type.equals("LineString") ) {
				for ( JsonNode coordinate : coordinates ) {
					++coordIndex;
					
					ArrayNode coord = (ArrayNode) coordinate;
					double lon = coord.get(0).doubleValue();
					double lat = coord.get(1).doubleValue();
					
					param.put("TMAP_COORD_INDEX", coordIndex);
					param.put("TMAP_LAT", lat);
					param.put("TMAP_LON", lon);
					
					dao.usp_nicecms_DeliveryTmapCoordAdd(param);
				}
			}
		} // for features
		
		/*
		param.put("baseIndex", baseIndex);
		param.put("baseDateTime", baseDateTime);
		param.put("startDateTime", startDateTime);
		param.put("completeDateTime", retTime);
		Map<String, Object> completeDateTime = dao.usp_nicecms_DeliveryTmapUpd(param);
		*/
		
		
		param.put("TMAP_DIST", Integer.parseInt(totalDistance) + prevTotalDistance);
		param.put("TMAP_TIME", Integer.parseInt(totalTime) + prevTotalTime);
		param.put("workTime", workTime);
		
		dao.usp_nicecms_DeliveryResultUpd(param);

		retMap.put("totalDistance", Integer.parseInt(totalDistance) + prevTotalDistance);
		retMap.put("totalTime", Integer.parseInt(totalTime) + prevTotalTime);
		//retMap.put("completeTime", completeDateTime.get("completeDateTime"));
		retMap.put("completeTime", retTime);
		retMap.put("featuresIndex", featuresIndex);
		
		return retMap;
	}
}

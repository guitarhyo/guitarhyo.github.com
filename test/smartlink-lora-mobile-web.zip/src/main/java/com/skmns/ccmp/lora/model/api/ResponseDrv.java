package com.skmns.ccmp.lora.model.api;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResponseDrv")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResponseDrv {

	/**
	 * 공통 헤더
	 */
	private ResDrvHeader header;

	private List<ResDriveInfo> info;
	private String authKey;

	/**
	 * constructor
	 */
	public ResponseDrv() {
		this.header = new ResDrvHeader();
	}

	/**
	 * constructor
	 *
	 * @param code
	 * @param message
	 */
	public ResponseDrv(final int code, final String message) {
		this.header = new ResDrvHeader(code, message);
	}
	
	/**
	 * constructor
	 *
	 * @param code
	 * @param message
	 * @param authkey
	 */
	public ResponseDrv(final int code, final String message , String authKey) {
		this.header = new ResDrvHeader(code, message);
		this.authKey = authKey;
	}

	/*
	 * getter & setter
	 */

	public ResDrvHeader getHeader() {
		return this.header;
	}

	public void setHeader(final ResDrvHeader header) {
		this.header = header;
	}


	public String getAuthkey() {
		return authKey;
	}

	public void setAuthkey(String authKey) {
		this.authKey = authKey;
	}

	public List<ResDriveInfo> getInfo() {
		return info;
	}

	public void setInfo(List<ResDriveInfo> info) {
		this.info = info;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseDrv [header=");
		builder.append(header);
		builder.append(", info=");
		builder.append(info);
		builder.append(", authKey=");
		builder.append(authKey);
		builder.append("]");
		return builder.toString();
	}

	
}

package com.skmns.ccmp.lora.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.dao.MypageDAO;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Member;

@Service
public class MypageService {

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private SessionManager sessionManager;

	@Autowired
	private MypageDAO mypageDAO;

	public Member mypageMain(final Member member) throws CommonResponseException {

		Member resultMember = this.mypageDAO.usp_api_Member_FindByUserId(member);
		resultMember.setUserId(member.getUserId());

		return resultMember;
	}

	public ModelMap mypageInfo(final Member member) throws CommonResponseException {

		ModelMap map = new ModelMap();
		String userId = this.sessionManager.getLoginMember(this.request).getUserId();
		member.setUserId(userId);

		Member resultMember = this.mypageDAO.usp_api_Member_FindByUserId(member);

		resultMember.setUserId(member.getUserId());


		map.put("resultMember", resultMember);

		return map;
	}

	public CommonResult infoUpdateMember(final Member member) throws CommonResponseException {

		CommonResult result = this.mypageDAO.usp_api_Member_Update(member);

		if ("0".equals(result.getCode())) {

			String userId = this.sessionManager.getMember(this.request).getUserId();
			member.setUserId(userId);

			Member resultMember = this.mypageDAO.usp_api_Member_FindByUserId(member);
			if (resultMember != null) {
				resultMember.setUserId(userId);
				this.sessionManager.setMember(this.request, resultMember);
			}

		}

		return result;
	}

	public CommonResult updatePass(final Member member) throws CommonResponseException {

		CommonResult result = this.mypageDAO.usp_api_Member_Update_UserPass(member);

		if ("0".equals(result.getCode())) {

			String userId = this.sessionManager.getMember(this.request).getUserId();
			member.setUserId(userId);

			Member resultMember = this.mypageDAO.usp_api_Member_FindByUserId(member);
			if (resultMember != null) {
				resultMember.setUserId(userId);
				this.sessionManager.setMember(this.request, resultMember);
			}

		}

		return result;
	}

	
	public CommonResult usp_api_Member_UnRegist(final Member member) throws CommonResponseException {
		return this.mypageDAO.usp_api_Member_UnRegist(member);
	}

}

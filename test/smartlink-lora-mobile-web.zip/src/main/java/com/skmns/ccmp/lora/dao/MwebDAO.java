package com.skmns.ccmp.lora.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.AreaAddr;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.model.MwebCar;

@Repository
public class MwebDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = MwebDAO.class.getPackage().getName() + ".";

	
	public List<MwebCar> mweb_Car_FindByCarList(MwebCar param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "Mweb_Car_FindByCarList", param);
	}
	
	
	
	/**
	 * 모바일 차량 관제 모니터링 관리자 체크
	 *
	 * @param member
	 *
	 * @return int
	 */
	public int usp_Admin_LoginCheck(final Member member) throws CommonResponseException {

		return this.sqlSession.selectOne(NS + "usp_Admin_LoginCheck", member);
	}
	
	
	public List<MwebCar> Mweb_MovingCafe_Car_FindByCarList(MwebCar param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "Mweb_MovingCafe_Car_FindByCarList", param);
	}
	public int Mweb_MovingCafe_Car_Update_Count(MwebCar param) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "Mweb_MovingCafe_Car_Update_Count", param);
	}
	
	public MwebCar Mweb_MovingCafe_Car_FindByCarInfo(MwebCar param) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "Mweb_MovingCafe_Car_FindByCarInfo", param);
	}
	public CommonResult Mweb_MovingCafe_Car_Create(MwebCar param) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "Mweb_MovingCafe_Car_Create", param);
	}
	public List<AreaAddr> Mweb_MovingCafe_Area_AddressList(final AreaAddr param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "Mweb_MovingCafe_Area_AddressList", param);
	}
}

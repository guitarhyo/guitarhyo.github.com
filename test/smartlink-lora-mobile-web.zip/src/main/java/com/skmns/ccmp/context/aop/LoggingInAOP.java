package com.skmns.ccmp.context.aop;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class LoggingInAOP {
	private static final String STR_COMMA = " ,";
	private static final String STR_RIGHT_PARENTHESIS = ")";
	private static final String STR_LEFT_PARENTHESIS = "(";
	private static final String STR_END_EXECUTE_TIME =   " E N D ....... Execute Time ....... : ";
	private static final String STR_START_EXECUTE_TIME = " START ....... Execute Time ....... : ";

	/*
	@Around(value = "execution(* com.skmns..*Controller.*(..)) " 
			+ "or execution(* com.skmns..*Service.*(..)) " 
			+ "or execution(* com.skmns..*Dao.*(..)) " 
			+ "or execution(* com.skmns..*DAO.*(..)) "
			+ "or execution(* com.skmns..*Handler.*(..))")
	*/
	@Around(value = "execution(* com.skmns..*Controller.*(..)) " 
			+ "or execution(* com.skmns..*Handler.*(..))")
	public Object doLayerLoggingAround(final ProceedingJoinPoint pjp) throws Throwable {
		return this.doLoggingAround(pjp);
	}

	public Object doLoggingAround(final ProceedingJoinPoint pjp) throws Throwable {
		Logger logger = LoggerFactory.getLogger(pjp.getTarget().getClass());

		StringBuffer sb = new StringBuffer();
		Object retVal = null;

		sb.append(pjp.getSignature().getName()).append(STR_LEFT_PARENTHESIS).append(this.getAgumentNames(pjp.getArgs())).append(STR_RIGHT_PARENTHESIS);

		try {
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			logger.info(sb.toString() + STR_START_EXECUTE_TIME + stopWatch.toString());

			retVal = pjp.proceed();

			stopWatch.stop();
			logger.info(sb.toString() + STR_END_EXECUTE_TIME + stopWatch.toString());
		} catch (Exception e) {
			logger.error(sb.toString() + ExceptionUtils.getStackTrace(e));
			throw e;
		}
		return retVal;
	}

	public StringBuffer getAgumentNames(final Object[] obj) {
		StringBuffer objNames = new StringBuffer();
		for (int i = 0; i < obj.length; i++) {
			if (obj[i] != null) {
				objNames.append(obj[i].getClass().getSimpleName());
				if (i + 1 != obj.length) {
					objNames.append(STR_COMMA);
				}
			}
		}
		return objNames;
	}

}

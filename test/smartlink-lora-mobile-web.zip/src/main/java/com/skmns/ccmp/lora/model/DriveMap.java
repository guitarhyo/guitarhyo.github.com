package com.skmns.ccmp.lora.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

@Alias(value = "DriveMap")
public class DriveMap implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1067535357828738552L;

	private long drvId; // 주행 ID
	private int carId;//차아이디
	private int coId;
	private String devEui; // Lora DEV EUI

	private String modelName; //차모델
	private String carNumber; //차 번호
	private String onDt; // 시동 ON 일시
	private String offDt; // 시동 OFF 일시
	private String drvSts;
	private String memberName;
	private String empNumber;
	private String empPart;

	private String startDt;
	private String endDt;
	private String searchDt;

	private float lat; // 위도
	private float lon; // 경도
	private String gpsDt; // gps 시간

	private String authKey;
	private String message;
	private int code;

	private String obdDist;
	private String usgTyp;
	private String rowNum;
	private String drvTime;

	private String onAddr;
	private String offAddr;

	private BigDecimal fuelPayment;
	private BigDecimal hipassPayment;

	private String isInpFuel; //주유 여부
	private float fuelAmt; // 주유량 단위 L

	//추가 요청때문에 미리 추가
	private int drvrId; // 운전자(회원) ID
	private int insTyp; // 고정 차량 (0: 자동, 1: 고정)
	private String userId;
	private String drvTimeStr;
	private int isDel; //삭제 여부 1 삭제
	private float onLat; // 시동 ON시 위도
	private float onLon; // 시동 ON시 경도
	private float offLat; // 시동 OFF시 위도
	private float offLon; // 시동 OFF시 경도
	private float gpsDist; // GPS 이동거리
	private float usrDist; // 사용자 이동거리
	private float drvStDist; // 운행 시작시 계기판 주행거리
	private float drvEdDist; // 운행 종료시 계기판 주행거리
	private float battVolt; // 차량 전압(0.1v)
	private String insId;
	private String insDt;
	private String updId;
	private String updDt;
	private int maxCnt;
	private int maxPage;
	private String searchStartDate;
	private String searchEndDate;
	private int cnt;
	private float ratio;
	private float cntRatio;
	private float obdDistRatio;
	private float gpsDistRatio;
	private float usrDistRatio;
	private float score;
	private int safDrvIdx; // 안전 지수 	
	private int fstAccelIdx; // 급가속 지수 
	private int fstAccelCnt; // 급가속 횟수 
	private int fstDecelIdx; // 급감속 지수 
	private int fstDecelCnt; // 급감속 횟수 
	private int overSpdIdx; // 과속 지수 

	public String getIsInpFuel() {
		return isInpFuel;
	}

	public void setIsInpFuel(String isInpFuel) {
		this.isInpFuel = isInpFuel;
	}

	public float getFuelAmt() {
		return fuelAmt;
	}

	public void setFuelAmt(float fuelAmt) {
		this.fuelAmt = fuelAmt;
	}

	public int getDrvrId() {
		return drvrId;
	}

	public void setDrvrId(int drvrId) {
		this.drvrId = drvrId;
	}

	public int getInsTyp() {
		return insTyp;
	}

	public void setInsTyp(int insTyp) {
		this.insTyp = insTyp;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDrvTimeStr() {
		return drvTimeStr;
	}

	public void setDrvTimeStr(String drvTimeStr) {
		this.drvTimeStr = drvTimeStr;
	}

	public int getIsDel() {
		return isDel;
	}

	public void setIsDel(int isDel) {
		this.isDel = isDel;
	}

	public float getOnLat() {
		return onLat;
	}

	public void setOnLat(float onLat) {
		this.onLat = onLat;
	}

	public float getOnLon() {
		return onLon;
	}

	public void setOnLon(float onLon) {
		this.onLon = onLon;
	}

	public float getOffLat() {
		return offLat;
	}

	public void setOffLat(float offLat) {
		this.offLat = offLat;
	}

	public float getOffLon() {
		return offLon;
	}

	public void setOffLon(float offLon) {
		this.offLon = offLon;
	}

	public float getGpsDist() {
		return gpsDist;
	}

	public void setGpsDist(float gpsDist) {
		this.gpsDist = gpsDist;
	}

	public float getUsrDist() {
		return usrDist;
	}

	public void setUsrDist(float usrDist) {
		this.usrDist = usrDist;
	}

	public float getDrvStDist() {
		return drvStDist;
	}

	public void setDrvStDist(float drvStDist) {
		this.drvStDist = drvStDist;
	}

	public float getDrvEdDist() {
		return drvEdDist;
	}

	public void setDrvEdDist(float drvEdDist) {
		this.drvEdDist = drvEdDist;
	}

	public float getBattVolt() {
		return battVolt;
	}

	public void setBattVolt(float battVolt) {
		this.battVolt = battVolt;
	}

	public String getInsId() {
		return insId;
	}

	public void setInsId(String insId) {
		this.insId = insId;
	}

	public String getInsDt() {
		return insDt;
	}

	public void setInsDt(String insDt) {
		this.insDt = insDt;
	}

	public String getUpdId() {
		return updId;
	}

	public void setUpdId(String updId) {
		this.updId = updId;
	}

	public String getUpdDt() {
		return updDt;
	}

	public void setUpdDt(String updDt) {
		this.updDt = updDt;
	}

	public int getMaxCnt() {
		return maxCnt;
	}

	public void setMaxCnt(int maxCnt) {
		this.maxCnt = maxCnt;
	}

	public int getMaxPage() {
		return maxPage;
	}

	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}

	public String getSearchStartDate() {
		return searchStartDate;
	}

	public void setSearchStartDate(String searchStartDate) {
		this.searchStartDate = searchStartDate;
	}

	public String getSearchEndDate() {
		return searchEndDate;
	}

	public void setSearchEndDate(String searchEndDate) {
		this.searchEndDate = searchEndDate;
	}

	public int getCnt() {
		return cnt;
	}

	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	public float getRatio() {
		return ratio;
	}

	public void setRatio(float ratio) {
		this.ratio = ratio;
	}

	public float getCntRatio() {
		return cntRatio;
	}

	public void setCntRatio(float cntRatio) {
		this.cntRatio = cntRatio;
	}

	public float getObdDistRatio() {
		return obdDistRatio;
	}

	public void setObdDistRatio(float obdDistRatio) {
		this.obdDistRatio = obdDistRatio;
	}

	public float getGpsDistRatio() {
		return gpsDistRatio;
	}

	public void setGpsDistRatio(float gpsDistRatio) {
		this.gpsDistRatio = gpsDistRatio;
	}

	public float getUsrDistRatio() {
		return usrDistRatio;
	}

	public void setUsrDistRatio(float usrDistRatio) {
		this.usrDistRatio = usrDistRatio;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public int getSafDrvIdx() {
		return safDrvIdx;
	}

	public void setSafDrvIdx(int safDrvIdx) {
		this.safDrvIdx = safDrvIdx;
	}

	public int getFstAccelIdx() {
		return fstAccelIdx;
	}

	public void setFstAccelIdx(int fstAccelIdx) {
		this.fstAccelIdx = fstAccelIdx;
	}

	public int getFstAccelCnt() {
		return fstAccelCnt;
	}

	public void setFstAccelCnt(int fstAccelCnt) {
		this.fstAccelCnt = fstAccelCnt;
	}

	public int getFstDecelIdx() {
		return fstDecelIdx;
	}

	public void setFstDecelIdx(int fstDecelIdx) {
		this.fstDecelIdx = fstDecelIdx;
	}

	public int getFstDecelCnt() {
		return fstDecelCnt;
	}

	public void setFstDecelCnt(int fstDecelCnt) {
		this.fstDecelCnt = fstDecelCnt;
	}

	public int getOverSpdIdx() {
		return overSpdIdx;
	}

	public void setOverSpdIdx(int overSpdIdx) {
		this.overSpdIdx = overSpdIdx;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DriveMap [drvId=");
		builder.append(drvId);
		builder.append(", carId=");
		builder.append(carId);
		builder.append(", coId=");
		builder.append(coId);
		builder.append(", devEui=");
		builder.append(devEui);
		builder.append(", modelName=");
		builder.append(modelName);
		builder.append(", carNumber=");
		builder.append(carNumber);
		builder.append(", onDt=");
		builder.append(onDt);
		builder.append(", offDt=");
		builder.append(offDt);
		builder.append(", drvSts=");
		builder.append(drvSts);
		builder.append(", memberName=");
		builder.append(memberName);
		builder.append(", empNumber=");
		builder.append(empNumber);
		builder.append(", empPart=");
		builder.append(empPart);
		builder.append(", startDt=");
		builder.append(startDt);
		builder.append(", endDt=");
		builder.append(endDt);
		builder.append(", searchDt=");
		builder.append(searchDt);
		builder.append(", lat=");
		builder.append(lat);
		builder.append(", lon=");
		builder.append(lon);
		builder.append(", gpsDt=");
		builder.append(gpsDt);
		builder.append(", authKey=");
		builder.append(authKey);
		builder.append(", message=");
		builder.append(message);
		builder.append(", code=");
		builder.append(code);
		builder.append("]");
		return builder.toString();
	}

	public BigDecimal getFuelPayment() {
		return fuelPayment;
	}

	public void setFuelPayment(BigDecimal fuelPayment) {
		this.fuelPayment = fuelPayment;
	}

	public BigDecimal getHipassPayment() {
		return hipassPayment;
	}

	public void setHipassPayment(BigDecimal hipassPayment) {
		this.hipassPayment = hipassPayment;
	}

	public String getOnAddr() {
		return onAddr;
	}

	public void setOnAddr(String onAddr) {
		this.onAddr = onAddr;
	}

	public String getOffAddr() {
		return offAddr;
	}

	public void setOffAddr(String offAddr) {
		this.offAddr = offAddr;
	}

	public String getDrvTime() {
		return drvTime;
	}

	public void setDrvTime(String drvTime) {
		this.drvTime = drvTime;
	}

	public String getObdDist() {
		return obdDist;
	}

	public void setObdDist(String obdDist) {
		this.obdDist = obdDist;
	}

	public String getUsgTyp() {
		return usgTyp;
	}

	public void setUsgTyp(String usgTyp) {
		this.usgTyp = usgTyp;
	}

	public String getRowNum() {
		return rowNum;
	}

	public void setRowNum(String rowNum) {
		this.rowNum = rowNum;
	}

	public String getSearchDt() {
		return searchDt;
	}

	public void setSearchDt(String searchDt) {
		this.searchDt = searchDt;
	}

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public long getDrvId() {
		return drvId;
	}

	public void setDrvId(long drvId) {
		this.drvId = drvId;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public int getCoId() {
		return coId;
	}

	public void setCoId(int coId) {
		this.coId = coId;
	}

	public String getDevEui() {
		return devEui;
	}

	public void setDevEui(String devEui) {
		this.devEui = devEui;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public String getOnDt() {
		return onDt;
	}

	public void setOnDt(String onDt) {
		this.onDt = onDt;
	}

	public String getOffDt() {
		return offDt;
	}

	public void setOffDt(String offDt) {
		this.offDt = offDt;
	}

	public String getDrvSts() {
		return drvSts;
	}

	public void setDrvSts(String drvSts) {
		this.drvSts = drvSts;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getEmpNumber() {
		return empNumber;
	}

	public void setEmpNumber(String empNumber) {
		this.empNumber = empNumber;
	}

	public String getEmpPart() {
		return empPart;
	}

	public void setEmpPart(String empPart) {
		this.empPart = empPart;
	}

	public String getStartDt() {
		return startDt;
	}

	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}

	public String getEndDt() {
		return endDt;
	}

	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}

	public float getLat() {
		return lat;
	}

	public void setLat(float lat) {
		this.lat = lat;
	}

	public float getLon() {
		return lon;
	}

	public void setLon(float lon) {
		this.lon = lon;
	}

	public String getGpsDt() {
		return gpsDt;
	}

	public void setGpsDt(String gpsDt) {
		this.gpsDt = gpsDt;
	}

}

package com.skmns.ccmp.lora.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.common.util.SkmnsDateUtil;
import com.skmns.ccmp.lora.model.Car;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Drive;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.model.Paging;
import com.skmns.ccmp.lora.service.DriveHistService;

@Controller
@RequestMapping("/app")
public class DriveHistController {
	private String jspPath = "/app/drivehist";
	
	private static final Logger logger = LoggerFactory.getLogger(DriveHistController.class);
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private SessionManager sessionManager;
	
	
	@Autowired
	private DriveHistService drvService;
	/*
	 * TODO
	 * - 요약(통계) 그래프 조회
	 * - 안전운전 지수 : 0~0.5 빨간색, 0.6~1.4 노란색, 1.5~2.0 초록색
	 * - 주행중 리스트
	 * - 주행완료 리스트
	 * - 상세 정보
	 * - 완료된 주행기록의 용도 변경
	 * 
	 * 메인화면
	 * - 현재 운행 완료된 상태 : 가장 최근 기록 1건 조회
	 * - 현재 운행중 상태 : 현재 운행 기록 조회
	 * - (미정) 캠페인 문구 랜덤
	 * 
	 * 메인화면-차량 연결 전환(주행뺏기)
	 * 차량 연결중 체크
	 * 1-1) 차량 미연결시 -> 사용자 변경
	 * 2-1) 10초마다 차량 연결 여부 확인
	 *  
	 */


	
	/**
	 * <PRE>
	 * 설명 : 주행 기록 리스트 페이지
	 *
	 * <PRE>
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/drivehist/list")
	public String drivehistlist(@RequestParam(value = "drvId", required = false, defaultValue = "-1") final int drvId,@RequestParam(value = "pageNum", required = false, defaultValue = "-1") final int pageNum) throws Exception {

		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		Map<String, Drive> summary = drvService.getDriveSummary(Integer.parseInt(memberId));
		
		Drive drive = new Drive();
		drive.setDrvSts(1);
		drive.setRowNum(1);
		drive.setDrvrId(Integer.parseInt(memberId));
		List<Drive> result = this.drvService.getDriveList(drive);
		
		for (int i = 0; i < result.size(); i++) {
			int milliseconds = result.get(i).getDrvTime();
			int seconds = (int) (milliseconds  % 60) ;            //초
			int minutes = (int) (milliseconds / 60% 60);  //분
			int hours   = (int) (milliseconds / (60*60));//시
			String str = "";
			if(hours >0){
				str +=  ((hours < 10) ? "0"+hours : hours) + "시"; 
			}
			if(minutes >0){
				str +=  ((minutes < 10) ? "0"+minutes : minutes) + "분"; 
			}
				str +=  ((seconds < 10) ? "0"+seconds : seconds) + "초"; 
				
				result.get(i).setDrvTimeStr(str);
		}
		
		request.setAttribute("summary", summary);
		request.setAttribute("result", result);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("drvId", drvId);
		
		return this.jspPath + "/driveHistList";
	}
	
	/**
	 * <PRE>
	 * 설명 : 주행 기록 주행완료
	 *
	 * <PRE>
	 *
	 * @return List<Drive>
	 * @throws Exception
	 */
	@RequestMapping("/drivehist/raceList")
	@ResponseBody
	public List<Drive> raceList(final Drive drive, Paging paging) throws CommonResponseException {
		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		drive.setDrvSts(0);
		drive.setDrvrId(Integer.parseInt(memberId));
		List<Drive> result = this.drvService.getDriveList(drive,  paging);
		logger.debug("result : {}", result);
		return result;
	}
	
	
	
	/**
	 * <PRE>
	 * 설명 : 주행 기록 검색리스트 페이지
	 *
	 * <PRE>
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/drivehist/searchList")
	public String searchList() throws Exception {
		this.request.setAttribute("searchStartDate", SkmnsDateUtil.getToday());
		this.request.setAttribute("searchEndDate",  SkmnsDateUtil.getToday());
		
		return this.jspPath + "/driveSearchList";
	}
	
	
	/**
	 * <PRE>
	 * 설명 : 주행 기록 검색 리스트
	 *
	 * <PRE>
	 *
	 * @return List<Drive>
	 * @throws Exception
	 */
	@RequestMapping("/drivehist/search")
	@ResponseBody
	public List<Drive> search(final Drive drive, Paging paging) throws CommonResponseException {
		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		drive.setDrvrId(Integer.parseInt(memberId));
		List<Drive> result = this.drvService.getDriveList(drive,paging);
		logger.debug("result : {}", result);
		return result;
	}
	
	
	/**
	 * <PRE>
	 * 설명 : 주행 기록 상세
	 *
	 * <PRE>
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/drivehist/{driveId}/dtl")
	public String dtlPage(@PathVariable final int driveId,@RequestParam(value = "pageNum", required = false, defaultValue = "-1") final int pageNum) throws Exception {
		
		Drive result = this.drvService.getDriveInfo(driveId);
		request.setAttribute("result", result);

		String beforeMonth = SkmnsDateUtil.getDatewithGap("MONTH", -2, "yyyyMM");
		String onDtMonth = SkmnsDateUtil.getPattern(result.getOnDt(),"yyyy-MM-dd HH:mm:ss.SSS","yyyyMM");
		request.setAttribute("monthBefore", beforeMonth);
		request.setAttribute("onDtMonth", onDtMonth);
		request.setAttribute("pageNum", pageNum);
		
		logger.debug("{}",driveId);
		return this.jspPath + "/driveHistDtl";
	}

	/**
	 * <PRE>
	 * 설명 : 주행 기록 운행용도 수정
	 *
	 * <PRE>
	 *
	 * @return CommonResult
	 * @throws Exception
	 */
	@RequestMapping("/drivehist/updateType")
	@ResponseBody
	public CommonResult updateDriveType(final Drive drive) throws CommonResponseException {
		
		String userId = this.sessionManager.getLoginMember(this.request).getUserId();
		drive.setInsId(userId);
		
		CommonResult result = this.drvService.updateDriveType(drive);
		
		logger.debug("result : {}", result);
		return result;
	}
	
	@RequestMapping("/drivehist/carFixCnt")
	@ResponseBody
	public int carFixCnt() throws CommonResponseException {
		String userId = this.sessionManager.getLoginMember(this.request).getUserId();

		int result = this.drvService.carFixCnt(userId);
		
		logger.debug("result : {}", result);
		return result;
	}
	
	
	@RequestMapping(value = "/drivehist/driveHistHandReg")
	public String driveHistHandReg() throws Exception {
		
		Member m = this.sessionManager.getLoginMember(this.request);
		Map<String, Object> searchMap = new HashMap<>();
		searchMap.put("corpId", m.getCorpId());
		searchMap.put("carNo", "");
		searchMap.put("userId", m.getUserId());
		List<Car> list =  this.drvService.searchCarNoList(searchMap);
		request.setAttribute("carList", list);
		
		String tmpDate = SkmnsDateUtil.getDatewithGap("MINUTE",-10,"yyyyMMddHHmmss");
		String nowDate = tmpDate.substring(0, 4) + "년" + tmpDate.substring(4, 6) + "월" + tmpDate.substring(6, 8) + "일";
		String nowHour =  tmpDate.substring(8, 10) + ":" + tmpDate.substring(10, 11)+"0";
		this.request.setAttribute("nowStartDate", nowDate);
		this.request.setAttribute("nowStartHour", nowHour);
		tmpDate = SkmnsDateUtil.Date2String("yyyyMMddHHmmss");
		nowDate = tmpDate.substring(0, 4) + "년" + tmpDate.substring(4, 6) + "월" + tmpDate.substring(6, 8) + "일";
		nowHour =  tmpDate.substring(8, 10) + ":" + tmpDate.substring(10, 11)+"0";
		this.request.setAttribute("nowEndDate", nowDate);
		this.request.setAttribute("nowEndHour", nowHour);
		
		logger.debug("{}",list);
		return this.jspPath + "/driveHistHandReg";
	}
	
	@RequestMapping("/drivehist/searchFixCarNoList")
	@ResponseBody
	public List<Car> searchFixCarNoList(@RequestParam(value = "searchWord", required = false, defaultValue = "") final String searchWord) throws CommonResponseException {
		Member m = this.sessionManager.getLoginMember(this.request);
		Map<String, Object> searchMap = new HashMap<>();
		searchMap.put("corpId", m.getCorpId());
		searchMap.put("carNo", searchWord);
		searchMap.put("userId", m.getUserId());
		List<Car> list =  this.drvService.searchCarNoList(searchMap);
		
		
		return list;
	}
	
	@RequestMapping("/drivehist/carLatestDist")
	@ResponseBody
	public int carLatestDist(@RequestParam(value = "carId", required = false, defaultValue = "") final String carId) throws CommonResponseException {
		Member m = this.sessionManager.getLoginMember(this.request);
		Map<String, Object> searchMap = new HashMap<>();
		searchMap.put("userId", m.getUserId());
		searchMap.put("carId", carId);
		Drive drve =  this.drvService.usp_Lora_Web_Drive_CarLatestDist(searchMap);
		
		int retDist = 0;
		if(drve != null && drve.getDrvEdDist() > 0){
			 retDist = (int) drve.getDrvEdDist();
		}

		return retDist;
	}
	
	@RequestMapping("/drivehist/driveHandCreate")
	@ResponseBody
	public CommonResult driveHandCreate(Drive drive) throws CommonResponseException {
		
		Member m = this.sessionManager.getLoginMember(this.request);
		drive.setUserId(m.getUserId());
		drive.setCoId(Integer.parseInt(m.getCorpId()));
		
		CommonResult result = this.drvService.usp_Lora_Web_Drive_Create(drive);
		
		logger.debug("result : {}", result);
		return result;
	}
	
	@RequestMapping("/drivehist/driveHandUpdate")
	@ResponseBody
	public CommonResult driveHandUpdate(Drive drive) throws CommonResponseException {
		drive.setIsDel(0);
		
		Member m = this.sessionManager.getLoginMember(this.request);
		drive.setUserId(m.getUserId());
		drive.setCoId(Integer.parseInt(m.getCorpId()));
		
		CommonResult result = this.drvService.usp_Lora_Web_Drive_Update_Fix(drive);
		
		logger.debug("result : {}", result);
		return result;
	}
	
	@RequestMapping("/drivehist/driveHandDel")
	@ResponseBody
	public CommonResult driveHandDel(long drvId) throws CommonResponseException {
		Drive drive = new Drive();
		drive.setDrvId(drvId);
		drive.setIsDel(1);
		
		Member m = this.sessionManager.getLoginMember(this.request);
		drive.setUserId(m.getUserId());
		drive.setCoId(Integer.parseInt(m.getCorpId()));
		
		CommonResult result = this.drvService.usp_Lora_Web_Drive_Update_Fix(drive);
		
		logger.debug("result : {}", result);
		return result;
	}
	
	
}

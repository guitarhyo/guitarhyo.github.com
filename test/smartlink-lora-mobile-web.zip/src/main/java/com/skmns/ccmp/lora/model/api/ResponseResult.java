package com.skmns.ccmp.lora.model.api;

import org.apache.ibatis.type.Alias;


@Alias(value = "ResponseResult")
public class ResponseResult {

	private int code;
	private String message;

	private String authkey;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAuthkey() {
		return authkey;
	}

	public void setAuthkey(String authkey) {
		this.authkey = authkey;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseResult [code=");
		builder.append(code);
		builder.append(", message=");
		builder.append(message);
		builder.append(", authkey=");
		builder.append(authkey);
		builder.append("]");
		return builder.toString();
	}

}

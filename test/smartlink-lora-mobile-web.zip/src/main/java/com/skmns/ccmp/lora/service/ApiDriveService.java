package com.skmns.ccmp.lora.service;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skmns.ccmp.common.enc.AES;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.dao.ApiDriveDAO;
import com.skmns.ccmp.lora.model.Corp;
import com.skmns.ccmp.lora.model.DriveInfo;
import com.skmns.ccmp.lora.model.api.ReqCheck;
import com.skmns.ccmp.lora.model.api.ResDrvStat;
import com.skmns.ccmp.lora.model.api.ResGps;
import com.skmns.ccmp.lora.model.api.ResHipass;
import com.skmns.ccmp.lora.model.api.ReqParam;
import com.skmns.ccmp.lora.model.api.ResCarDist;
import com.skmns.ccmp.lora.model.api.ResCarInfo;
import com.skmns.ccmp.lora.model.api.ResDiagCode;
import com.skmns.ccmp.lora.model.api.ResDriveInfo;
import com.skmns.ccmp.lora.model.api.ResDrvDyStat;
import com.skmns.ccmp.lora.model.api.ResDrvHst;
import com.skmns.ccmp.lora.model.api.ResMemberInfo;
import com.skmns.ccmp.lora.model.api.ResMntnCost;
import com.skmns.ccmp.lora.model.api.ResPanelty;
import com.skmns.ccmp.lora.model.api.ResRsvInfo;
import com.skmns.ccmp.lora.model.api.ResSafeStats;
import com.skmns.ccmp.lora.model.api.ResponseDrv;
import com.skmns.ccmp.lora.model.api.ResponseData;
import com.skmns.ccmp.lora.model.api.ResponseResult;
import com.skmns.ccmp.lora.model.api.ResFrstLstDrvDt;

/**
 * @author 201610095
 *
 */
@Service
public class ApiDriveService {
	
	private static final Logger logger = LoggerFactory.getLogger("API");

	@Autowired
	private ApiDriveDAO apiDriveDAO;
	
	private static final int CODE_SUCCESS = 0;
	private static final int CODE_FAIL = 200;
	private static final String CODE_SUCCESS_MESSAGE = "success";
	
	/**
	 * AuthKey 생성
	 */
	public ResponseDrv reqAuthKey(ReqParam param) {
		ResponseDrv rtnObj = new ResponseDrv(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		String fileLog = "";
		
		try {
			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|reqAuthKey|" + fileLog;
			
			param.setCheckTyp(2);//고객사 아이디 및 인증키 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseDrv(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}
			
			ResponseResult responseResult = this.apiDriveDAO.usp_CustAPI_AuthKey_Req(param);
			if(responseResult != null && 0 == responseResult.getCode()){
				rtnObj = new ResponseDrv(responseResult.getCode(), responseResult.getMessage(),responseResult.getAuthkey());
			}else{
				rtnObj = new ResponseDrv(responseResult.getCode(), responseResult.getMessage());
			}
			
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
		} catch (Exception e) {
			rtnObj = new ResponseDrv(CODE_FAIL, "Exception");
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		return rtnObj;
	}
	
	
	/**
	 * 물류센터 운행 이력 조회(gps 궤적 포함)
	 */
	public ResponseDrv reqDrvHstGps(ReqParam param) {
		ResponseDrv rtnObj = new ResponseDrv(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		String fileLog = "";
		
		try {
			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|reqDrvHstGps|" + fileLog;
			
			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
				param.setCorpId(reqCheck.getCorpId());
			}else{
				rtnObj = new ResponseDrv(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}
			
			param.setCheckTyp(1);//날짜 검증
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseDrv(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}
			
			List<DriveInfo> driveList = this.apiDriveDAO.usp_CustAPI_DrvHstGps_Req(param);
				
				if(driveList != null){
						for (int i = 0; i < driveList.size(); i++) {
							ResDriveInfo info = driveList.get(i);
							//GPS 가져오는 프로시저 호출
							param.setDrvId(info.getDrvId().intValue());
							List<ResGps> gpsList = this.apiDriveDAO. usp_CustAPI_DrvGpsDist_Req(param);
							if(gpsList != null && gpsList.size() >0){
								driveList.get(i).setGps(gpsList);
							}
						}

					rtnObj.setInfo(resDriveListInit(driveList));
					logger.debug("driveList.size() : {}",driveList.size());
					fileLog +=  "|driveList.size() :"+driveList.size();
				}

			fileLog += "|"+rtnObj.getHeader().toString()+"|";
			
			logger.info("{}",fileLog);
		} catch (Exception e) {
			rtnObj = new ResponseDrv(CODE_FAIL, "Exception");
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		return rtnObj;
	}
	

	
	/**
	 *  ResDriveInfo 생성
	 *
	 * @param url
	 * @param param
	 * @return
	 */
	public List<ResDriveInfo> resDriveListInit( List<DriveInfo> driveList) {
		List<ResDriveInfo> resDriveList = new ArrayList<ResDriveInfo>() ;
		
		if(driveList != null){
			for (int i = 0; i < driveList.size(); i++) {
				ResDriveInfo resDriveInfo = new ResDriveInfo(driveList.get(i).getDrvId()
						, driveList.get(i).getCarNum(), driveList.get(i).getOnDt(), driveList.get(i).getOnDist()
						, driveList.get(i).getOffDt(), driveList.get(i).getOffDist(), 
						driveList.get(i).getGps(), driveList.get(i).getSafDrvIdx(), driveList.get(i).getFstAccelIdx()
						, driveList.get(i).getFstDecelIdx(), driveList.get(i).getFstAccelCnt(), driveList.get(i).getFstDecelCnt()
						, driveList.get(i).getOverSpdIdx(), driveList.get(i).getOverSpdTm(), driveList.get(i).getFstAccelTm()
						, driveList.get(i).getFstDecelTm(), driveList.get(i).getFuelAmt(), driveList.get(i).getFuelUseAmt()
						, driveList.get(i).getOncnt(), driveList.get(i).getMovTm(), driveList.get(i).getIdleTm());
				resDriveList.add(resDriveInfo);
	
			}
		}
		
		return resDriveList;
	}
	
	/**
	 *  차량정보 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getCarInfoList (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		String fileLog = "";

		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getCarInfoList|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		param.setCheckTyp(3);// 차량정보  필수 정보 확인
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

			List<ResCarInfo> list =apiDriveDAO.usp_CustAPI_CarInfo_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setCars(list); 
			}
			
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	/**
	 *  회원정보 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getMemberInfoList (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		
		String fileLog = "";
		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getMemberInfoList|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		param.setCheckTyp(4);// 회원 정보  필수 정보 확인
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		List<ResMemberInfo> list =apiDriveDAO.usp_CustAPI_MemberInfo_Req(param);
		if(list != null && list.size() > 0){
			rtnObj.setMembers(list); 
		}
			
			
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	
	
	/**
	 *  운행 이력  조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getDrvHst (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		String fileLog = "";
		
		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getDrvHst|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		param.setCheckTyp(5);// 날짜 및 회원 정보  필수 정보 확인
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
			List<ResDrvHst> list = apiDriveDAO.usp_CustAPI_DrvHst_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setDrvHsts(list); 
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	/**
	 *  운행 GPS 이력  조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getDrvGps (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		
		String fileLog = "";
		

		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getDrvGps|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		
		param.setCheckTyp(6);// 주행 아이디 체크
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
			List<ResGps> list = apiDriveDAO.usp_CustAPI_DrvGps_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setGps(list); 
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	/**
	 *  운행 통계  조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getDrvStat (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		
		String fileLog = "";
		

		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getDrvStat|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		param.setCheckTyp(7);// 날짜및 선택 파람 체크
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

			List<ResDrvStat> list = apiDriveDAO.usp_CustAPI_DrvStat_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setDrvStats(list); 
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	/**
	 *  운행 통계 검색  조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getDrvStatBySearchWord (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		
		String fileLog = "";
		

		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getDrvStatSearch|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		param.setCheckTyp(10);// 날짜및 선택 파람 체크
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

			List<ResDrvStat> list = apiDriveDAO.usp_CustAPI_DrvStatBySearchWord_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setDrvStats(list); 
			}
			
			ResFrstLstDrvDt dt = apiDriveDAO.usp_CustAPI_FrstLstDrvDt_Req(param);
			if(dt != null){
				
				rtnObj.setFrstDrvDt(dt.getFrstDrvDt());
				
			}
			
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	
	/**
	 *  최초/최종 운행일  조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getFrstLstDrvDt (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		
		String fileLog = "";
		

		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getFrstLstDrvDt|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		param.setCheckTyp(11);// 필수값 체크
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

			ResFrstLstDrvDt dt = apiDriveDAO.usp_CustAPI_FrstLstDrvDt_Req(param);
			if(dt != null){
				
				rtnObj.setFrstDrvDt(dt.getFrstDrvDt());
				rtnObj.setLstDrvDt(dt.getLstDrvDt());
				
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	
	
	
	/**
	 *  차량 유지비 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getMntnCost (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		
		String fileLog = "";
		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getMntnCost|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		param.setCheckTyp(8);// 차량 유지비 체크
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

			List<ResMntnCost> list = apiDriveDAO.usp_CustAPI_MntnCost_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setMntnCosts(list); 
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	/**
	 *  범칙금 정보 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getPenalty (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		
		String fileLog = "";
		try {
			
		fileLog = param.toString();
		fileLog = fileLog.replaceAll("\\r\\n", "");
		fileLog = "|getPenalty|" + fileLog;
		
		param.setCheckTyp(0);//authkey 검증
		ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		param.setCheckTyp(9);// 차량 유지비 체크
		reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
		if(0 != reqCheck.getCode()){
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

			List<ResPanelty> list = apiDriveDAO.usp_CustAPI_LawPanelty_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setPenalties(list); 
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	/**
	 *  고장진단 코드 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getDiagCode (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);

		String fileLog = "";
		try {

			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|getDiagCode|" + fileLog;

			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
				param.setCorpId(reqCheck.getCorpId());
			}else{
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			param.setCheckTyp(12);// OBD 고장 진단 체크
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			List<ResDiagCode> list = apiDriveDAO.usp_CustAPI_DiagCode_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setDiagInfo(list);
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}


		return rtnObj;

	}
	
	/**
	 * 주행 정보 갱신
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getDrvUpd (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);

		String fileLog = "";
		try {

			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|getDrvUpd|" + fileLog;

			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
				param.setCorpId(reqCheck.getCorpId());
			}else{
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			param.setCheckTyp(13);// 주행 정보 갱신
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			int rowCnt = apiDriveDAO.usp_CustAPI_DrvUpd_Req(param);
			rtnObj.setRowCnt(rowCnt);
			
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		return rtnObj;

	}
	
	/**
	 *  GPS 궤적 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getGps (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);

		String fileLog = "";
		try {

			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|getDiagCode|" + fileLog;

			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
				param.setCorpId(reqCheck.getCorpId());
			}else{
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			param.setCheckTyp(14);
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}
			
			ResCarDist dist = apiDriveDAO.usp_CustAPI_CarDist_Req(param);
			if(dist != null){
				rtnObj.setLstDist(dist.getLstDist());
				rtnObj.setDistDt(dist.getDistDt());
			}
			
			List<ResGps> list = apiDriveDAO.usp_CustAPI_CarGps_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setGps(list); 
			}
			
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}


		return rtnObj;

	}
	
	/**
	 *  Hipass 요금 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getHipass (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);

		String fileLog = "";
		try {

			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|getDiagCode|" + fileLog;

			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
				param.setCorpId(reqCheck.getCorpId());
			}else{
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			param.setCheckTyp(15);
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			List<ResHipass> list = apiDriveDAO.usp_CustAPI_Hipass_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setHipassInfo(list);
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		return rtnObj;

	}
	
	
	/**
	 * 회원 정보 등록
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getMemberReg (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);

		String fileLog = "";
		try {

			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|getMemberReg|" + fileLog;

			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
				param.setCorpId(reqCheck.getCorpId());
			}else{
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			param.setCheckTyp(16);// 회원 정보 등록
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			int rowCnt = apiDriveDAO.usp_CustAPI_MemReg_Req(param);
			rtnObj.setRowCnt(rowCnt);
			
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		return rtnObj;

	}
	
	/**
	 * 운전자 정보 갱신(주행 정보)
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getDrvUpdDrvr (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);

		String fileLog = "";
		try {

			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|getDrvUpdDrvr|" + fileLog;

			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
				param.setCorpId(reqCheck.getCorpId());
			}else{
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			param.setCheckTyp(17);// 운전자 정보 갱신(주행 정보)
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			int rowCnt = apiDriveDAO.usp_CustAPI_DrvUpdDrvr_Req(param);
			rtnObj.setRowCnt(rowCnt);
			
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		return rtnObj;

	}
	
	/**
	 *  차량별 일간 통계 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getDrvDyStat (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);
		
		String fileLog = "";
		

		try {
			
			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|getDrvDyStat|" + fileLog;
		
			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
			param.setCorpId(reqCheck.getCorpId());
		}else{
			rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
			fileLog += "|"+rtnObj.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

			param.setCheckTyp(18);// 차량별 일간 통계
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			ResDrvDyStat dyStat = apiDriveDAO.usp_CustAPI_DrvDyStat_Req(param);
			if(dyStat != null){
			
				List<ResSafeStats> list = apiDriveDAO.usp_CustAPI_SafeStats_Req(param);
				if(list !=null && list.size() > 0){
					dyStat.setSafeStats(list);
				}
				rtnObj.setDrvDyStat(dyStat); 
			}
			
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}
		
		
		return rtnObj;
		
	}
	
	
	/**
	 *  예약 정보 조회
	 *
	 * @param ReqParam
	 * @return ResponseData
	 */
	public ResponseData  getRsvInfo (ReqParam param) {
		ResponseData rtnObj = new ResponseData(CODE_SUCCESS, CODE_SUCCESS_MESSAGE);

		String fileLog = "";
		try {

			fileLog = param.toString();
			fileLog = fileLog.replaceAll("\\r\\n", "");
			fileLog = "|getRsvInfo|" + fileLog;

			param.setCheckTyp(0);//authkey 검증
			ReqCheck reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(100 == reqCheck.getCode()){
				param.setCorpId(reqCheck.getCorpId());
			}else{
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			param.setCheckTyp(19);
			reqCheck = this.apiDriveDAO.usp_CustAPI_ReqValidation_Check(param);
			if(0 != reqCheck.getCode()){
				rtnObj = new ResponseData(reqCheck.getCode(), reqCheck.getMessage());
				fileLog += "|"+rtnObj.toString()+"|";
				logger.info("{}",fileLog);
				return rtnObj;
			}

			List<ResRsvInfo> list = apiDriveDAO.usp_CustAPI_RsvInfo_Req(param);
			if(list != null && list.size() > 0){
				rtnObj.setRsvs(list);
			}
		} catch (Exception e) {
			rtnObj = new ResponseData(CODE_FAIL, "Exception");//DB에 없으면 실패
			fileLog += "|"+rtnObj.toString()+"|"+e.toString()+"|";
			logger.info("{}",fileLog);
			return rtnObj;
		}

		return rtnObj;

	}
	
	
	
	/**
	 *  AuthKey 생성
	 *
	 * @param url
	 * @param param
	 * @return
	 */
	public String encAuthKey(String strObj) {
		
		logger.debug("encKey : {}", strObj);
		String encStr = "";
		try {
			
			encStr = AES.encrypt(strObj);
			encStr = URLEncoder.encode(encStr, "UTF-8");

			logger.debug("encStr : " + encStr);
			return encStr;
			
		} catch (Exception e) {
			logger.debug("Exception : " + e.toString());
			return "-1";
		}

	}
	
	/**
	 *  AuthKey 복호화
	 *	 corpId 추출
	 */
	public String decAuthKey(String authKey) {
		
		logger.debug("decKey : {}", authKey);
		String decStr = "";
		String[] authKeyArray;
		try {
			authKeyArray = authKey.split("\\?");
			//corpId 추출
			decStr = authKeyArray[0];

			logger.debug("decStr : " + decStr);
			return decStr;
			
		} catch (Exception e) {
			logger.debug("Exception : " + e.toString());
			return "-1";
		}

	}
}

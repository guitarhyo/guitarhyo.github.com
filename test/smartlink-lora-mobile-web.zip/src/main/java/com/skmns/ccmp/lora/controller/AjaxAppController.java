package com.skmns.ccmp.lora.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.common.util.SkmnsDateUtil;
import com.skmns.ccmp.lora.model.Agree;
import com.skmns.ccmp.lora.model.CodeSection;
import com.skmns.ccmp.lora.model.Drive;
import com.skmns.ccmp.lora.model.Paging;
import com.skmns.ccmp.lora.service.AjaxService;
import com.skmns.ccmp.lora.service.DriveHistService;

@Controller
@RequestMapping("/ajax/app")
public class AjaxAppController {
	private static final Logger logger = LoggerFactory.getLogger(AjaxAppController.class);
	private String jspPath = "/ajax/app";

	@Autowired
	private AjaxService ajaxService;

	@Autowired
	private HttpServletRequest request;
	@Autowired
	private SessionManager sessionManager;
	@Autowired
	private DriveHistService drvService;
	

	@RequestMapping(value = "/carreport/raceList")
	public String raceList() throws CommonResponseException {

		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		
		Drive drive = new Drive();
		drive.setDrvSts(1);
		drive.setRowNum(1);
		drive.setDrvrId(Integer.parseInt(memberId));
		List<Drive> result = this.drvService.getDriveList(drive);
		for (int i = 0; i < result.size(); i++) {
			int milliseconds = result.get(i).getDrvTime();
			int seconds = (int) (milliseconds  % 60) ;            //초
			int minutes = (int) (milliseconds / 60% 60);  //분
			int hours   = (int) (milliseconds / (60*60));//시
			String str = "";
			if(hours >0){
				str +=  ((hours < 10) ? "0"+hours : hours) + "시"; 
			}
			if(minutes >0){
				str +=  ((minutes < 10) ? "0"+minutes : minutes) + "분"; 
			}
				str +=  ((seconds < 10) ? "0"+seconds : seconds) + "초"; 
				
				result.get(i).setDrvTimeStr(str);
		}
		request.setAttribute("result", result);
		return this.jspPath + "/raceList";
	}
	
	@RequestMapping(value = "/carreport/fixRaceList")
	public String fixRaceList() throws CommonResponseException {

		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		
		Drive drive = new Drive();
		drive.setDrvSts(1);
		drive.setRowNum(1);
		drive.setDrvrId(Integer.parseInt(memberId));
		List<Drive> result = this.drvService.getFixDriveList(drive, new Paging());
		for (int i = 0; i < result.size(); i++) {
			int milliseconds = result.get(i).getDrvTime();
			int seconds = (int) (milliseconds  % 60) ;            //초
			int minutes = (int) (milliseconds / 60% 60);  //분
			int hours   = (int) (milliseconds / (60*60));//시
			String str = "";
			if(hours >0){
				str +=  ((hours < 10) ? "0"+hours : hours) + "시"; 
			}
			if(minutes >0){
				str +=  ((minutes < 10) ? "0"+minutes : minutes) + "분"; 
			}
				str +=  ((seconds < 10) ? "0"+seconds : seconds) + "초"; 
				
				result.get(i).setDrvTimeStr(str);
		}
		request.setAttribute("result", result);
		return this.jspPath + "/raceList";
	}

	@RequestMapping(value = "/carreport/raceSearch")
	public String raceSearch() throws CommonResponseException {
		this.request.setAttribute("searchStartDate", SkmnsDateUtil.getToday());
		this.request.setAttribute("searchEndDate",  SkmnsDateUtil.getToday());

		return this.jspPath + "/raceSearch";
	}

	/**
	 * <PRE>
	 * 설명 : 약관 동의 상세 조회
	 *
	 * <PRE>
	 *
	 * @param categoryId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/agree/info/{corpId}/{categoryId}")
	public String agreeDtl(@PathVariable final String corpId, @PathVariable final String categoryId) throws Exception {
		logger.debug("agreeDtl page start");

		Agree agree = new Agree();
		agree.setCorpId(corpId);
		agree.setCategoryId(categoryId);

		Agree result = this.ajaxService.selectTerms(agree);
		this.request.setAttribute("info", result);

		return this.jspPath + "/agreeDtl";
	}

	

	@RequestMapping("/codeSelect/findParentId")
	@ResponseBody
	public List<CodeSection> codeSelectFindByParentId(final CodeSection codeSection) throws CommonResponseException {
		return this.ajaxService.usp_CodeSectionValue_FindByParentId(codeSection);
	}
}

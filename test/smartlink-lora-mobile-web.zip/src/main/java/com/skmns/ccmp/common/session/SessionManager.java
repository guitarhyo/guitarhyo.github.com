package com.skmns.ccmp.common.session;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.skmns.ccmp.lora.model.Member;

@Component
public class SessionManager {

	@SuppressWarnings("unused")
	private static final Logger logger = LoggerFactory.getLogger(SessionManager.class);

	private static final String LOGIN_SESSION_NAME = "LOGIN_SESSION_NAME";
	private static final String LOGIN_SESSION_NAME_M = "LOGIN_SESSION_NAME_M";

	/**
	 * 로그인 여부
	 *
	 * <pre>
	 * 세션에 저장된 Member 객체에 userId가 존재하는지 확인한다
	 * </pre>
	 *
	 * @param request
	 * @return
	 */
	public boolean isLogin(final HttpServletRequest request) {
		return StringUtils.isNotEmpty(this.getMember(request).getUserId());
	}
	
	public boolean isMwebLogin(final HttpServletRequest request) {
		return StringUtils.isNotEmpty(this.getMwebMember(request).getUserId());
	}

	/**
	 * 세션에 저장된 회원 객체를 가져온다
	 *
	 * @param request
	 * @return
	 */
	public Member getMember(final HttpServletRequest request) {
		Member member = (Member) request.getSession().getAttribute(LOGIN_SESSION_NAME);
		if (member == null) {
			member = new Member();
		}

		return member;
	}
	
	public Member getMwebMember(final HttpServletRequest request) {
		Member member = (Member) request.getSession().getAttribute(LOGIN_SESSION_NAME_M);
		if (member == null) {
			member = new Member();
		}

		return member;
	}

	/**
	 * 세션에 회원 객체를 저장
	 *
	 * @param request
	 * @param member
	 */
	public void setMember(final HttpServletRequest request, final Member member) {
		request.getSession().setAttribute(LOGIN_SESSION_NAME, member);
	}
	
	public void setMwebMember(final HttpServletRequest request, final Member member) {
		request.getSession().setAttribute(LOGIN_SESSION_NAME_M, member);
	}


	/**
	 * 세션 제거
	 *
	 * @param request
	 */
	public void removeSession(final HttpServletRequest request) {
		request.getSession().removeAttribute(LOGIN_SESSION_NAME);
	}
	
	public void removeMwebSession(final HttpServletRequest request) {
		request.getSession().removeAttribute(LOGIN_SESSION_NAME_M);
	}

	/**
	 *
	 * @param request
	 * @return seconds
	 */
	public int getMaxInactiveInterval(final HttpServletRequest request) {
		return request.getSession().getMaxInactiveInterval();
	}

	public Member getLoginMember(final HttpServletRequest request) {
		Member member;
		if (this.isLogin(request)) { // 일반 사용자
			member = this.getMember(request);
		} else {
			member = new Member();
		}
		return member;
	}
	
	public Member getMwebLoginMember(final HttpServletRequest request) {
		Member member;
		if(this.isMwebLogin(request)){
			member = this.getMwebMember(request);
		} else {
			member = new Member();
		}
		return member;
	}
}

package com.skmns.ccmp.lora.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.skmns.ccmp.common.constant.ConstantCode4Application;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.util.SkmnsFileUtil;
import com.skmns.ccmp.lora.dao.MaintenanceReportDAO;
import com.skmns.ccmp.lora.model.Car;
import com.skmns.ccmp.lora.model.MaintenanceReport;

@Service
public class MaintenanceReportService {

	private static final Logger logger = LoggerFactory.getLogger(MaintenanceReportService.class);
	
	private ObjectMapper mapper = new ObjectMapper();

	@Autowired
	private MaintenanceReportDAO reportDao;

	@Autowired
	private MessageSourceAccessor msa;
	
	@Transactional
	public ObjectNode addReportInfo(final MaintenanceReport reportVO) throws CommonResponseException {
		ObjectNode jsonObject = mapper.createObjectNode();
		int mntncostId = this.reportDao.usp_CarMntnCostHst_Ins(reportVO);
		reportVO.setMntncostId(Integer.toString(mntncostId));

		String base64Imge = reportVO.getBase64Image();
		if (base64Imge != null && !"".equals(base64Imge)) {

			String uploadRoot = this.msa.getMessage("upload.root");
			String filePath = File.separator + "mntncost";
			String downloadRoot = this.msa.getMessage("download.report.rootpath");

			String imgPath = SkmnsFileUtil.tcmsUploadFileBase64(base64Imge, uploadRoot, filePath, downloadRoot, reportVO.getMntncostId());
			reportVO.setImgPath(imgPath);
			this.reportDao.usp_CarMntnCostHst_Upd(reportVO);
		}

		jsonObject.put(ConstantCode4Application.RESPONSE_CODE, "S");
		return jsonObject;
	}

	@Transactional
	public ObjectNode updateReportInfo(final MaintenanceReport reportVO) throws CommonResponseException {
		ObjectNode jsonObject = mapper.createObjectNode();
		String deletePath = reportVO.getDelFilePath();
		String base64Imge = reportVO.getBase64Image();
		String uploadRoot = this.msa.getMessage("upload.root");
		String imgPath = "";
		if (base64Imge != null && !"".equals(base64Imge)) {

			String filePath = File.separator + "mntncost";
			String downloadRoot = this.msa.getMessage("download.report.rootpath");

			imgPath = SkmnsFileUtil.tcmsUploadFileBase64(base64Imge, uploadRoot, filePath, downloadRoot, reportVO.getMntncostId());
			reportVO.setImgPath(imgPath);
		}

		this.reportDao.usp_CarMntnCostHst_Upd(reportVO);

		if (StringUtils.isNotEmpty(deletePath) && "".equals(reportVO.getImgPath())) {
			try {
				// /home/shares/tcms/uploads/images/mntncost
				logger.debug(uploadRoot + deletePath.substring(deletePath.indexOf("/mntncost")));

				File del = new File(uploadRoot + deletePath.substring(deletePath.indexOf("/mntncost")));
				boolean isDel = del.delete();
				logger.debug("{}", "" + isDel);
			} catch (Exception e) {
				logger.error(e.toString());
			}
		}

		jsonObject.put(ConstantCode4Application.RESPONSE_CODE, "S");
		return jsonObject;
	}

	@Transactional
	public ObjectNode deleteReportInfo(final MaintenanceReport reportVO) throws CommonResponseException {
		ObjectNode jsonObject = mapper.createObjectNode();
		this.reportDao.usp_CarMntnCostHst_Del(reportVO);
		jsonObject.put(ConstantCode4Application.RESPONSE_CODE, "S");
		return jsonObject;
	}

	/**
	 * 월별 차량유지비 통계 조회
	 *
	 * @param reportVo
	 * @return list=항목별 금액, total=총금액
	 * @throws CommonResponseException
	 */
	public Map<String, Object> selectItemCostList(final MaintenanceReport reportVo) throws CommonResponseException {
		reportVo.setSearchDate();
		reportVo.setPaybackSts(StringUtils.isNotEmpty(reportVo.getPaybackSts()) ? reportVo.getPaybackSts() : "-1");
		Map<String, Object> costItemInfo = new HashMap<>();
		List<MaintenanceReport> costItemList = this.reportDao.usp_CarMntnCostItemSumStat_Req(reportVo);
		BigDecimal totalCost = new BigDecimal(0);
		if (this.isValidReport(costItemList)) {
			for (MaintenanceReport r : costItemList) {
				totalCost = totalCost.add(r.getCost());
			}
		} else {
			costItemList = new ArrayList<>();
		}
		costItemInfo.put("list", costItemList);
		costItemInfo.put("total", totalCost);

		return costItemInfo;
	}



	public List<MaintenanceReport> selectCarList(final MaintenanceReport reportVo) throws CommonResponseException {
		reportVo.setSearchDate();
		reportVo.setPaybackSts(StringUtils.isNotEmpty(reportVo.getPaybackSts()) ? reportVo.getPaybackSts() : "-1");
		return this.reportDao.usp_CarMntnCostHst_Req(reportVo);
	}

	public MaintenanceReport selectCarDtl(final String maintaintId) throws CommonResponseException {
		MaintenanceReport report = new MaintenanceReport();
		report.setReqType("I");
		report.setReqId(maintaintId);
		List<MaintenanceReport> list = this.reportDao.usp_CarMntnCostDtl_Req(report);
		MaintenanceReport result = null;
		if (list != null && list.size() > 0) {
			result = list.get(0);
		}

		return result;
	}


	public MaintenanceReport selectCalculateCnt(final MaintenanceReport reportVo) throws CommonResponseException {
		return this.reportDao.usp_CarMntnCalcCnt_Req(reportVo);

	}

	public List<Car> searchCarNoList(final String carNo, final String corpId) {
		Map<String, String> searchMap = new HashMap<>();
		searchMap.put("corpId", corpId);
		searchMap.put("carNo", carNo);
		List<Car> searchCarList = this.reportDao.usp_CarSearchByKeyword_Req(searchMap);
		return searchCarList;
	}

	private boolean isValidReport(final List<MaintenanceReport> list) {
		return (list != null && list.size() > 0 && list.get(0).getCode() == null);
	}
	
	public Car selectCarInfo(final int carId) {
		return  this.reportDao.usp_Car_FindByID(carId);
	}
	
	public List<Map<String, Object>> selectCarMntnCostDate(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCostDate_Req(reportVO);
	}

	public List<Map<String, Object>> selectCarMntnCostDateCnt(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCostDateCnt_Req(reportVO);
	}

	public List<Map<String, Object>> selectCarMntnCostItem(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCostItem_Req(reportVO);
	}

	public List<Map<String, Object>> selectCarMntnCalcDistCnt(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCalcDistCnt_Req(reportVO);
	}

	public List<Map<String, Object>> selectCarMntnCalcDist(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCalcDist_Req(reportVO);
	}

	public List<Map<String, Object>> selectCarMntnCalcDistTotal(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCalcDistTotal_Req(reportVO);
	}

	public List<Map<String, Object>> selectCarMntnCalcHst(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCalcHst_Req(reportVO);
	}

	public List<Map<String, Object>> selectCarMntnCalcTotal(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCalcTotal_Req(reportVO);
	}

	public MaintenanceReport selectCarMntnCalcCnt(final MaintenanceReport reportVO) {
		return this.reportDao.usp_CarMntnCalcCnt_Req(reportVO);
	}
	
}

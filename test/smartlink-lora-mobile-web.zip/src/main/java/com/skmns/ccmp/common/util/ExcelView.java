package com.skmns.ccmp.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jxls.transformer.XLSTransformer;

import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.servlet.view.document.AbstractXlsxStreamingView;

public class ExcelView extends AbstractXlsxStreamingView {

	private static final String carMaintain = "/excel/carMaintainSample.xlsx";// 클래스패스에 있는 경로 실제 classes 밑에
	private static final String carCalculate = "/excel/carCalculateSample.xlsx";

	// http://syaku.tistory.com/301
	// http://greatkim91.tistory.com/72
	@Override
	protected void buildExcelDocument(final Map<String, Object> model, final Workbook workbook, final HttpServletRequest request,
			final HttpServletResponse response) throws Exception {

		OutputStream os = null;
		InputStream is = null;

		try {
			String fileName = "car";
			String templateType = (String) model.get("templateType");
			if ("maintain".equals(templateType)) {
				is = new ClassPathResource(carMaintain).getInputStream();
				fileName = "carMaintain";
			} else {
				is = new ClassPathResource(carCalculate).getInputStream();
				fileName = "carCalculate";
			}

			response.setHeader("Content-Type", "application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xlsx");

			os = response.getOutputStream();

			XLSTransformer transformer = new XLSTransformer();

			Workbook excel = transformer.transformXLS(is, model);
			excel.write(os);
			os.flush();

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		} finally {
			if (os != null) {
				try {
					os.close();
				} catch (IOException e) {
				}
			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
				}
			}
		}

	}

}

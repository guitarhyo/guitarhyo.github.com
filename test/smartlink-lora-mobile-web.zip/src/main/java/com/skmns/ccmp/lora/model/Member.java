package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.type.Alias;

@Alias(value = "Member")
public class Member extends CommonResult implements Serializable {

	private static final long serialVersionUID = 6624199960978829166L;

	// 고객사아이디
	private String corpId = "";
	// 회원 로그인 아이디
	private String userId = "";
	// 회원 로그인 비밀번호
	private String userPass = "";
	// 기존 비밀번호
	private String oldUserPass = "";
	// 회원명
	private String memberName = "";
	// 이메일
	private String email = "";
	// 회원구분(탈퇴대기,탈퇴회원,일반회원)
	private String gubun = "";
	// 휴대폰
	private String mobilePhone = "";
	// 본인인증여부
	private String isConfirm = "";
	// 부서명
	private String empPart = "";
	// 사번
	private String empNumber = "";
	// PushKey
	private String pushKey = "";
	// 모바일종류(Android/IOS)
	private String pushDevice = "";
	// 고객사명
	private String corpName = "";
	// MemberTableId
	private String memberId = "";
	// 생년월일
	private String birthDate = "";
	// 면허승인여부(0:미승인, 1:승인)
	private String licStatus = "";
	// 면허종류(1종,2종...)
	private String lcKind = "";
	// 면허암호화번호
	private String licEncNumber = "";
	// 면허등록일
	private String licCreatedt = "";
	// 면허갱신일
	private String licUpdatedt = "";
	// 면허번호
	private String licNumber = "";
	// 면허번호마스크
	private String licNumberMask = "";
	// 이용정지여부(0:이용가능, 1:이용중지)
	private String isStop = "";
	// 이용정지시작
	private String stopStartdt = "";
	// 이용정지종료
	private String stopEnddt = "";
	// 인증 번호
	private String authKey = "";
	// 메인카드 아이디
	private String mainCardId = "";
	// 카드 아이디
	private String creditCardId = "";
	// 탈퇴 사유
	private String unRegistComment = "";
	// 운전면허 종류
	private String licKind = "";
	// 팝업 닫기 공지팝업
	private String firstNotiYn = "N";
	// 팝업 닫기 튜토리얼 팝업
	private String firstCoachYn = "N";
	// 팝업 닫기 최초 한번 미결제자
	private String firstNofeeYn = "N";
	// 자동로그인 여부
	private String autoLogin = "N";
	// 로그인 여부
	private String isLoginYn = "N";
	// 탈퇴여부
	private String deleted = "0";
	// 메인카드 여부
	private String isMain;
	//os version
	private String osVersion="";
	//modelname
	private String modelName="";
	private String appName ="";
	
	
	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getOsVersion() {
		return osVersion;
	}

	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	/**
	 * @return the firstCoachYn
	 */
	public String getFirstCoachYn() {
		return firstCoachYn;
	}

	/**
	 * @param firstCoachYn the firstCoachYn to set
	 */
	public void setFirstCoachYn(String firstCoachYn) {
		this.firstCoachYn = firstCoachYn;
	}

	public String getCorpId() {
		return this.corpId;
	}

	/**
	 * @return the deleted
	 */
	public String getDeleted() {
		return this.deleted;
	}

	/**
	 * @param deleted
	 *            the deleted to set
	 */
	public void setDeleted(final String deleted) {
		this.deleted = deleted;
	}

	/**
	 * @return the isLoginYn
	 */
	public String getIsLoginYn() {
		return this.isLoginYn;
	}

	/**
	 * @param isLoginYn
	 *            the isLoginYn to set
	 */
	public void setIsLoginYn(final String isLoginYn) {
		this.isLoginYn = isLoginYn;
	}

	/**
	 * @return the licNumberMask
	 */
	public String getLicNumberMask() {
		return this.licNumberMask;
	}

	/**
	 * @param licNumberMask
	 *            the licNumberMask to set
	 */
	public void setLicNumberMask(final String licNumberMask) {
		this.licNumberMask = licNumberMask;
	}

	/**
	 * @return the firstNofeeYn
	 */
	public String getFirstNofeeYn() {
		return this.firstNofeeYn;
	}

	/**
	 * @param firstNofeeYn
	 *            the firstNofeeYn to set
	 */
	public void setFirstNofeeYn(final String firstNofeeYn) {
		this.firstNofeeYn = firstNofeeYn;
	}

	/**
	 * @return the autoLogin
	 */
	public String getAutoLogin() {
		return this.autoLogin;
	}

	/**
	 * @param autoLogin
	 *            the autoLogin to set
	 */
	public void setAutoLogin(final String autoLogin) {
		this.autoLogin = autoLogin;
	}

	/**
	 * @return the firstNotiYn
	 */
	public String getFirstNotiYn() {
		return this.firstNotiYn;
	}

	/**
	 * @param firstNotiYn
	 *            the firstNotiYn to set
	 */
	public void setFirstNotiYn(final String firstNotiYn) {
		this.firstNotiYn = firstNotiYn;
	}

	/**
	 * @return the licKind
	 */
	public String getLicKind() {
		return this.licKind;
	}

	/**
	 * @param licKind
	 *            the licKind to set
	 */
	public void setLicKind(final String licKind) {
		this.licKind = licKind;
	}

	/**
	 * @return the unRegistComment
	 */
	public String getUnRegistComment() {
		return this.unRegistComment;
	}

	/**
	 * @param unRegistComment
	 *            the unRegistComment to set
	 */
	public void setUnRegistComment(final String unRegistComment) {
		this.unRegistComment = unRegistComment;
	}

	/**
	 * @return the oldUserPass
	 */
	public String getOldUserPass() {
		return this.oldUserPass;
	}

	/**
	 * @param oldUserPass
	 *            the oldUserPass to set
	 */
	public void setOldUserPass(final String oldUserPass) {
		this.oldUserPass = oldUserPass;
	}

	/**
	 * @return the creditCardId
	 */
	public String getCreditCardId() {
		return this.creditCardId;
	}

	/**
	 * @param creditCardId
	 *            the creditCardId to set
	 */
	public void setCreditCardId(final String creditCardId) {
		this.creditCardId = creditCardId;
	}

	/**
	 * @return the mainCardId
	 */
	public String getMainCardId() {
		return this.mainCardId;
	}

	/**
	 * @param mainCardId
	 *            the mainCardId to set
	 */
	public void setMainCardId(final String mainCardId) {
		this.mainCardId = mainCardId;
	}

	/**
	 * @return the authKey
	 */
	public String getAuthKey() {
		return this.authKey;
	}

	/**
	 * @param authKey
	 *            the authKey to set
	 */
	public void setAuthKey(final String authKey) {
		this.authKey = authKey;
	}

	/**
	 * @return the corpName
	 */
	public String getCorpName() {
		return this.corpName;
	}

	/**
	 * @param corpName
	 *            the corpName to set
	 */
	public void setCorpName(final String corpName) {
		this.corpName = corpName;
	}

	/**
	 * @return the memberId
	 */
	public String getMemberId() {
		return this.memberId;
	}

	/**
	 * @param memberId
	 *            the memberId to set
	 */
	public void setMemberId(final String memberId) {
		this.memberId = memberId;
	}

	/**
	 * @return the birthDate
	 */
	public String getBirthDate() {
		return this.birthDate;
	}

	/**
	 * @param birthDate
	 *            the birthDate to set
	 */
	public void setBirthDate(final String birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * @return the licStatus
	 */
	public String getLicStatus() {
		return this.licStatus;
	}

	/**
	 * @param licStatus
	 *            the licStatus to set
	 */
	public void setLicStatus(final String licStatus) {
		this.licStatus = licStatus;
	}

	/**
	 * @return the lcKind
	 */
	public String getLcKind() {
		return this.lcKind;
	}

	/**
	 * @param lcKind
	 *            the lcKind to set
	 */
	public void setLcKind(final String lcKind) {
		this.lcKind = lcKind;
	}

	/**
	 * @return the licEncNumber
	 */
	public String getLicEncNumber() {
		return this.licEncNumber;
	}

	/**
	 * @param licEncNumber
	 *            the licEncNumber to set
	 */
	public void setLicEncNumber(final String licEncNumber) {
		this.licEncNumber = licEncNumber;
	}

	/**
	 * @return the licCreatedt
	 */
	public String getLicCreatedt() {
		return this.licCreatedt;
	}

	/**
	 * @param licCreatedt
	 *            the licCreatedt to set
	 */
	public void setLicCreatedt(final String licCreatedt) {
		this.licCreatedt = licCreatedt;
	}

	/**
	 * @return the licUpdatedt
	 */
	public String getLicUpdatedt() {
		return this.licUpdatedt;
	}

	/**
	 * @param licUpdatedt
	 *            the licUpdatedt to set
	 */
	public void setLicUpdatedt(final String licUpdatedt) {
		this.licUpdatedt = licUpdatedt;
	}

	/**
	 * @return the licNumber
	 */
	public String getLicNumber() {
		return this.licNumber;
	}

	/**
	 * @param licNumber
	 *            the licNumber to set
	 */
	public void setLicNumber(final String licNumber) {
		this.licNumber = licNumber;
	}

	/**
	 * @return the isStop
	 */
	public String getIsStop() {
		return this.isStop;
	}

	/**
	 * @param isStop
	 *            the isStop to set
	 */
	public void setIsStop(final String isStop) {
		this.isStop = isStop;
	}

	/**
	 * @return the stopStartdt
	 */
	public String getStopStartdt() {
		return this.stopStartdt;
	}

	/**
	 * @param stopStartdt
	 *            the stopStartdt to set
	 */
	public void setStopStartdt(final String stopStartdt) {
		this.stopStartdt = stopStartdt;
	}

	/**
	 * @return the stopEnddt
	 */
	public String getStopEnddt() {
		return this.stopEnddt;
	}

	/**
	 * @param stopEnddt
	 *            the stopEnddt to set
	 */
	public void setStopEnddt(final String stopEnddt) {
		this.stopEnddt = stopEnddt;
	}

	public void setCorpId(final String corpId) {
		this.corpId = corpId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(final String userId) {
		this.userId = userId;
	}

	public String getUserPass() {
		return this.userPass;
	}

	public void setUserPass(final String userPass) {
		this.userPass = userPass;
	}

	public String getMemberName() {
		return this.memberName;
	}

	public void setMemberName(final String memberName) {
		this.memberName = memberName;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public String getGubun() {
		return this.gubun;
	}

	public void setGubun(final String gubun) {
		this.gubun = gubun;
	}

	public String getMobilePhone() {
		return this.mobilePhone;
	}

	public void setMobilePhone(final String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getIsConfirm() {
		return this.isConfirm;
	}

	public void setIsConfirm(final String isConfirm) {
		this.isConfirm = isConfirm;
	}

	public String getEmpPart() {
		return this.empPart;
	}

	public void setEmpPart(final String empPart) {
		this.empPart = empPart;
	}

	public String getEmpNumber() {
		return this.empNumber;
	}

	public void setEmpNumber(final String empNumber) {
		this.empNumber = empNumber;
	}

	public String getPushKey() {
		return this.pushKey;
	}

	public void setPushKey(final String pushKey) {
		this.pushKey = pushKey;
	}

	public String getPushDevice() {
		return this.pushDevice;
	}

	public void setPushDevice(final String pushDevice) {
		this.pushDevice = pushDevice;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the isMain
	 */
	public String getIsMain() {
		return this.isMain;
	}

	/**
	 * @param isMain
	 *            the isMain to set
	 */
	public void setIsMain(final String isMain) {
		this.isMain = isMain;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Member [");
		builder.append("corpId=");
		builder.append(this.corpId);
		builder.append(", userId=");
		builder.append(this.userId);
		if (StringUtils.isNotBlank(this.userPass)) {
			builder.append(", userPass=");
			builder.append(this.userPass);
		}
		if (StringUtils.isNotBlank(this.oldUserPass)) {
			builder.append(", oldUserPass=");
			builder.append(this.oldUserPass);
		}
		if (StringUtils.isNotBlank(this.memberName)) {
			builder.append(", memberName=");
			builder.append(this.memberName);
		}
		if (StringUtils.isNotBlank(this.email)) {
			builder.append(", email=");
			builder.append(this.email);
		}

		if (StringUtils.isNotBlank(this.gubun)) {
			builder.append(", gubun=");
			builder.append(this.gubun);
		}
		if (StringUtils.isNotBlank(this.mobilePhone)) {
			builder.append(", mobilePhone=");
			builder.append(this.mobilePhone);
		}
		if (StringUtils.isNotBlank(this.isConfirm)) {
			builder.append(", isConfirm=");
			builder.append(this.isConfirm);
		}
		if (StringUtils.isNotBlank(this.empPart)) {
			builder.append(", empPart=");
			builder.append(this.empPart);
		}
		if (StringUtils.isNotBlank(this.empNumber)) {
			builder.append(", empNumber=");
			builder.append(this.empNumber);
		}
		if (StringUtils.isNotBlank(this.pushKey)) {
			builder.append(", pushKey=");
			builder.append(this.pushKey);
		}

		if (StringUtils.isNotBlank(this.pushDevice)) {
			builder.append(", pushDevice=");
			builder.append(this.pushDevice);
		}
		if (StringUtils.isNotBlank(this.corpName)) {
			builder.append(", corpName=");
			builder.append(this.corpName);
		}
		if (StringUtils.isNotBlank(this.memberId)) {
			builder.append(", memberId=");
			builder.append(this.memberId);
		}
		if (StringUtils.isNotBlank(this.birthDate)) {
			builder.append(", birthDate=");
			builder.append(this.birthDate);
		}
		if (StringUtils.isNotBlank(this.licStatus)) {
			builder.append(", licStatus=");
			builder.append(this.licStatus);
		}
		if (StringUtils.isNotBlank(this.lcKind)) {
			builder.append(", lcKind=");
			builder.append(this.lcKind);
		}

		if (StringUtils.isNotBlank(this.licEncNumber)) {
			builder.append(", licEncNumber=");
			builder.append(this.licEncNumber);
		}
		if (StringUtils.isNotBlank(this.licCreatedt)) {
			builder.append(", licCreatedt=");
			builder.append(this.licCreatedt);
		}
		if (StringUtils.isNotBlank(this.licUpdatedt)) {
			builder.append(", licUpdatedt=");
			builder.append(this.licUpdatedt);
		}
		if (StringUtils.isNotBlank(this.licNumber)) {
			builder.append(", licNumber=");
			builder.append(this.licNumber);
		}
		if (StringUtils.isNotBlank(this.isStop)) {
			builder.append(", isStop=");
			builder.append(this.isStop);
		}
		if (StringUtils.isNotBlank(this.stopStartdt)) {
			builder.append(", stopStartdt=");
			builder.append(this.stopStartdt);
		}
		if (StringUtils.isNotBlank(this.stopEnddt)) {
			builder.append(", stopEnddt=");
			builder.append(this.stopEnddt);
		}
		if (StringUtils.isNotBlank(this.authKey)) {
			builder.append(", authKey=");
			builder.append(this.authKey);
		}
		if (StringUtils.isNotBlank(this.mainCardId)) {
			builder.append(", mainCardId=");
			builder.append(this.mainCardId);
		}

		if (StringUtils.isNotBlank(this.creditCardId)) {
			builder.append(", creditCardId=");
			builder.append(this.creditCardId);
		}
		if (StringUtils.isNotBlank(this.unRegistComment)) {
			builder.append(", unRegistComment=");
			builder.append(this.unRegistComment);
		}
		if (StringUtils.isNotBlank(this.licKind)) {
			builder.append(", licKind=");
			builder.append(this.licKind);
		}
		if (StringUtils.isNotBlank(this.firstNotiYn)) {
			builder.append(", firstNotiYn=");
			builder.append(this.firstNotiYn);
		}
		if (StringUtils.isNotBlank(this.autoLogin)) {
			builder.append(", autoLogin=");
			builder.append(this.autoLogin);
		}

		builder.append("]");
		return builder.toString();
	}

}

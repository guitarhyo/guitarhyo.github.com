package com.skmns.ccmp.common.constant;

import java.io.File;

public class ConstantCode4Application {

	protected ConstantCode4Application() {
		throw new UnsupportedOperationException();
	}

	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String BLANK = "";

	public static final String INSERT_MODE = "I";
	public static final String UPDATE_MODE = "U";
	public static final String DELETE_MODE = "D";

	public static final String RESPONSE_CODE = "responseCode";
	public static final String RESPONSE_MESSAGE = "responseMessage";
	public static final String RESPONSE_DATA = "responseData";
	public static final String ADDITIONAL_MESSAGE = "additionalMessage";
	public static final String APP_NAME = "LORA";
	public static final String SERVICE_TYPE = "3"; // LORA SERVICE TYPE
	
	public static final String FILE_UPLOAD_LOCAL_PATH = "C:" + File.separator;
	public static final String FILE_UPLOAD_SERVER_PATH = File.separator + "tmp";
	
	public static final String SUBJECT_ENCODE_CHARSET = "euc-kr";

}

package com.skmns.ccmp.lora.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Push;

@Repository
public class PushDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = PushDAO.class.getPackage().getName() + ".";

	public CommonResult usp_Lora_Web_Push_GetStatus(String memberId) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Push_GetStatus", memberId);
	}

	public CommonResult usp_Lora_Web_Push_UpdateCheckDt(String memberId) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Push_UpdateCheckDt", memberId);
	}
	
	public List<Push> usp_Lora_Web_Push_FindByTerm(Map<String, Object> map) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_Lora_Web_Push_FindByTerm", map);
	}
	
	public List<Push> usp_Lora_Web_Push_GetNew(Push push) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_Lora_Web_Push_GetNew", push);
	}

}

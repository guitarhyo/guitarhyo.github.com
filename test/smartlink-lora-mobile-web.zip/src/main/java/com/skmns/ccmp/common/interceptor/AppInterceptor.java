package com.skmns.ccmp.common.interceptor;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.skmns.ccmp.common.constant.ConstantCode4Application;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.service.MemberService;

/**
 * AppInterceptor
 *
 * <pre>
 * App에서 WebView 와 API 요청시 사용되는 인터셉터
 * </pre>
 *
 * @author 201510077
 *
 */
public class AppInterceptor extends HandlerInterceptorAdapter {
	private static final Logger logger = LoggerFactory.getLogger(AppInterceptor.class);

	@Autowired
	private MemberService memberService;

	@Override
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler) throws CommonResponseException {
		Device device = (Device) request.getAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE);
		logger.debug("isMobile : {}", device.isMobile());
		logger.debug("getDevicePlatform : {}", device.getDevicePlatform());

		String appName = request.getHeader("App-Name");
		String appVer = request.getHeader("App-Version");
		String authKey = request.getHeader("AuthKey");
		String deviceId = request.getHeader("Device-ID");
		String devicePlatform = request.getHeader("Device-Platform");

		if ("null".equals(authKey)) {
			authKey = null;
			logger.debug("authKey is not null -> authKey is 'null' String.");
		}

		logger.info("#### Custom Headers ####");
		logger.info("# App-Name 		: {}", appName);
		logger.info("# App-Version 		: {}", appVer);
		logger.info("# AuthKey 			: {}", (StringUtils.isNotBlank(authKey)) ? StringUtils.left(authKey, 36) + "..." : "empty");
		logger.info("# Device-ID 		: {}", deviceId);
		logger.info("# Device-Platform 	: {}", devicePlatform);
		logger.info("########################");

		boolean isInApp = false;
		// isInApp 판단 기준
		if (StringUtils.isNotEmpty(appName) && appName.indexOf(ConstantCode4Application.APP_NAME) >= 0) {
			isInApp = true;
		}
		logger.debug("isInApp : {}", isInApp);

		Member member = new Member();
		if (StringUtils.isNotBlank(authKey)) {
			try {
				authKey = URLDecoder.decode(authKey, "UTF-8");
				logger.debug("authKey : {}", StringUtils.left(authKey, 36) + "...");
				member = this.memberService.decryptAuthKey(authKey);
			} catch (UnsupportedEncodingException e) {
				logger.warn(e.getMessage());
				e.printStackTrace();
			}
		}

		String backKeyUrl = request.getParameter("backKeyUrl");
		if (StringUtils.isNotBlank(backKeyUrl)) {// http 체크 후 도메인이 틀릴경우 메인으로
			try {
				logger.debug("@@@@@backKeyUrl 확인!!" + backKeyUrl);
				if (backKeyUrl.startsWith("http") || backKeyUrl.contains(".")) {
					if (!backKeyUrl.contains("lora")) {
						response.sendRedirect("/app/main");
						return false;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			backKeyUrl = "";
		}

		request.setAttribute("backKeyUrl", backKeyUrl);
		request.setAttribute("AUTH", member); // API 인증에 사용
		request.setAttribute("authKey", authKey);
		request.setAttribute("isInApp", isInApp);
		request.setAttribute("requestURI", request.getRequestURI());

		return true;
	}
}
// EOF
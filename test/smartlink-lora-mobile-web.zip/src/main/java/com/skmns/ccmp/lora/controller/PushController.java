package com.skmns.ccmp.lora.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.common.util.SkmnsDateUtil;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Paging;
import com.skmns.ccmp.lora.model.Push;
import com.skmns.ccmp.lora.service.PushService;

@Controller
@RequestMapping("/app")
public class PushController {
private String jspPath = "/app/push";
	
	private static final Logger logger = LoggerFactory.getLogger(PushController.class);
	
	@Autowired
	private HttpServletRequest request;
	/*
	 * TODO
	 * - 푸시메시지 리스트 조회 (날짜 검색)
	 * - 새로운 알림, 지난 알림 구분
	 * - 신규 알림 유무 체크 -> LNB에 new badge 표시
	 */
	@Autowired
	private PushService pushService;
	
	@Autowired
	private SessionManager sessionManager;
	
	/**
	 * <PRE>
	 * 설명 : 알림 페이지
	 *
	 * <PRE>
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/push/pushMsgList")
	public String pushMsgList() throws Exception {

		this.request.setAttribute("searchStartDate", SkmnsDateUtil.getDatewithGap("MONTH", -3,"yyyy-MM-dd"));
		this.request.setAttribute("searchEndDate",  SkmnsDateUtil.getToday());
		
		return this.jspPath + "/pushMsgList";
	}
	
	
	/**
	 * <PRE>
	 * 설명 : 알림 리스트
	 *
	 * <PRE>
	 *
	 * @return List<Push>
	 * @throws Exception
	 */
	@RequestMapping("/push/pushSearch")
	@ResponseBody
	public List<Push> search(final Push push, Paging paging) throws CommonResponseException {
		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		push.setMemberId(memberId);
		List<Push> result = this.pushService.getPushList(push,paging);
		logger.debug("result : {}", result);
		return result;
	}
	
	
	/**
	 * <PRE>
	 * 설명 : 알림 리스트
	 *
	 * <PRE>
	 *
	 * @return List<Push>
	 * @throws Exception
	 */
	@RequestMapping("/push/newPushList")
	@ResponseBody
	public List<Push> getNewPushList(final Push push) throws CommonResponseException {
		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		push.setMemberId(memberId);
		List<Push> result = this.pushService.getNewPushList(push);
		logger.debug("result : {}", result);
		return result;
	}
	
	
	
	/**
	 * <PRE>
	 * 설명 : 신규 알림 업데이트
	 *
	 * <PRE>
	 *
	 * @return CommonResult
	 * @throws Exception
	 */
	@RequestMapping("/push/updateCheckTime")
	@ResponseBody
	public CommonResult updateCheckTime() throws CommonResponseException {
		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		CommonResult result = this.pushService.updateCheckTime(memberId);
		logger.debug("result : {}", result);
		return result;
	}
	
	
	/**
	 * <PRE>
	 * 설명 : 신규 알림 조회
	 *
	 * <PRE>
	 *
	 * @return CommonResult
	 * @throws Exception
	 */
	@RequestMapping("/push/checkNewPush")
	@ResponseBody
	public CommonResult checkNewPush(@RequestParam(value = "memberId", required = false,defaultValue ="") final String memberId) throws CommonResponseException {
		//String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		CommonResult result = this.pushService.checkNewPush(memberId);
		logger.debug("result : {}", result);
		return result;
	}
	
	
	
	
}

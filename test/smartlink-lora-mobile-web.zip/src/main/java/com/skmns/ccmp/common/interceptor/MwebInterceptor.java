package com.skmns.ccmp.common.interceptor;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.protocol.CommonResultCode;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.service.MemberService;


public class MwebInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger(MwebInterceptor.class);
	private static final String STOP_WATCH_NAME = "mi.stopWatch";


	@Autowired
	SessionManager sessionManager;
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private MessageSourceAccessor msa;
	
	/**
	 * preHandle
	 *
	 * controller 호출전
	 */
	@Override
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)  {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		
		String appName = request.getHeader("App-Name");
		String appType = request.getHeader("App-Type");
		String appVer = request.getHeader("App-Version");
		String deviceId = request.getHeader("Device-ID");
		String devicePlatform = request.getHeader("Device-Platform");
		String osVersion = request.getHeader("os-version");
		String reqUri = request.getRequestURI();
		String reqUrl = request.getRequestURL().toString();
		String queryString = request.getQueryString();
		

		logger.info("########################  Custom Headers   ##############################");
		logger.info("# App-Name 		: {}", appName);
		logger.info("# App-Type 		: {}", appType);
		logger.info("# App-Version 		: {}", appVer);
		logger.info("# Device-ID 		: {}", deviceId);
		logger.info("# Device-Platform 	: {}", devicePlatform);
		logger.info("# os-version		: {}", osVersion);
		logger.info("# User-Agent     = {}", request.getHeader("user-agent"));
		logger.info("# Accept     = {}", request.getHeader("Accept"));
		logger.info("##################################################################");
		logger.info("########################  REQUEST   ##################################");
		/*logger.info("# Host           = {}", request.getRemoteHost());*/
		logger.info("# Method         = {}", request.getMethod());
		logger.info("# RequestURL     = {}", reqUrl);
		logger.info("# QueryString    = {}", queryString);
		logger.info("# ServerName     = {}", request.getServerName());
		logger.info("# RequestURI     = {}", reqUri);
		logger.info("# ContextPath    = {}", request.getContextPath());
		ObjectMapper mapper = new ObjectMapper();
		try {
			logger.info("# Parameters     = {}", mapper.writeValueAsString(request.getParameterMap()));
		} catch (JsonProcessingException e) {
		}
		logger.info("##################################################################");
		
		// Login URL SSL 적용
		Boolean useSSL = Boolean.valueOf(this.msa.getMessage("con.common.domain.useSSL"));
		String sslPort = this.msa.getMessage("con.common.domain.sslPort");
		String domain = this.msa.getMessage("con.common.domain");
		logger.debug("useSSL : {}, sslPort : {}, domain : {}", useSSL, sslPort, domain);
		
		try {
			if (useSSL && reqUri.startsWith("/mweb/login") && !request.isSecure()) {
				String url = "https://" + domain + ":" + sslPort + "/mweb/login" + "?" + request.getQueryString();
				response.sendRedirect(url);
				return false;
			} else if (request.isSecure() && isNonSslUrl(reqUri)) {
				logger.warn("Main menu was requested SSL !!!!! ");
				response.sendRedirect("http://" + domain + reqUri);
				return false;
			}
			
		} catch (IOException e1) {
			logger.warn("SSL redirect error: " + e1.getMessage(), e1);
		}

		if (!this.sessionManager.isMwebLogin(request)) {
			if (request.getHeader("Accept").indexOf(MediaType.APPLICATION_JSON_VALUE) > -1) {
				// Ajax 요청 처리
				logger.debug("has JSON header : {}", MediaType.APPLICATION_JSON_VALUE);
				throw new CommonResponseException(CommonResultCode.ERROR_NOT_ALLOWED_MEMBER);
			}
			
			try {
				response.sendRedirect("/mweb/login");
			} catch (IOException e) {
				logger.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}

		}

		request.setAttribute(STOP_WATCH_NAME, stopWatch);
		request.setAttribute("isLogin", this.sessionManager.isMwebLogin(request));
		request.setAttribute("member", this.sessionManager.getMwebMember(request));

		return true;
	}

	/**
	 * postHandle
	 *
	 * controller 호출 후 view 페이지 출력전
	 */
	@Override
	public void postHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler, final ModelAndView modelAndView) {
	}

	/**
	 * afterCompletion
	 *
	 * controller + view 페이지 모두 출력 후
	 */
	@Override
	public void afterCompletion(final HttpServletRequest request, final HttpServletResponse response, final Object handler, final Exception ex) {
		logger.info("afterCompletion start");
		
		StopWatch stopWatch = (StopWatch) request.getAttribute(STOP_WATCH_NAME);
		stopWatch.stop();
		// logger.info(request.getRequestURI() + " ....... All Request Complete Execute Time(include JSP) ....... : " + stopWatch.toString());
		// logger.info("....... Request Complete. Execute Time(include JSP) ....... : " + stopWatch.toString());
		logger.info(".... Request Complete(include JSP). Execute Time .... : " + stopWatch.toString() + "\t" + request.getRequestURI() + "\n");
		request.removeAttribute(STOP_WATCH_NAME);
	}

	private boolean isNonSslUrl(String reqUri) {
		try {
			String urlString = this.msa.getMessage("con.common.nonssl");
			String[] sslMappingUrl = urlString.split(";");
			for (String sslUrl : sslMappingUrl) {
				if (reqUri.startsWith(sslUrl)) {
					logger.info("SSL non-check url: {}", reqUri);
					return true;
				}
			}
		} catch (Exception e) {
			logger.warn("SSL non-check url property check error: {}", e.getMessage());
			return reqUri.startsWith("/app/main");
		}
		
		return false;
	}
	
}

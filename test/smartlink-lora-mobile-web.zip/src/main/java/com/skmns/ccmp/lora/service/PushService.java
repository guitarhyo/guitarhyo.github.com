package com.skmns.ccmp.lora.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.dao.PushDAO;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Paging;
import com.skmns.ccmp.lora.model.Push;

@Service
public class PushService {
	
	@Autowired
	private PushDAO pushDAO;
	
	/**
	 * 푸시(알림) 리스트 검색/조회
	 * 
	 * @param push
	 * <pre>
	 * memberId - 사용자 ID
	 * searchStartDate - 검색 시작일시
	 * searchEndDate - 검색 종료일시
	 * </pre>
	 * @return List<Push>
	 * @throws CommonResponseException
	 */
	public List<Push> getPushList(Push push, Paging paging) throws CommonResponseException {
		
		
		if (StringUtils.isEmpty(push.getSearchStartDate())) {
			push.setSearchStartDate("");
		}
		if (StringUtils.isEmpty(push.getSearchEndDate())) {
			push.setSearchEndDate("");
		}
		
		Map<String, Object> map = new HashMap<>();
		map.put("Push", push);
		map.put("Paging", paging != null ? paging : new Paging());
		
		return pushDAO.usp_Lora_Web_Push_FindByTerm(map);
	}
	
	
	/**
	 * 신규 푸시(알림) 리스트 검색/조회
	 * 
	 * @param 
	 * <pre>
	 * memberId - 사용자 ID
	 * </pre>
	 * @return List<Push>
	 * @throws CommonResponseException
	 */
	public List<Push> getNewPushList(Push push) throws CommonResponseException {
		if (StringUtils.isEmpty(push.getSearchStartDate())) {
			push.setSearchStartDate("");
		}
		if (StringUtils.isEmpty(push.getSearchEndDate())) {
			push.setSearchEndDate("");
		}
		
		return pushDAO.usp_Lora_Web_Push_GetNew(push);
	}
	
	/**
	 * 사용자의 마지막 알림 조회 시간 업데이트
	 * (알림 수신함 페이지 접근하면 실행)
	 * 
	 * @param memberId
	 * @return
	 * code 0:성공, -1:실패
	 * message 설명
	 * @throws CommonResponseException
	 */
	public CommonResult updateCheckTime(String memberId) throws CommonResponseException {
		return pushDAO.usp_Lora_Web_Push_UpdateCheckDt(memberId);
	}	

	/**
	 * 신규 알림 유무 조회 (LNB에서 New 뱃지 표시)
	 * 
	 * @param memberId
	 * @return
	 * code 1: 신규 알림 존재함, 0: 신규 알림 존재하지 않음
	 * message 설명
	 * @throws CommonResponseException
	 */
	public CommonResult checkNewPush(String memberId) throws CommonResponseException {
		return pushDAO.usp_Lora_Web_Push_GetStatus(memberId);
	}
}

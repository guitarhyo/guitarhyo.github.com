package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "Agree")
public class Agree implements Serializable {

	private static final long serialVersionUID = 415880783634967500L;

	private String corpId = "";
	private String categoryId = "";
	private String categoryIds = "";
	private String category = "";
	private String terms = "";

	public String getCorpId() {
		return this.corpId;
	}

	public void setCorpId(final String corpId) {
		this.corpId = corpId;
	}

	public String getCategoryId() {
		return this.categoryId;
	}

	public void setCategoryId(final String categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryIds() {
		return this.categoryIds;
	}

	public void setCategoryIds(final String categoryIds) {
		this.categoryIds = categoryIds;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(final String category) {
		this.category = category;
	}

	public String getTerms() {
		return this.terms;
	}

	public void setTerms(final String terms) {
		this.terms = terms;
	}

}

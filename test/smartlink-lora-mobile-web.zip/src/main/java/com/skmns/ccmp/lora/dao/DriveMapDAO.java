package com.skmns.ccmp.lora.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.DriveMap;

@Repository
public class DriveMapDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = DriveMapDAO.class.getPackage().getName() + ".";
	
	
	public  List<DriveMap> usp_Lora_DriveMap_SearchList(DriveMap param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_Lora_DriveMap_SearchList", param);
	}
	
	
	public  List<DriveMap> usp_Lora_DriveMap_LogGps_Req(DriveMap param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_Lora_DriveMap_LogGps_Req", param);
	}
	
	public  DriveMap usp_Lora_DriveMap_AuthKey_Check(DriveMap param) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_DriveMap_AuthKey_Check", param);
	}
	
}

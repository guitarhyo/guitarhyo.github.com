package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResDriveInfo")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResDriveInfo implements Serializable {

	private static final long serialVersionUID = -2226680203989838733L;
	
	
	private BigDecimal drvId; // 주행 ID
	private String carNum; //차 번호
	private String onDt; // 시동 ON 일시
	private Float onDist; 			// 운행 시작시 계기판 주행거리
	private String offDt; // 시동 OFF 일시
	private Float offDist; 			// 운행 종료시 계기판 주행거리
	
	private List<ResGps> gps;
	
	//안전운전
	private Integer safDrvIdx;    		// 안전 지수 	
	private Integer fstAccelIdx;	 	// 급가속 지수 
	private Integer fstDecelIdx;		// 급감속 지수 
	private Integer fstAccelCnt;	 	// 급가속 횟수 
	private Integer fstDecelCnt; 		// 급감속 횟수
	private Integer overSpdIdx;	 	// 과속 지수 
	private Integer overSpdTm;	 	// 과속 시간 
	private Integer fstAccelTm;	 	// 급가속 시간 
	private Integer fstDecelTm; 		// 급감속 시간

	//OBD
	private Float fuelAmt; 			//주유잔량
	private Float fuelUseAmt; 	//연료분사량
	private Integer oncnt;				//시동횟수
	private Integer movTm;					//운행시간
	private Integer idleTm;					//공회전시간
	
	
	public ResDriveInfo() {
		
	}


	public ResDriveInfo(BigDecimal drvId, String carNum, String onDt, Float onDist, String offDt, Float offDist, List<ResGps> gps, Integer safDrvIdx,
			Integer fstAccelIdx, Integer fstDecelIdx, Integer fstAccelCnt, Integer fstDecelCnt, Integer overSpdIdx, Integer overSpdTm,
			Integer fstAccelTm, Integer fstDecelTm, Float fuelAmt, Float fuelUseAmt, Integer oncnt, Integer movTm, Integer idleTm) {
		this.drvId = drvId;
		this.carNum = carNum;
		this.onDt = onDt;
		this.onDist = onDist;
		this.offDt = offDt;
		this.offDist = offDist;
		this.gps = gps;
		this.safDrvIdx = safDrvIdx;
		this.fstAccelIdx = fstAccelIdx;
		this.fstDecelIdx = fstDecelIdx;
		this.fstAccelCnt = fstAccelCnt;
		this.fstDecelCnt = fstDecelCnt;
		this.overSpdIdx = overSpdIdx;
		this.overSpdTm = overSpdTm;
		this.fstAccelTm = fstAccelTm;
		this.fstDecelTm = fstDecelTm;
		this.fuelAmt = fuelAmt;
		this.fuelUseAmt = fuelUseAmt;
		this.oncnt = oncnt;
		this.movTm = movTm;
		this.idleTm = idleTm;
	}


	public BigDecimal getDrvId() {
		return drvId;
	}


	public void setDrvId(BigDecimal drvId) {
		this.drvId = drvId;
	}


	public String getCarNum() {
		return carNum;
	}


	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}


	public String getOnDt() {
		return onDt;
	}


	public void setOnDt(String onDt) {
		this.onDt = onDt;
	}


	public Float getOnDist() {
		return onDist;
	}


	public void setOnDist(Float onDist) {
		this.onDist = onDist;
	}


	public String getOffDt() {
		return offDt;
	}


	public void setOffDt(String offDt) {
		this.offDt = offDt;
	}


	public Float getOffDist() {
		return offDist;
	}


	public void setOffDist(Float offDist) {
		this.offDist = offDist;
	}


	public List<ResGps> getGps() {
		return gps;
	}


	public void setGps(List<ResGps> gps) {
		this.gps = gps;
	}


	public Integer getSafDrvIdx() {
		return safDrvIdx;
	}


	public void setSafDrvIdx(Integer safDrvIdx) {
		this.safDrvIdx = safDrvIdx;
	}


	public Integer getFstAccelIdx() {
		return fstAccelIdx;
	}


	public void setFstAccelIdx(Integer fstAccelIdx) {
		this.fstAccelIdx = fstAccelIdx;
	}


	public Integer getFstDecelIdx() {
		return fstDecelIdx;
	}


	public void setFstDecelIdx(Integer fstDecelIdx) {
		this.fstDecelIdx = fstDecelIdx;
	}


	public Integer getFstAccelCnt() {
		return fstAccelCnt;
	}


	public void setFstAccelCnt(Integer fstAccelCnt) {
		this.fstAccelCnt = fstAccelCnt;
	}


	public Integer getFstDecelCnt() {
		return fstDecelCnt;
	}


	public void setFstDecelCnt(Integer fstDecelCnt) {
		this.fstDecelCnt = fstDecelCnt;
	}


	public Integer getOverSpdIdx() {
		return overSpdIdx;
	}


	public void setOverSpdIdx(Integer overSpdIdx) {
		this.overSpdIdx = overSpdIdx;
	}


	public Integer getOverSpdTm() {
		return overSpdTm;
	}


	public void setOverSpdTm(Integer overSpdTm) {
		this.overSpdTm = overSpdTm;
	}


	public Integer getFstAccelTm() {
		return fstAccelTm;
	}


	public void setFstAccelTm(Integer fstAccelTm) {
		this.fstAccelTm = fstAccelTm;
	}


	public Integer getFstDecelTm() {
		return fstDecelTm;
	}


	public void setFstDecelTm(Integer fstDecelTm) {
		this.fstDecelTm = fstDecelTm;
	}


	public Float getFuelAmt() {
		return fuelAmt;
	}


	public void setFuelAmt(Float fuelAmt) {
		this.fuelAmt = fuelAmt;
	}


	public Float getFuelUseAmt() {
		return fuelUseAmt;
	}


	public void setFuelUseAmt(Float fuelUseAmt) {
		this.fuelUseAmt = fuelUseAmt;
	}


	public Integer getOncnt() {
		return oncnt;
	}


	public void setOncnt(Integer oncnt) {
		this.oncnt = oncnt;
	}


	public Integer getMovTm() {
		return movTm;
	}


	public void setMovTm(Integer movTm) {
		this.movTm = movTm;
	}


	public Integer getIdleTm() {
		return idleTm;
	}


	public void setIdleTm(Integer idleTm) {
		this.idleTm = idleTm;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResDriveInfo [drvId=");
		builder.append(drvId);
		builder.append(", carNum=");
		builder.append(carNum);
		builder.append(", onDt=");
		builder.append(onDt);
		builder.append(", onDist=");
		builder.append(onDist);
		builder.append(", offDt=");
		builder.append(offDt);
		builder.append(", offDist=");
		builder.append(offDist);
		builder.append(", gps=");
		builder.append(gps);
		builder.append(", safDrvIdx=");
		builder.append(safDrvIdx);
		builder.append(", fstAccelIdx=");
		builder.append(fstAccelIdx);
		builder.append(", fstDecelIdx=");
		builder.append(fstDecelIdx);
		builder.append(", fstAccelCnt=");
		builder.append(fstAccelCnt);
		builder.append(", fstDecelCnt=");
		builder.append(fstDecelCnt);
		builder.append(", overSpdIdx=");
		builder.append(overSpdIdx);
		builder.append(", overSpdTm=");
		builder.append(overSpdTm);
		builder.append(", fstAccelTm=");
		builder.append(fstAccelTm);
		builder.append(", fstDecelTm=");
		builder.append(fstDecelTm);
		builder.append(", fuelAmt=");
		builder.append(fuelAmt);
		builder.append(", fuelUseAmt=");
		builder.append(fuelUseAmt);
		builder.append(", oncnt=");
		builder.append(oncnt);
		builder.append(", movTm=");
		builder.append(movTm);
		builder.append(", idleTm=");
		builder.append(idleTm);
		builder.append("]");
		return builder.toString();
	}
	

}

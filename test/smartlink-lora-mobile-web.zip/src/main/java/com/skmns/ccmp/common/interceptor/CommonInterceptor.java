package com.skmns.ccmp.common.interceptor;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skmns.ccmp.common.constant.ConstantCode4Application;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.service.MemberService;

/**
 * CommonInterceptor
 * 
 * @author sh.yu
 *
 */
public class CommonInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger(CommonInterceptor.class);
	private static final String STOP_WATCH_NAME = "mi.stopWatch";


	@Autowired
	SessionManager sessionManager;
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private MessageSourceAccessor msa;
	
	/**
	 * preHandle
	 *
	 * controller 호출전
	 */
	@Override
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)  {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		
		String appName = request.getHeader("App-Name");
		String appType = request.getHeader("App-Type");
		String appVer = request.getHeader("App-Version");
		String authKey = request.getHeader("AuthKey");
		String deviceId = request.getHeader("Device-ID");
		String devicePlatform = request.getHeader("Device-Platform");
		String osVersion = request.getHeader("os-version");
		String modelName = request.getHeader("Model-Name");
		
		String reqUri = request.getRequestURI();
		String reqUrl = request.getRequestURL().toString();
		String queryString = request.getQueryString();
		
		if ("null".equals(authKey)) {
			authKey = null;
			logger.debug("authKey is not null -> authKey is 'null' String.");
		}

		logger.info("########################  Custom Headers   ############################");
		logger.info("# App-Name 		: {}", appName);
		logger.info("# App-Type 		: {}", appType);
		logger.info("# App-Version 		: {}", appVer);
		logger.info("# AuthKey 			: {}", (StringUtils.isNotBlank(authKey)) ? StringUtils.left(authKey, 36) + "..." : "empty");
		logger.info("# Device-ID 		: {}", deviceId);
		logger.info("# Device-Platform 	: {}", devicePlatform);
		logger.info("# os-version		: {}", osVersion);
		logger.info("# Model-Name	: {}", modelName);
		logger.info("# User-Agent     = {}", request.getHeader("user-agent"));
		logger.info("# Accept     = {}", request.getHeader("Accept"));
		logger.info("######################");
		logger.info("########################  REQUEST   ############################");
		/*logger.info("# Host           = {}", request.getRemoteHost());*/
		logger.info("# Method         = {}", request.getMethod());
		logger.info("# RequestURL     = {}", reqUrl);
		logger.info("# QueryString    = {}", queryString);
		logger.info("# ServerName     = {}", request.getServerName());
		logger.info("# RequestURI     = {}", reqUri);
		logger.info("# ContextPath    = {}", request.getContextPath());
		ObjectMapper mapper = new ObjectMapper();
		try {
			logger.info("# Parameters     = {}", mapper.writeValueAsString(request.getParameterMap()));
		} catch (JsonProcessingException e) {
		}
		logger.info("################################################################");
		
		// Login URL SSL 적용
		Boolean useSSL = Boolean.valueOf(this.msa.getMessage("con.common.domain.useSSL"));
		String sslPort = this.msa.getMessage("con.common.domain.sslPort");
		String domain = this.msa.getMessage("con.common.domain");
		logger.debug("useSSL : {}, sslPort : {}, domain : {}", useSSL, sslPort, domain);
		
		try {
			if (useSSL && reqUri.startsWith("/app/login") && !request.isSecure()) {
				String url = "https://" + domain + ":" + sslPort + "/app/login" + "?" + request.getQueryString();
				response.sendRedirect(url);
				return false;
			} else if (request.isSecure() && isNonSslUrl(reqUri)) {
				logger.warn("Main menu was requested SSL !!!!! ");
				response.sendRedirect("http://" + domain + reqUri);
				return false;
			}
			
			//물류센터 API https 로만 들어오게 http 403리턴 
			if (useSSL && reqUri.startsWith("/cust") && !request.isSecure()) {
				mapper = new ObjectMapper();
				HashMap<String, Object> retMap = new HashMap<String, Object>();
				retMap.put("error", "403");
				  response.setContentType("application/json");
				  response.setStatus(HttpServletResponse.SC_FORBIDDEN);
				  response.getWriter().write(mapper.writeValueAsString(retMap));
				return false;
			}
		} catch (IOException e1) {
			logger.warn("SSL redirect error: " + e1.getMessage(), e1);
		}
		
		boolean isInApp = false;
		// isInApp 판단 기준
		if (StringUtils.isNotEmpty(appName) && appName.indexOf(ConstantCode4Application.APP_NAME) >= 0) {
			isInApp = true;
		}
		logger.debug("isInApp : {}", isInApp);
		
		String backKeyUrl = request.getParameter("backKeyUrl");
		Member member = new Member();
		if (StringUtils.isNotBlank(authKey)) {
			try {
				authKey = URLDecoder.decode(authKey, "UTF-8");
				logger.debug("authKey : {}", StringUtils.left(authKey, 36) + "...");
				member = this.memberService.decryptAuthKey(authKey);
			} catch (UnsupportedEncodingException e) {
				logger.warn(e.getMessage());
				e.printStackTrace();
			}
		}
		
		request.setAttribute("SSL_URL", "https://" + domain);
		request.setAttribute("AUTH", member); // API 인증에 사용
		request.setAttribute("backKeyUrl", backKeyUrl);
		request.setAttribute("appType", appType);
		request.setAttribute("authKey", authKey);
		request.setAttribute("isInApp", isInApp);
		request.setAttribute("requestURI", reqUri);
		request.setAttribute("devicePlatform", devicePlatform);
		request.setAttribute("osVersion", osVersion);

		request.setAttribute(STOP_WATCH_NAME, stopWatch);
		
		request.setAttribute("isLogin", this.sessionManager.isLogin(request));
		request.setAttribute("member", this.sessionManager.getMember(request));

		return true;
	}

	/**
	 * postHandle
	 *
	 * controller 호출 후 view 페이지 출력전
	 */
	@Override
	public void postHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler, final ModelAndView modelAndView) {
	}

	/**
	 * afterCompletion
	 *
	 * controller + view 페이지 모두 출력 후
	 */
	@Override
	public void afterCompletion(final HttpServletRequest request, final HttpServletResponse response, final Object handler, final Exception ex) {
		logger.info("afterCompletion start");
		
		StopWatch stopWatch = (StopWatch) request.getAttribute(STOP_WATCH_NAME);
		stopWatch.stop();
		// logger.info(request.getRequestURI() + " ....... All Request Complete Execute Time(include JSP) ....... : " + stopWatch.toString());
		// logger.info("....... Request Complete. Execute Time(include JSP) ....... : " + stopWatch.toString());
		logger.info(".... Request Complete(include JSP). Execute Time .... : " + stopWatch.toString() + "\t" + request.getRequestURI() + "\n");
		request.removeAttribute(STOP_WATCH_NAME);
	}

	private boolean isNonSslUrl(String reqUri) {
		try {
			String urlString = this.msa.getMessage("con.common.nonssl");
			String[] sslMappingUrl = urlString.split(";");
			for (String sslUrl : sslMappingUrl) {
				if (reqUri.startsWith(sslUrl)) {
					logger.info("SSL non-check url: {}", reqUri);
					return true;
				}
			}
		} catch (Exception e) {
			logger.warn("SSL non-check url property check error: {}", e.getMessage());
			return reqUri.startsWith("/app/main");
		}
		
		return false;
	}
	
}

package com.skmns.ccmp.lora.service;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skmns.ccmp.common.constant.ConstantCode4Application;
import com.skmns.ccmp.common.enc.AES2;
import com.skmns.ccmp.lora.dao.ApiDAO;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.model.api.JigCommand;
import com.skmns.ccmp.lora.model.api.ResponseRoot;

/**
 * @author 201610095
 *
 */
@Service
public class ApiService {
	
	private static final Logger logger = LoggerFactory.getLogger("API");
	private static final Logger jigLogger = LoggerFactory.getLogger("JIG_API");
	
	private static final String CODE_SUCCESS = "0";

	@Autowired
	private ApiDAO apiDAO;
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private MessageSourceAccessor msa;
	
	/**
	 * App 초기 진입
	 *
	 * @param request
	 * @return CommonResult
	 */
	public ResponseRoot init(final HttpServletRequest request) {
		ResponseRoot rr = new ResponseRoot("0", "success");

		// 버전 체크
		Map<String, String> appinfo = this.getAppLastVersion(request);
		if (appinfo != null) {
			rr.setAppInfo(appinfo);
		} else {
			rr = new ResponseRoot("-1", "조회된 버전 정보 없음");
		}

		return rr;
	}
	
	/**
	 * Phone의 MacAddress를 업데이트
	 *
	 * @param request
	 * @param reservation
	 * @return
	 */
	public ResponseRoot configMacAddress(String macAddr, String authKey) {
		
		CommonResult result = new CommonResult(CODE_SUCCESS, null);
		if (StringUtils.isBlank(authKey)) {
			result.setCode("-1");
			result.setMessage("사용자 인증키가 없습니다.");
			
			return result.toResponseRoot();
		}
		
		Member member = new Member();
		try {
			authKey = URLDecoder.decode(authKey, StandardCharsets.UTF_8.toString());
			logger.debug("authKey : {}", authKey);
			member = this.memberService.decryptAuthKey(authKey);
			if (member == null || StringUtils.isEmpty(member.getUserId())) {
				throw new Exception("Invalid AuthKey");
			}
		} catch (Exception e) {
			logger.warn(e.getMessage());
			result.setCode("-9");
			result.setMessage("시스템 오류 : " + e.getMessage());
		}
		
		if (StringUtils.isEmpty(macAddr)) {
			result.setCode("-8");
			result.setMessage("Mac 주소가 없습니다.");
		}
		
		if (StringUtils.equals(result.getCode(), CODE_SUCCESS)
				|| StringUtils.equals(result.getCode(), "1")) {
			Map<String, String> paramMap = new HashMap<String, String>();
			paramMap.put("macAddress", macAddr.replaceAll(":", ""));
			paramMap.put("userId", member.getUserId());
			result = apiDAO.usp_Lora_Web_PhoneMacAddr_Update(paramMap);

			logger.info("## /api/app/config/macaddr: {}", paramMap);
		}
		
		logger.info("## RESULT: {}", result);
		return result.toResponseRoot();
	}

	/**
	 * 버전 확인용
	 *
	 * @param request
	 * @return
	 */
	public Map<String, String> getAppLastVersion(final HttpServletRequest request) {
		Device device = (Device) request.getAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE);
		logger.debug("isMobile : {}", device.isMobile());
		logger.debug("getDevicePlatform : {}", device.getDevicePlatform());
		String deviceType = device.getDevicePlatform().toString();
		
		return this.apiDAO.usp_api_AppVersion_FindByLastVersion(deviceType, ConstantCode4Application.SERVICE_TYPE);
	}
	
	/**
	 * TODO 충격감지 여부 설정
	 * 
	 * @return
	 */
	public CommonResult configDetectionImpact() {
//		Member m = memberService.getMemberInfo(member);
//		Map<String,String> param = new HashMap<String, String>();
//		param.put("controlType", "3");
//		param.put("bluetoothRequestType", "1");
//		param.put("macAddr", macAddr);
//		
//		this.callAPI("",param);
		return new CommonResult("0", "OK");
	}
	
	
	/**
	 * API bridge 서버 호출
	 *
	 * @param url
	 * @param param
	 * @return
	 */
	private String callAPI(final String url, final Map<String,String> param) {
		ObjectMapper mapper = new ObjectMapper();
		Map<String,String> ret = new HashMap<String,String>();
		String code = "";
		logger.info("################ callAPI : {}", url);
		logger.info("params : {}", param.toString());
		String encKey = this.msa.getMessage("con.api.encrypt.key");
		String encStr;

		logger.debug("encKey : {}", encKey);
		try {
			encStr = mapper.writeValueAsString(param);
			encStr = AES2.encrypt(encStr, encKey);
			encStr = URLEncoder.encode(encStr, "UTF-8");

			RestTemplate restTemplate = new RestTemplate();
			String res = restTemplate.postForObject(url, encStr, String.class);
			logger.debug("res : " + res);

			// 리턴값 set
			ret = mapper.readValue(res, new TypeReference<Map<String, String>>(){});
			code = ret.get("code");
		} catch (Exception e) {
			logger.debug("Exception : " + e.toString());
			return "-1";
		}

		return code;
	}
	
	/**
	 * JIG Util 로깅 
	 *
	 * @param jigCommand
	 * @param reservation
	 * @return
	 */
	public ResponseRoot addJigCmdLog(final JigCommand jigCommand) {
		CommonResult result = new CommonResult(CODE_SUCCESS, null);
		result = apiDAO.usp_Lora_Web_Jig_LogCmd_Ins(jigCommand);
		jigLogger.info("## RESULT: {}", result);
		
		return result.toResponseRoot();
	}
}

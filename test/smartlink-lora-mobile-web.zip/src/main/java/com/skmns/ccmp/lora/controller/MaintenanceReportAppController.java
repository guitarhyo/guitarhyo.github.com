package com.skmns.ccmp.lora.controller;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.skmns.ccmp.common.constant.ConstantCode4Application;
import com.skmns.ccmp.common.enc.AES;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.common.util.SkmnsDateUtil;
import com.skmns.ccmp.lora.model.Car;
import com.skmns.ccmp.lora.model.CodeSection;
import com.skmns.ccmp.lora.model.Drive;
import com.skmns.ccmp.lora.model.MaintenanceReport;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.service.AjaxService;
import com.skmns.ccmp.lora.service.DriveHistService;
import com.skmns.ccmp.lora.service.MaintenanceReportService;

@Controller
@RequestMapping("/app")
public class MaintenanceReportAppController {
	
	private String jspPath = "/app/carreport";
	
	@Autowired
	private HttpServletRequest request;

	@Autowired
	private SessionManager sessionManager;

	@Autowired
	private AjaxService commonService;

	@Autowired
	private MaintenanceReportService maintenanceReportService;

	@Autowired
	private MessageSourceAccessor msa;
	
	@Autowired
	private DriveHistService drvService;

	private static final String STR_DOT = ".";
	private static final String STR_EXTENSION = "jpg";
	private static final String MNTNCOST_TYPE = "MNTNCOST_TYPE";

	private static final Logger logger = LoggerFactory.getLogger(MaintenanceReportAppController.class);
	
	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * <PRE>
	 * 설명 : 차계부 페이지.carMaintainReport
	 *
	 * <PRE>
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/carreport/main")
	public String carreportmain(@RequestParam(value = "useDt", required = false, defaultValue = "") String useDt) throws Exception {
		if (StringUtils.isNotEmpty(useDt)) {
			useDt = useDt.substring(0, 4) + "년" + useDt.substring(4, 6) + "월";
			this.request.setAttribute("useDt", useDt);
		}
		
		return this.jspPath + "/main";
	}

	@RequestMapping(value = "/carreport/carList")
	@ResponseBody
	public ObjectNode carreportlist(@RequestParam(value = "currPage", required = false, defaultValue = "1") final String currPage) throws Exception {
		ObjectNode jsonObject = mapper.createObjectNode();
		MaintenanceReport maintenanceReportVO = new MaintenanceReport();
		Member loginVO = this.sessionManager.getMember(this.request);
		maintenanceReportVO.setReqId(loginVO.getMemberId());

		List<MaintenanceReport> carList = this.maintenanceReportService.selectCarList(maintenanceReportVO);
		
		jsonObject.set("carList", mapper.valueToTree(carList));

		return jsonObject;
	}

	@RequestMapping(value = "/carreport/carListDate")
	@ResponseBody
	public ObjectNode carListDate(final MaintenanceReport maintenanceReportVO) throws Exception {
		ObjectNode jsonObject = mapper.createObjectNode();

		if (StringUtils.isEmpty(maintenanceReportVO.getUseDt())) {
			maintenanceReportVO.setUseDt(SkmnsDateUtil.Date2String("yyyyMM"));
		}

		Member loginVO = this.sessionManager.getMember(this.request);
		maintenanceReportVO.setReqId(loginVO.getMemberId());
		maintenanceReportVO.setMemberId(loginVO.getMemberId());
		maintenanceReportVO.setSearchStartDt("");
		maintenanceReportVO.setSearchEndDt("");

		Map<String, Object> totalCostInfo = this.maintenanceReportService.selectItemCostList(maintenanceReportVO);

		@SuppressWarnings("unchecked")
		List<MaintenanceReport> reportList = (List<MaintenanceReport>) totalCostInfo.get("list");

		if (reportList != null && reportList.size() > 0) {
			BigDecimal totalCost = (BigDecimal) totalCostInfo.get("total");
			jsonObject.put("totalPrice", totalCost);
		} else {
			jsonObject.put("totalPrice", 0);
		}
		jsonObject.set("reportList", mapper.valueToTree(reportList));

		List<MaintenanceReport> carList = this.maintenanceReportService.selectCarList(maintenanceReportVO);
		jsonObject.set("carList", mapper.valueToTree(carList));

		return jsonObject;
	}

	/**
	 * <PRE>
	 * 설명 : 차계부 차량유지비 관리 등록 페이지.
	 *
	 * <PRE>
	 *
	 * @return
	 * @throws CommonResponseException
	 */
	@RequestMapping(value = "/carreport/regPage")
	public String regPage() throws Exception {

		CodeSection commonCodeVO = new CodeSection(MNTNCOST_TYPE, "0");
		this.request.setAttribute("categoryType", this.commonService.usp_api_CodeSectionValueBySection(commonCodeVO));

		String nowDate = SkmnsDateUtil.Date2String("yyyyMMddHHmmss");
		nowDate = nowDate.substring(0, 4) + "년" + nowDate.substring(4, 6) + "월" + nowDate.substring(6, 8) + "일";
		this.request.setAttribute("nowDate", nowDate);

		return this.jspPath + "/carMaintainReg";
	}

	@RequestMapping(value = "/carreport/{driveId}/raceReg")
	public String regDriveInfo(@PathVariable final String driveId) throws Exception {
		CodeSection commonCodeVO = new CodeSection(MNTNCOST_TYPE, "0");
		this.request.setAttribute("categoryType", this.commonService.usp_api_CodeSectionValueBySection(commonCodeVO));

		Drive drive= drvService.getDriveInfo(Integer.parseInt(driveId));

		String onDt = drive.getOnDt();
		if(onDt != null && onDt != ""){
			onDt =  SkmnsDateUtil.getPattern(onDt, "yyyy-MM-dd HH:mm:ss.SSS", "yyyy년MM월dd일");
		}else{
			onDt = SkmnsDateUtil.Date2String("yyyy년MM월dd일");
		}

		this.request.setAttribute("raceDtl", drive);
		this.request.setAttribute("nowDate", onDt);

		return this.jspPath + "/carMaintainReg";
	}

	@RequestMapping(value = "/carreport/reg")
	@ResponseBody
	public ObjectNode reg(final MaintenanceReport maintenanceReportVO) throws CommonResponseException {
		ObjectNode jsonObject = mapper.createObjectNode();

		Member loginVO = this.sessionManager.getMember(this.request);
		maintenanceReportVO.setRegId(loginVO.getMemberId());
		maintenanceReportVO.setCorpId(loginVO.getCorpId());
		maintenanceReportVO.setMemberId(loginVO.getMemberId());
		maintenanceReportVO.setItemId(maintenanceReportVO.getItemCd());
		maintenanceReportVO.setItemDtlId(maintenanceReportVO.getItemDtl());
		
		try {
			if ("Y".equals(maintenanceReportVO.getCalculateYn())) {
				maintenanceReportVO.setPaybackSts("1");
			} else {
				maintenanceReportVO.setPaybackSts("0");
			}

			jsonObject = this.maintenanceReportService.addReportInfo(maintenanceReportVO);
		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put(ConstantCode4Application.RESPONSE_CODE, "F");
		}

		return jsonObject;
	}

	@RequestMapping(value = "/carreport/{maintainId}/dtlPage")
	public String dtlPage(@PathVariable final String maintainId) throws Exception {

		CodeSection commonCodeVO = new CodeSection(MNTNCOST_TYPE, "0");
		this.request.setAttribute("categoryType", this.commonService.usp_api_CodeSectionValueBySection(commonCodeVO));

		MaintenanceReport maintenanceReportVO = new MaintenanceReport();
		maintenanceReportVO = this.maintenanceReportService.selectCarDtl(maintainId);

		String useDt = maintenanceReportVO.getUseDt();

		useDt = useDt.replaceAll("\\-", "");
		this.request.setAttribute("nowDate", useDt.substring(0, 4) + "년" + useDt.substring(4, 6) + "월" + useDt.substring(6, 8) + "일");

		this.request.setAttribute("maintainId", maintainId);
		this.request.setAttribute("carDtl", maintenanceReportVO);

		this.request.setAttribute("viewDtl", "Y");

		return this.jspPath + "/carMaintainDtl";
	}

	@RequestMapping(value = "/carreport/update")
	@ResponseBody
	public ObjectNode update(final MaintenanceReport maintenanceReportVO) throws CommonResponseException {
		ObjectNode jsonObject = mapper.createObjectNode();
		Member loginVO = this.sessionManager.getMember(this.request);
		maintenanceReportVO.setMemberId(loginVO.getMemberId());
		maintenanceReportVO.setUpdId(loginVO.getMemberId());
		maintenanceReportVO.setCorpId(loginVO.getCorpId());
		maintenanceReportVO.setMemberId(loginVO.getMemberId());
		maintenanceReportVO.setItemId(maintenanceReportVO.getItemCd());
		maintenanceReportVO.setItemDtlId(maintenanceReportVO.getItemDtl());

		try {
			if ("Y".equals(maintenanceReportVO.getCalculateYn())) {
				maintenanceReportVO.setPaybackSts("1");
			} else {
				maintenanceReportVO.setPaybackSts("0");
			}

			jsonObject = this.maintenanceReportService.updateReportInfo(maintenanceReportVO);

		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put(ConstantCode4Application.RESPONSE_CODE, "F");
		}

		return jsonObject;
	}

	@RequestMapping(value = "/carreport/delete")
	@ResponseBody
	public ObjectNode deleteReportInfo(final MaintenanceReport maintenanceReportVO) throws CommonResponseException {
		ObjectNode jsonObject = mapper.createObjectNode();
		Member loginVO = this.sessionManager.getMember(this.request);
		maintenanceReportVO.setMemberId(loginVO.getMemberId());
		try {

			jsonObject = this.maintenanceReportService.deleteReportInfo(maintenanceReportVO);

		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put(ConstantCode4Application.RESPONSE_CODE, "F");
		}

		return jsonObject;
	}

	@RequestMapping(value = "/carreport/mainCalculate")
	public String mainCalculate() throws Exception {

		String nowDate = SkmnsDateUtil.Date2String("yyyyMM");
		nowDate = nowDate.substring(0, 4) + "년" + nowDate.substring(4, 6) + "월";
		this.request.setAttribute("nowDate", nowDate);

		return this.jspPath + "/mainCalculate";
	}

	@RequestMapping(value = "/carreport/maintainCalculate")
	@ResponseBody
	public ObjectNode selectMaintainCalculate(final MaintenanceReport maintenanceReportVO) throws CommonResponseException {
		ObjectNode jsonObject = mapper.createObjectNode();

		String memberId = this.sessionManager.getMember(this.request).getMemberId();
		maintenanceReportVO.setMemberId(memberId);
		jsonObject.set("maintainList", mapper.valueToTree(this.maintenanceReportService.selectCarMntnCalcHst(maintenanceReportVO)));
		jsonObject.set("maintainTotal", mapper.valueToTree(this.maintenanceReportService.selectCarMntnCalcTotal(maintenanceReportVO)));

		jsonObject.set("kmList", mapper.valueToTree(this.maintenanceReportService.selectCarMntnCalcDist(maintenanceReportVO)));
		jsonObject.set("kmTotal", mapper.valueToTree(this.maintenanceReportService.selectCarMntnCalcDistTotal(maintenanceReportVO)));

		jsonObject.set("calculateCnt", mapper.convertValue(this.maintenanceReportService.selectCalculateCnt(maintenanceReportVO), JsonNode.class));

		return jsonObject;

	}
	
	
	@RequestMapping(value = "/carreport/carKmCalculate")
	@ResponseBody
	public ObjectNode selectCarKmCalculate(final MaintenanceReport maintenanceReportVO) throws CommonResponseException {
		ObjectNode jsonObject = mapper.createObjectNode();
		String memberId = this.sessionManager.getMember(this.request).getMemberId();
		maintenanceReportVO.setMemberId(memberId);
		
		jsonObject.set("kmList", mapper.valueToTree(this.maintenanceReportService.selectCarMntnCalcDist(maintenanceReportVO)));

		jsonObject.set("calculateCnt", mapper.convertValue(this.maintenanceReportService.selectCalculateCnt(maintenanceReportVO), JsonNode.class));

		
		return jsonObject;
	}



	@RequestMapping(value = "/carreport/searchCarNoList")
	@ResponseBody
	public List<Car> searchCarNoList(@RequestParam(value = "searchWord", required = false, defaultValue = "") final String searchWord)
			throws CommonResponseException {
		List<Car> list = null;
		if (this.sessionManager.isLogin(this.request)) {
			String corpId = this.sessionManager.getMember(this.request).getCorpId();
			list = this.maintenanceReportService.searchCarNoList(searchWord, corpId);
		}
		return list;
	}
	
	@RequestMapping(value = "/carreport/excelEnc")
	@ResponseBody
	public ObjectNode reportExcelEncParam(@RequestParam(value = "yyyyMM", required = false, defaultValue = "") final String yyyyMM,
			@RequestParam(value = "paybackSts", required = false, defaultValue = "") final String paybackSts) throws Exception {
		ObjectNode jsonObject = mapper.createObjectNode();
		jsonObject.set("retParam", mapper.convertValue("", JsonNode.class));
		try {
			Map<String, String> map = new HashMap<>();
			String memberId = this.sessionManager.getMember(this.request).getMemberId();

			Date date = new Date();
			long time = date.getTime();
			map.put("memberId", memberId);
			map.put("yyyyMM", yyyyMM);
			map.put("paybackSts", paybackSts);
			map.put("downloadTime", String.valueOf(time));

			String jsonString =  mapper.convertValue(map,JsonNode.class).toString();
			String aesenc = AES.encrypt(jsonString);

			String urlenc = URLEncoder.encode(aesenc, "UTF-8");
			// urlenc = urlenc.replaceAll("%20", "%2B");
			if (urlenc != null && !"".equals(urlenc)) {
				jsonObject.set("retParam", mapper.convertValue(urlenc, JsonNode.class));
				logger.debug(urlenc);
			}
		} catch (Exception e) {
			logger.error("reportExcelEncParam {}", e.toString());
		}

		return jsonObject;
	}
	

}

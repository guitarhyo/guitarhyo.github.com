package com.skmns.ccmp.common.enc;

import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * AES2
 *
 * <pre>
 * API 서버와 암호화를 맞추기 위해 추가된 class.
 * ivBytes 를 별도로 사용하는 것과 key를 동적으로 사용하는것 외에는 AES.java와 동일함
 * </pre>
 *
 * @author 201510077
 *
 */
public class AES2 {
	private static final String ALGORITHM = "AES";
	private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
	// private static final String KEY = "SkMnS00000000000";

	private static byte[] ivBytes = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

	protected AES2() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 복호화
	 *
	 * @param encStr
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String decrypt(final String encStr, final String key) throws Exception {
		byte[] textBytes = Base64.decodeBase64(encStr);

		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(key.getBytes("UTF-8"), ALGORITHM);
		Cipher cipher = Cipher.getInstance(TRANSFORMATION);

		cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
		return new String(cipher.doFinal(textBytes), "UTF-8");
	}

	/**
	 * 암호화
	 *
	 * @param planText
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String encrypt(final String planText, final String key) throws Exception {
		byte[] textBytes = planText.getBytes("UTF-8");

		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(key.getBytes("UTF-8"), ALGORITHM);
		Cipher cipher = Cipher.getInstance(TRANSFORMATION);

		cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
		return Base64.encodeBase64String(cipher.doFinal(textBytes));
	}

}

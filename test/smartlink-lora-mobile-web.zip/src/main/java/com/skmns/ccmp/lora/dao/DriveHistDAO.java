package com.skmns.ccmp.lora.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.Car;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Drive;

@Repository
public class DriveHistDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = DriveHistDAO.class.getPackage().getName() + ".";
	
	public List<Drive> usp_Lora_Web_Drive_Summ(int memberId) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_Lora_Web_Drive_Summ", memberId);
	}
	
	public List<Drive> usp_Lora_Web_Drive_FindByTerm(Map<String, Object> map) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_Lora_Web_Drive_FindByTerm", map);
	}
	
	public List<Drive> usp_Lora_Web_Drive_FindByTerm_Fix(Map<String, Object> map) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_Lora_Web_Drive_FindByTerm_Fix", map);
	}
	
	public Drive usp_Lora_Web_Drive_FindById(int driveId) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Drive_FindById", driveId);
	}
	
	public CommonResult usp_Lora_Web_Drive_Update(Drive drvie) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Drive_Update", drvie);
	}
	
	public Drive usp_Lora_Web_Drive_FindLatest(int memberId) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Drive_FindLatest", memberId);
	}
	
	public CommonResult usp_Lora_Web_Drive_GetStatus(int memberId) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Drive_GetStatus", memberId);
	}

	public CommonResult usp_Lora_Web_Drive_UpdateAddr(Drive drive) {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Drive_UpdateAddr", drive);
	}
	
	public CommonResult usp_Lora_Web_PhoneReg_Ins(Map<String, Object> map) {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_PhoneReg_Ins", map);
	}
	
	public int usp_Car_Fix_Cnt(String userId) {
		return this.sqlSession.selectOne(NS + "usp_Car_Fix_Cnt", userId);
	}
	
	public List<Car> usp_CarSearchByKeyword_Fix_Req(Map<String, Object> map) {
		return this.sqlSession.selectList(NS + "usp_CarSearchByKeyword_Fix_Req", map);
	}
	
	public Drive usp_Lora_Web_Drive_CarLatestDist(Map<String, Object> map) {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Drive_CarLatestDist", map);
	}
	public CommonResult usp_Lora_Web_Drive_Create(Drive drive) {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Drive_Create", drive);
	}
	public CommonResult usp_Lora_Web_Drive_Update_Fix(Drive drive) {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Drive_Update_Fix", drive);
	}
	
}

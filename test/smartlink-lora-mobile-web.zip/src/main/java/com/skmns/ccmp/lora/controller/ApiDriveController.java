package com.skmns.ccmp.lora.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.lora.model.api.ReqParam;
import com.skmns.ccmp.lora.model.api.ResponseDrv;
import com.skmns.ccmp.lora.model.api.ResponseData;
import com.skmns.ccmp.lora.service.ApiDriveService;

@Controller
@RequestMapping(value="/cust", method = RequestMethod.POST)
public class ApiDriveController {
	private static final Logger logger = LoggerFactory.getLogger(ApiDriveController.class);

	@Autowired
	private MessageSourceAccessor msa;

	@Autowired
	private ApiDriveService apiDriveService;


	
	/**
	 * 인증키 생성
	 *
	 * @return
	 */
	@RequestMapping(value="/reqAuthKey", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseDrv authkeyInit(@RequestBody ReqParam param) {
		logger.debug("@@@@"+param.toString());
			return apiDriveService.reqAuthKey(param);
		
	}
	
	
	/**
	 * 운행이력 조회 리스트(gps 포함)
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDrvHstGps", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseDrv drvInf(@RequestBody  ReqParam param) {

			return apiDriveService.reqDrvHstGps(param);
		
	}
	
	/**
	 * 차량정보 조회 리스트
	 *
	 * @return
	 */
	@RequestMapping(value="/reqCarInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqCarInfo(@RequestBody  ReqParam param) {

			return apiDriveService.getCarInfoList(param);
		
	}
	
	/**
	 * 회원정보 조회 리스트
	 *
	 * @return
	 */
	@RequestMapping(value="/reqMemberInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqMemberInfo(@RequestBody  ReqParam param) {

			return apiDriveService.getMemberInfoList(param);
		
	}
	
	/**
	 *운행 이력 조회 리스트
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDrvHst", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqDrvHst(@RequestBody  ReqParam param) {

			return apiDriveService.getDrvHst(param);
		
	}
	
	/**
	 * 운행 GPS 이력 조회 리스트
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDrvGps", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqDrvGps(@RequestBody  ReqParam param) {

			return apiDriveService.getDrvGps(param);
		
	}
	
	/**
	 * 운행 통계  조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDrvStat", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqDrvStat(@RequestBody  ReqParam param) {

			return apiDriveService.getDrvStat(param);
		
	}
	

	/**
	 * 운행 통계 2   조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDrvStatSearch", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqDrvStatSearch(@RequestBody  ReqParam param) {

			return apiDriveService.getDrvStatBySearchWord(param);
		
	}
	
	/**
	 * 최초/최종 운행 일시  조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqFrstLstDrvDt", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqFrstLstDrvDt(@RequestBody  ReqParam param) {

			return apiDriveService.getFrstLstDrvDt(param);
		
	}
	
	/**
	 * 차량 유지비  조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqMntnCost", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqMntnCost(@RequestBody  ReqParam param) {

			return apiDriveService.getMntnCost(param);
		
	}
	
	/**
	 * 차량 패널티  조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqPenalty", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqPenalty(@RequestBody  ReqParam param) {

			return apiDriveService.getPenalty(param);
		
	}
	
	/**
	 * 고장진단 코드 조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDiagCode", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqDiagCode(@RequestBody  ReqParam param) {

		return apiDriveService.getDiagCode(param);

	}
	
	/**
	 * 주행 정보 갱신
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDrvUpd", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqDrvUpd(@RequestBody  ReqParam param) {

		return apiDriveService.getDrvUpd(param);

	}
	
	/**
	 * GPS 궤적 조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqGps", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqGps(@RequestBody  ReqParam param) {

		return apiDriveService.getGps(param);

	}
	
	/**
	 * 하이패스 요금 조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqHipass", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqHipass(@RequestBody  ReqParam param) {

		return apiDriveService.getHipass(param);

	}
	
	/**
	 * 회원 정보 등록
	 *
	 * @return
	 */
	@RequestMapping(value="/reqMemberReg", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqMemberReg(@RequestBody  ReqParam param) {

		return apiDriveService.getMemberReg(param);

	}
	
	/**
	 * 운전자 정보 갱신(주행 정보)
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDrvUpdDrvr", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqDrvUpdDrvr(@RequestBody  ReqParam param) {

		return apiDriveService.getDrvUpdDrvr(param);

	}
	
	/**
	 * 차량별 일간 통계 조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqDrvDyStat", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqDrvDyStat(@RequestBody  ReqParam param) {

		return apiDriveService.getDrvDyStat(param);

	}
	
	/**
	 * 예약 조회
	 *
	 * @return
	 */
	@RequestMapping(value="/reqRsvInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseData reqRsvInfo(@RequestBody  ReqParam param) {

		return apiDriveService.getRsvInfo(param);

	}


}

package com.skmns.ccmp.lora.model.api;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * ResponseRoot
 *
 * @author 201510077
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseRoot {

	/**
	 * 공통 헤더
	 */
	private ResponseHeader header;

	private Map<String, String> appInfo;
	private Map<String, String> fileInfo;

	/**
	 * constructor
	 */
	public ResponseRoot() {
		this.header = new ResponseHeader();
	}

	/**
	 * constructor
	 *
	 * @param code
	 * @param message
	 */
	public ResponseRoot(final String code, final String message) {
		this.header = new ResponseHeader(code, message);
	}

	/*
	 * getter & setter
	 */

	public ResponseHeader getHeader() {
		return this.header;
	}

	public void setHeader(final ResponseHeader header) {
		this.header = header;
	}

	public Map<String, String> getAppInfo() {
		return this.appInfo;
	}

	public void setAppInfo(final Map<String, String> appinfo) {
		this.appInfo = appinfo;
	}

	/**
	 * @return the fileInfo
	 */
	public Map<String, String> getFileInfo() {
		return this.fileInfo;
	}

	/**
	 * @param fileInfo
	 *            the fileInfo to set
	 */
	public void setFileInfo(final Map<String, String> fileInfo) {
		this.fileInfo = fileInfo;
	}
}

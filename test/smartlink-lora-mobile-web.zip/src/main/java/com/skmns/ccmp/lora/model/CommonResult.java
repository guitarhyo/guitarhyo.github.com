package com.skmns.ccmp.lora.model;

import org.apache.ibatis.type.Alias;

import com.skmns.ccmp.lora.model.api.ResponseRoot;

@Alias(value = "CommonResult")
public class CommonResult {
	private String code;
	private String message;
	private String result;
	private String title;

	/**
	 *
	 */
	private Object data;

	/**
	 * default constructor
	 */
	public CommonResult() {

	}

	/**
	 *
	 * @param code
	 * @param message
	 */
	public CommonResult(final String code, final String message) {
		this.code = code;
		this.message = message;
	}

	/**
	 *
	 * @param code
	 * @param title
	 * @param message
	 */
	public CommonResult(final String code, final String title, final String message) {
		this.code = code;
		this.message = message;
		this.title = title;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(final String title) {
		this.title = title;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(final String code) {
		this.code = code;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(final String message) {
		this.message = message;
	}

	public String getResult() {
		return this.result;
	}

	public void setResult(final String result) {
		this.result = result;
	}

	public Object getData() {
		return this.data;
	}

	public void setData(final Object data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "CommonResult [code=" + this.code + ", message=" + this.message + "]";
	}

	public ResponseRoot toResponseRoot() {
		return new ResponseRoot(code, message);
	}
}

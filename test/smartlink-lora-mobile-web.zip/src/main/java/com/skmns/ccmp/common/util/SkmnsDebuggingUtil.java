package com.skmns.ccmp.common.util;

import javax.servlet.http.HttpServletRequest;

import com.skmns.ccmp.common.constant.ConstantCode4Application;

public class SkmnsDebuggingUtil {

	protected SkmnsDebuggingUtil() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 디버깅 여부
	 *
	 * <pre>
	 * RequestURL로 localhost 여부를 판단한다.
	 * </pre>
	 *
	 * @param request
	 * @return
	 */
	public static boolean isDebugging(final HttpServletRequest request) {
		return request.getRequestURL().indexOf("localhost") >= 0 || request.getRequestURL().indexOf("127.0.0.1") >= 0;
	}

	/**
	 * 개발서버 여부.
	 *
	 * @param request
	 * @return PROD, STG 환경이면 false
	 */
	public static boolean isDevServer(final HttpServletRequest request) {
		String svr = request.getServerName();
		if (svr.startsWith("www.") || isStagingServer(request)) {
			return false;
		}
		return true;
	}

	public static boolean isStagingServer(final HttpServletRequest request) {
		String svr = request.getServerName();
		return svr.startsWith("dev.") || svr.startsWith("dev-tcms.");
	}
	
	public static String getFileRootPath(final HttpServletRequest request) {
		String fileRootPath = ConstantCode4Application.FILE_UPLOAD_SERVER_PATH;
		if (SkmnsDebuggingUtil.isDebugging(request)) {
			fileRootPath = ConstantCode4Application.FILE_UPLOAD_LOCAL_PATH;
		}

		return fileRootPath;
	}

	public static String getPathRemoveRootPath(final HttpServletRequest request, final String path) {
		return path.substring(SkmnsDebuggingUtil.getFileRootPath(request).length()).replaceAll("\\\\", "\\\\\\\\");
	}

}

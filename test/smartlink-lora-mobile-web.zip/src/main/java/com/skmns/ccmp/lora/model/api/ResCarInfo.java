package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResCarInfo")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResCarInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5572510777634046472L;
	
	private Integer carId; 			//스마트링크 생성 차량ID
	private String carNum;   //차량번호
	private String modelNm;  //차종
	private String carTyp;		//차량유형(소형 중형 대형)
	private String fuelTyp;	//유종
	private Integer cc;				//배기량
	private String crtYear;	//연식
	private String color;		//색상
	private String spot;		//소속 주차장
	private String usgTyp;	//사용용도
	private Float accDist;		//누적거리
	private String gpsDt;		//gps위치 업데이트
	private Float curLat;		//gps위도
	private Float curLon;		//gps경도
	private String drvSts;		//운행 상태
	private String comment;	//특이사항
	
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getModelNm() {
		return modelNm;
	}
	public void setModelNm(String modelNm) {
		this.modelNm = modelNm;
	}
	public String getCarTyp() {
		return carTyp;
	}
	public void setCarTyp(String carTyp) {
		this.carTyp = carTyp;
	}
	public String getFuelTyp() {
		return fuelTyp;
	}
	public void setFuelTyp(String fuelTyp) {
		this.fuelTyp = fuelTyp;
	}
	public Integer getCc() {
		return cc;
	}
	public void setCc(Integer cc) {
		this.cc = cc;
	}
	public String getCrtYear() {
		return crtYear;
	}
	public void setCrtYear(String crtYear) {
		this.crtYear = crtYear;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getSpot() {
		return spot;
	}
	public void setSpot(String spot) {
		this.spot = spot;
	}
	public String getUsgTyp() {
		return usgTyp;
	}
	public void setUsgTyp(String usgTyp) {
		this.usgTyp = usgTyp;
	}
	public Float getAccDist() {
		return accDist;
	}
	public void setAccDist(Float accDist) {
		this.accDist = accDist;
	}
	public String getGpsDt() {
		return gpsDt;
	}
	public void setGpsDt(String gpsDt) {
		this.gpsDt = gpsDt;
	}
	public Float getCurLat() {
		return curLat;
	}
	public void setCurLat(Float curLat) {
		this.curLat = curLat;
	}
	public Float getCurLon() {
		return curLon;
	}
	public void setCurLon(Float curLon) {
		this.curLon = curLon;
	}
	public String getDrvSts() {
		return drvSts;
	}
	public void setDrvSts(String drvSts) {
		this.drvSts = drvSts;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	
}

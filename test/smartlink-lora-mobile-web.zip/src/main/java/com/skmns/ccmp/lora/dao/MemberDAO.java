package com.skmns.ccmp.lora.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.util.CommonUtil;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Member;

@Repository
public class MemberDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = MemberDAO.class.getPackage().getName() + ".";

	/**
	 * 회원 로그인
	 *
	 * @param member
	 *
	 *            <pre>
	 * UserId varchar(20) -- 회원의 로그인아이디
	 * UserPass varchar(20) -- 비밀번호
	 * PushKey varchar(200) = '' -- PushKey
	 * PushDevice varchar(10) = '' -- 디바이스구분(Android, IOS)
	 * </pre>
	 *
	 * @return
	 *
	 *         <pre>
	 * Corpid -- 고객사아이디
	 * MemberName -- 고객명
	 * EmpPart -- 부서명
	 * EmpNumber -- 사번
	 * Cnt -- 예약건수
	 * </pre>
	 *
	 * @throws CommonResponseException
	 */
	public Member usp_Lora_Web_Member_Login(final Member member) throws CommonResponseException {
		if (member.getUserPass() != null) {
			member.setUserPass(CommonUtil.clearDefaultXss(member.getUserPass()));
		}
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Member_Login", member);
	}

	/**
	 * 아이디 찾기 핸드폰 발송
	 *
	 * @param member
	 *
	 * @return CommonResult
	 */
	public CommonResult usp_api_Member_FindUserIdByNamePhone(final Member member) throws CommonResponseException {
		if (member.getMemberName() != null) {
			member.setMemberName(CommonUtil.clearDefaultXss(member.getMemberName()));
		}
		return this.sqlSession.selectOne(NS + "usp_api_Member_FindUserIdByNamePhone", member);
	}

	/**
	 * 비밀번호 초기화 핸드폰 발송
	 *
	 * @param member
	 *
	 * @return CommonResult
	 */
	public CommonResult usp_api_Member_UserPassByMobilePhone(final Member member) throws CommonResponseException {
		if (member.getMemberName() != null) {
			member.setMemberName(CommonUtil.clearDefaultXss(member.getMemberName()));
		}
		return this.sqlSession.selectOne(NS + "usp_api_Member_UserPassByMobilePhone", member);
	}

	/**
	 * 핸드폰번호 및 이름 인증번호 발송
	 *
	 * @param member
	 *
	 * @return CommonResult
	 */
	public CommonResult usp_api_AuthPhone_ByMemberName(final Member member) throws CommonResponseException {
		if (member.getMemberName() != null) {
			member.setMemberName(CommonUtil.clearDefaultXss(member.getMemberName()));
		}
		return this.sqlSession.selectOne(NS + "usp_api_AuthPhone_ByMemberName", member);
	}

	/**
	 * 휴면고객 전환 발송
	 *
	 * @param member
	 *
	 * @return CommonResult
	 */
	public CommonResult usp_api_Member_ResetLastLogin(final Member member) throws CommonResponseException {
		if (member.getMemberName() != null) {
			member.setMemberName(CommonUtil.clearDefaultXss(member.getMemberName()));
		}
		return this.sqlSession.selectOne(NS + "usp_api_Member_ResetLastLogin", member);
	}

}

package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "Drive")
public class Drive implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -721354420123606732L;
	
	private long drvId; // 주행 ID
	private int coId; // 고객사 ID
	private String devEui; // Lora DEV EUI
	private int drvrId; // 운전자(회원) ID
	private int drvSts = -1; // 주행 상태(1: 주행 중, 0: 주행 완료)
	private int usgTyp; // 운행 용도 (1: 업무용, 2: 출퇴근용, 3: 개인용)
	private int insTyp; // 고정 차량 (0: 자동, 1: 고정)
	private String userId;
	private String modelName; //차모델
	private String carNumber; //차 번호
	private int carId;//차아이디
	private int  drvTime;
	private String  drvTimeStr;
	private int isDel; //삭제 여부 1 삭제
	
	private String onDt; // 시동 ON 일시
	private float onLat; // 시동 ON시 위도
	private float onLon; // 시동 ON시 경도
	private String onAddr; // 시동 ON시 행정계/주소
	private String offDt; // 시동 OFF 일시
	private float offLat; // 시동 OFF시 위도
	private float offLon; // 시동 OFF시 경도
	private String offAddr; // 시동 OFF시 행정계/주소
	
	private float obdDist; // OBD 이동거리
	private float gpsDist; // GPS 이동거리
	private float usrDist; // 사용자 이동거리
	private float drvStDist; // 운행 시작시 계기판 주행거리
	private float drvEdDist; // 운행 종료시 계기판 주행거리
	
	private float battVolt; // 차량 전압(0.1v)
	
	private String insId;
	private String insDt;
	private String updId;
	private String updDt;
	
	private int rowNum;
	private int maxCnt;
	private int maxPage;
	private String searchStartDate;
	private String searchEndDate;
	
	private int cnt;
	private float ratio;
	private float cntRatio;
	private float obdDistRatio;
	private float gpsDistRatio;
	private float usrDistRatio;
	private float score;
	
	private String  code;
	
	private int safDrvIdx;    // 안전 지수 	
	private  int fstAccelIdx;	 // 급가속 지수 
	private  int fstAccelCnt;	 // 급가속 횟수 
	private  int fstDecelIdx;	// 급감속 지수 
	private  int fstDecelCnt	; // 급감속 횟수 
	private  int overSpdIdx;	 // 과속 지수 
	
	
	public int getIsDel() {
		return isDel;
	}
	public void setIsDel(int isDel) {
		this.isDel = isDel;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getInsTyp() {
		return insTyp;
	}
	public void setInsTyp(int insTyp) {
		this.insTyp = insTyp;
	}
	/**
	 * @return the safDrvIdx
	 */
	public int getSafDrvIdx() {
		return safDrvIdx;
	}
	/**
	 * @param safDrvIdx the safDrvIdx to set
	 */
	public void setSafDrvIdx(int safDrvIdx) {
		this.safDrvIdx = safDrvIdx;
	}
	/**
	 * @return the fstAccelIdx
	 */
	public int getFstAccelIdx() {
		return fstAccelIdx;
	}
	/**
	 * @param fstAccelIdx the fstAccelIdx to set
	 */
	public void setFstAccelIdx(int fstAccelIdx) {
		this.fstAccelIdx = fstAccelIdx;
	}
	/**
	 * @return the fstAccelCnt
	 */
	public int getFstAccelCnt() {
		return fstAccelCnt;
	}
	/**
	 * @param fstAccelCnt the fstAccelCnt to set
	 */
	public void setFstAccelCnt(int fstAccelCnt) {
		this.fstAccelCnt = fstAccelCnt;
	}
	/**
	 * @return the fstDecelIdx
	 */
	public int getFstDecelIdx() {
		return fstDecelIdx;
	}
	/**
	 * @param fstDecelIdx the fstDecelIdx to set
	 */
	public void setFstDecelIdx(int fstDecelIdx) {
		this.fstDecelIdx = fstDecelIdx;
	}
	/**
	 * @return the fstDecelCnt
	 */
	public int getFstDecelCnt() {
		return fstDecelCnt;
	}
	/**
	 * @param fstDecelCnt the fstDecelCnt to set
	 */
	public void setFstDecelCnt(int fstDecelCnt) {
		this.fstDecelCnt = fstDecelCnt;
	}
	/**
	 * @return the overSpdIdx
	 */
	public int getOverSpdIdx() {
		return overSpdIdx;
	}
	/**
	 * @param overSpdIdx the overSpdIdx to set
	 */
	public void setOverSpdIdx(int overSpdIdx) {
		this.overSpdIdx = overSpdIdx;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the drvTimeStr
	 */
	public String getDrvTimeStr() {
		return drvTimeStr;
	}
	/**
	 * @param drvTimeStr the drvTimeStr to set
	 */
	public void setDrvTimeStr(String drvTimeStr) {
		this.drvTimeStr = drvTimeStr;
	}
	/**
	 * @return the drvTime
	 */
	public int getDrvTime() {
		return drvTime;
	}
	/**
	 * @param drvTime the drvTime to set
	 */
	public void setDrvTime(int drvTime) {
		this.drvTime = drvTime;
	}
	/**
	 * @return the carId
	 */
	public int getCarId() {
		return carId;
	}
	/**
	 * @param carId the carId to set
	 */
	public void setCarId(int carId) {
		this.carId = carId;
	}
	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}
	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	/**
	 * @return the carNumber
	 */
	public String getCarNumber() {
		return carNumber;
	}
	/**
	 * @param carNumber the carNumber to set
	 */
	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}
	public long getDrvId() {
		return drvId;
	}
	public void setDrvId(long drvId) {
		this.drvId = drvId;
	}
	public int getCoId() {
		return coId;
	}
	public void setCoId(int coId) {
		this.coId = coId;
	}
	public String getDevEui() {
		return devEui;
	}
	public void setDevEui(String devEui) {
		this.devEui = devEui;
	}
	public int getDrvrId() {
		return drvrId;
	}
	public void setDrvrId(int drvrId) {
		this.drvrId = drvrId;
	}
	public int getDrvSts() {
		return drvSts;
	}
	public void setDrvSts(int drvSts) {
		this.drvSts = drvSts;
	}
	public int getUsgTyp() {
		return usgTyp;
	}
	public void setUsgTyp(int usgTyp) {
		this.usgTyp = usgTyp;
	}
	public String getOnDt() {
		return onDt;
	}
	public void setOnDt(String onDt) {
		this.onDt = onDt;
	}
	public float getOnLat() {
		return onLat;
	}
	public void setOnLat(float onLat) {
		this.onLat = onLat;
	}
	public float getOnLon() {
		return onLon;
	}
	public void setOnLon(float onLon) {
		this.onLon = onLon;
	}
	public String getOnAddr() {
		return onAddr;
	}
	public void setOnAddr(String onAddr) {
		this.onAddr = onAddr;
	}
	public String getOffDt() {
		return offDt;
	}
	public void setOffDt(String offDt) {
		this.offDt = offDt;
	}
	public float getOffLat() {
		return offLat;
	}
	public void setOffLat(float offLat) {
		this.offLat = offLat;
	}
	public float getOffLon() {
		return offLon;
	}
	public void setOffLon(float offLon) {
		this.offLon = offLon;
	}
	public String getOffAddr() {
		return offAddr;
	}
	public void setOffAddr(String offAddr) {
		this.offAddr = offAddr;
	}
	public float getObdDist() {
		return obdDist;
	}
	public void setObdDist(float obdDist) {
		this.obdDist = obdDist;
	}
	public float getGpsDist() {
		return gpsDist;
	}
	public void setGpsDist(float gpsDist) {
		this.gpsDist = gpsDist;
	}
	public float getUsrDist() {
		return usrDist;
	}
	public void setUsrDist(float usrDist) {
		this.usrDist = usrDist;
	}
	public float getDrvStDist() {
		return drvStDist;
	}
	public void setDrvStDist(float drvStDist) {
		this.drvStDist = drvStDist;
	}
	public float getDrvEdDist() {
		return drvEdDist;
	}
	public void setDrvEdDist(float drvEdDist) {
		this.drvEdDist = drvEdDist;
	}
	public float getBattVolt() {
		return battVolt;
	}
	public void setBattVolt(float battVolt) {
		this.battVolt = battVolt;
	}
	public String getInsId() {
		return insId;
	}
	public void setInsId(String insId) {
		this.insId = insId;
	}
	public String getInsDt() {
		return insDt;
	}
	public void setInsDt(String insDt) {
		this.insDt = insDt;
	}
	public String getUpdId() {
		return updId;
	}
	public void setUpdId(String updId) {
		this.updId = updId;
	}
	public String getUpdDt() {
		return updDt;
	}
	public void setUpdDt(String updDt) {
		this.updDt = updDt;
	}
	public String getSearchStartDate() {
		return searchStartDate;
	}
	public void setSearchStartDate(String searchStartDate) {
		this.searchStartDate = searchStartDate;
	}
	public String getSearchEndDate() {
		return searchEndDate;
	}
	public void setSearchEndDate(String searchEndDate) {
		this.searchEndDate = searchEndDate;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public float getRatio() {
		return ratio;
	}
	public void setRatio(float ratio) {
		this.ratio = ratio;
	}
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public int getMaxCnt() {
		return maxCnt;
	}
	public void setMaxCnt(int maxCnt) {
		this.maxCnt = maxCnt;
	}
	public int getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}
	public float getCntRatio() {
		return cntRatio;
	}
	public void setCntRatio(float cntRatio) {
		this.cntRatio = cntRatio;
	}
	public float getObdDistRatio() {
		return obdDistRatio;
	}
	public void setObdDistRatio(float obdDistRatio) {
		this.obdDistRatio = obdDistRatio;
	}
	public float getGpsDistRatio() {
		return gpsDistRatio;
	}
	public void setGpsDistRatio(float gpsDistRatio) {
		this.gpsDistRatio = gpsDistRatio;
	}
	public float getUsrDistRatio() {
		return usrDistRatio;
	}
	public void setUsrDistRatio(float usrDistRatio) {
		this.usrDistRatio = usrDistRatio;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Drive [drvId=");
		builder.append(drvId);
		builder.append(", coId=");
		builder.append(coId);
		builder.append(", devEui=");
		builder.append(devEui);
		builder.append(", drvrId=");
		builder.append(drvrId);
		builder.append(", drvSts=");
		builder.append(drvSts);
		builder.append(", usgTyp=");
		builder.append(usgTyp);
		builder.append(", modelName=");
		builder.append(modelName);
		builder.append(", carNumber=");
		builder.append(carNumber);
		builder.append(", carId=");
		builder.append(carId);
		builder.append(", drvTime=");
		builder.append(drvTime);
		builder.append(", onDt=");
		builder.append(onDt);
		builder.append(", onLat=");
		builder.append(onLat);
		builder.append(", onLon=");
		builder.append(onLon);
		builder.append(", onAddr=");
		builder.append(onAddr);
		builder.append(", offDt=");
		builder.append(offDt);
		builder.append(", offLat=");
		builder.append(offLat);
		builder.append(", offLon=");
		builder.append(offLon);
		builder.append(", offAddr=");
		builder.append(offAddr);
		builder.append(", obdDist=");
		builder.append(obdDist);
		builder.append(", gpsDist=");
		builder.append(gpsDist);
		builder.append(", usrDist=");
		builder.append(usrDist);
		builder.append(", drvStDist=");
		builder.append(drvStDist);
		builder.append(", drvEdDist=");
		builder.append(drvEdDist);
		builder.append(", battVolt=");
		builder.append(battVolt);
		builder.append(", insId=");
		builder.append(insId);
		builder.append(", insDt=");
		builder.append(insDt);
		builder.append(", updId=");
		builder.append(updId);
		builder.append(", updDt=");
		builder.append(updDt);
		builder.append(", rowNum=");
		builder.append(rowNum);
		builder.append(", maxCnt=");
		builder.append(maxCnt);
		builder.append(", maxPage=");
		builder.append(maxPage);
		builder.append(", searchStartDate=");
		builder.append(searchStartDate);
		builder.append(", searchEndDate=");
		builder.append(searchEndDate);
		builder.append(", cnt=");
		builder.append(cnt);
		builder.append(", ratio=");
		builder.append(ratio);
		builder.append(", cntRatio=");
		builder.append(cntRatio);
		builder.append(", obdDistRatio=");
		builder.append(obdDistRatio);
		builder.append(", gpsDistRatio=");
		builder.append(gpsDistRatio);
		builder.append(", usrDistRatio=");
		builder.append(usrDistRatio);
		builder.append(", score=");
		builder.append(score);
		builder.append("]");
		return builder.toString();
	}
	
	
}

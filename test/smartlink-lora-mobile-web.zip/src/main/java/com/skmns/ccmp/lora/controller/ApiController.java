package com.skmns.ccmp.lora.controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.View;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.skmns.ccmp.common.enc.AES;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.api.JigCommand;
import com.skmns.ccmp.common.util.ExcelView;
import com.skmns.ccmp.common.util.SkmnsDateUtil;
import com.skmns.ccmp.lora.model.MaintenanceReport;
import com.skmns.ccmp.lora.model.api.ResponseRoot;
import com.skmns.ccmp.lora.service.ApiService;
import com.skmns.ccmp.lora.service.MaintenanceReportService;

@Controller
@RequestMapping("/api/app")
public class ApiController {
	private static final Logger logger = LoggerFactory.getLogger(ApiController.class);
	private static final Logger jigLogger = LoggerFactory.getLogger("JIG_API");

	@Autowired
	private MessageSourceAccessor msa;

	@Autowired
	private ApiService apiService;

	@Autowired
	private MaintenanceReportService maintenanceReportService;

	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * App 초기 진입
	 *
	 * @return
	 */
	@RequestMapping("/init")
	@ResponseBody
	public ResponseRoot init(final HttpServletRequest request) {
		try {
			return this.apiService.init(request);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseRoot("-9", "System Error");
		}
	}
	
	@RequestMapping("/config/macaddr")
	@ResponseBody
	public ResponseRoot configMacAddr(HttpServletRequest req
			, @RequestParam(value = "macaddr", required = false) final String macAddr) throws CommonResponseException {
		String authKey = req.getHeader("AuthKey");
		logger.debug("request.getHeader(AuthKey) : {}", authKey);
		
		return apiService.configMacAddress(macAddr, authKey);
	}
	
	@RequestMapping("/jig/log")
	@ResponseBody
	public ResponseRoot addJigCommandLog(HttpServletRequest req, @RequestBody final JigCommand jigCommand) throws CommonResponseException {
		try {
			jigLogger.info("jigCommand : {}", jigCommand);

			if (jigCommand == null
					|| StringUtils.isEmpty(jigCommand.getUserName())
					|| StringUtils.isEmpty(jigCommand.getMacAddr())
					|| StringUtils.isEmpty(jigCommand.getCarNum())
					|| StringUtils.isEmpty(jigCommand.getCmd())) {
				jigLogger.info("required field is missing request");
				return new ResponseRoot("-1", "필수 입력 필드가 누락되었습니다.");
			}

			jigCommand.setIpAddr(req.getRemoteAddr());
			return this.apiService.addJigCmdLog(jigCommand);
		} catch (Exception e) {
			e.printStackTrace();
			jigLogger.warn("System Error : {}", e.getMessage());
			return new ResponseRoot("-9", "System Error");
		}
	}

	/**
	 * TODO 임시 메소드. 추후 삭제
	 * App 테스트시 필요함..
	 *
	 * @return
	 */
	@RequestMapping("/reservations")
	@ResponseBody
	public ResponseRoot reservations(final HttpServletRequest request, @RequestParam(value = "reservId", required = false) final String reservId) {
		try {
			return new ResponseRoot("0", "success");
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseRoot("-9", "System Error");
		}
	}


	@RequestMapping(value = "/carreport/maintain/excel")
	public View reportExcelDownload(final HttpServletResponse response,
			@RequestParam(value = "reqData", required = false, defaultValue = "") final String reqData, final Model model) throws Exception {

		// decryption
		// http://syaku.tistory.com/301
		// http://greatkim91.tistory.com/72
		try {
			// reqData = reqData.replaceAll(" ", "\\+");
			logger.debug("REQ_DATA : '{}'", reqData);
			String jsonStr = AES.decrypt(reqData);

			// convertJson
			ObjectNode excelReqInfo = (ObjectNode) mapper.readTree(jsonStr);
			String memberId = excelReqInfo.get("memberId").textValue();
			String period = excelReqInfo.get("yyyyMM").textValue();
			String paybackSts = excelReqInfo.get("paybackSts").textValue();
			String downloadTime = excelReqInfo.get("downloadTime").textValue();
			logger.debug("excelReqInfo : '{}'", excelReqInfo.toString());
			long beforeTime = Long.parseLong(downloadTime);
			Date date = new Date();
			long afterTime = date.getTime();
			long retTime = afterTime - beforeTime;

			// 시간체크 필요 잘못된 접근 방지 차원
			if (retTime > 5000) {
				logger.error("reportExcelDownload {}", "시간 초과!!");
				throw new Exception("시간 초과!!");
			}
			// data 조회
			MaintenanceReport maintenanceReportVO = new MaintenanceReport();
			if (StringUtils.isEmpty(period)) {
				maintenanceReportVO.setUseDt(SkmnsDateUtil.Date2String("yyyyMM"));
			} else {
				maintenanceReportVO.setUseDt(period);
			}

			maintenanceReportVO.setMemberId(memberId);
			maintenanceReportVO.setPaybackSts(paybackSts);
			maintenanceReportVO.setPaySts(Integer.parseInt(paybackSts));
			List<Map<String, Object>> carList = this.maintenanceReportService.selectCarMntnCostDate(maintenanceReportVO);

			List<Map<String, Object>> reportList = this.maintenanceReportService.selectCarMntnCostItem(maintenanceReportVO);

			List<Map<String, Object>> reportListCnt = this.maintenanceReportService.selectCarMntnCostDateCnt(maintenanceReportVO);

			BigDecimal totalPrice = new BigDecimal(0);

			for (int i = 0; i < reportList.size(); i++) {
				totalPrice = totalPrice.add((BigDecimal) reportList.get(i).get("totalPrice"));
			}

			model.addAttribute("totalPrice", totalPrice);
			model.addAttribute("reportList", reportList);
			model.addAttribute("reportListCnt", reportListCnt);
			model.addAttribute("carList", carList);
			model.addAttribute("yyyyMM", period.substring(0, 4) + "년" + period.substring(4, 6) + "월");
			model.addAttribute("searchDate", SkmnsDateUtil.Date2String("yyyy.MM.dd HH:mm:ss"));
			model.addAttribute("templateType", "maintain");

		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}

		return new ExcelView();

	}

	@RequestMapping(value = "/carreport/calculate/excel")
	public View reportExcelDownload2(final HttpServletResponse response,
			@RequestParam(value = "reqData", required = false, defaultValue = "") final String reqData, final Model model) throws Exception {

		try {

			logger.debug("REQ_DATA : '{}'", reqData);
			String jsonStr = AES.decrypt(reqData);

			// convertJson
			ObjectNode excelReqInfo = (ObjectNode) mapper.readTree(jsonStr);
			String memberId = excelReqInfo.get("memberId").textValue();
			String period = excelReqInfo.get("yyyyMM").textValue();
			String downloadTime = excelReqInfo.get("downloadTime").textValue();

			long beforeTime = Long.parseLong(downloadTime);
			Date date = new Date();
			long afterTime = date.getTime();
			long retTime = afterTime - beforeTime;

			// 시간체크 필요 잘못된 접근 방지 차원
			if (retTime > 5000) {
				logger.error("reportExcelDownload {}", "시간 초과!!");
				throw new Exception("시간 초과!!");
			}
			// data 조회
			MaintenanceReport maintenanceReportVO = new MaintenanceReport();
			if (StringUtils.isEmpty(period)) {
				maintenanceReportVO.setUseDt(SkmnsDateUtil.Date2String("yyyyMM"));
			} else {
				maintenanceReportVO.setUseDt(period);
			}

			maintenanceReportVO.setMemberId(memberId);

			List<Map<String, Object>> maintainCntList = this.maintenanceReportService.selectCarMntnCalcTotal(maintenanceReportVO);
			BigDecimal maintainListTotalPrice = new BigDecimal(0);
			int maintainListTotalCnt = 0;
			for (int i = 0; i < maintainCntList.size(); i++) {
				maintainListTotalPrice = maintainListTotalPrice.add((BigDecimal) maintainCntList.get(i).get("totalPrice"));
				int tmp = (int) maintainCntList.get(i).get("itemCnt");
				maintainListTotalCnt += tmp;
			}
			model.addAttribute("maintainListTotalPrice", maintainListTotalPrice);
			model.addAttribute("maintainListTotalCnt", maintainListTotalCnt);

			List<Map<String, Object>> carKmCntList = this.maintenanceReportService.selectCarMntnCalcDistCnt(maintenanceReportVO);

			BigDecimal carKmListTotalPrice = new BigDecimal(0);
			int carKmListTotalCnt = 0;
			for (int i = 0; i < carKmCntList.size(); i++) {
				carKmListTotalPrice = carKmListTotalPrice.add(BigDecimal.valueOf((double) carKmCntList.get(i).get("totalPrice")));
				int tmp = (int) carKmCntList.get(i).get("carCnt");
				carKmListTotalCnt += tmp;
			}
			model.addAttribute("carKmListTotalPrice", carKmListTotalPrice);
			model.addAttribute("carKmListTotalCnt", carKmListTotalCnt);

			List<Map<String, Object>> carKmList = this.maintenanceReportService.selectCarMntnCalcDist(maintenanceReportVO);
			List<Map<String, Object>> maintainList = this.maintenanceReportService.selectCarMntnCalcHst(maintenanceReportVO);

			MaintenanceReport cntVo = this.maintenanceReportService.selectCalculateCnt(maintenanceReportVO);

			model.addAttribute("totalPrice", cntVo.getTotalPrice());
			model.addAttribute("raceTotalPrice", cntVo.getRaceTotalPrice());
			model.addAttribute("maintainTotalPrice", cntVo.getMaintainTotalPrice());
			model.addAttribute("carKmList", carKmList);
			model.addAttribute("carKmCntList", carKmCntList);
			model.addAttribute("maintainList", maintainList);
			model.addAttribute("maintainCntList", maintainCntList);

			model.addAttribute("yyyyMM", period.substring(0, 4) + "년" + period.substring(4, 6) + "월");
			model.addAttribute("searchDate", SkmnsDateUtil.Date2String("yyyy.MM.dd HH:mm:ss"));
			model.addAttribute("templateType", "carculate");

		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}

		return new ExcelView();

	}

//	public static void main(String[] args) {
//
//		ObjectMapper mapper = new ObjectMapper();
//
//		Map<String, String> map = new HashMap<>();
//		ObjectNode excelReqInfo;
//		Date date = new Date();
//		long time = date.getTime();
//		map.put("memberId", "1111111");
//		map.put("yyyyMM", "1111111");
//		map.put("paybackSts", "1111111");
//		map.put("downloadTime", String.valueOf(111111));
//
//		String jsonString =  mapper.convertValue(map,JsonNode.class).toString();
//
//
//		try {
//			excelReqInfo = (ObjectNode) mapper.readTree(jsonString);
//
//			String memberId = excelReqInfo.get("memberId").toString();
//			String period = excelReqInfo.get("yyyyMM").toString();
//			String paybackSts = excelReqInfo.get("paybackSts").textValue();
//			String downloadTime = excelReqInfo.get("downloadTime").textValue();
//			System.out.println( excelReqInfo.toString());
//
//			System.out.println( paybackSts);
//			System.out.println( downloadTime);
//			long beforeTime = Long.parseLong(downloadTime);
//			System.out.println( beforeTime);
//
//		} catch (JsonProcessingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}
}

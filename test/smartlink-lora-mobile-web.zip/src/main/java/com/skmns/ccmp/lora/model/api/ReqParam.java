package com.skmns.ccmp.lora.model.api;

import org.apache.ibatis.type.Alias;

@Alias(value = "ReqParam")
public class ReqParam {

	private int checkTyp;
	private String authKey;
	private int corpId;
	private String corpCode;
	private String reqTyp;
	private int memberId;
	private String carNum;
	private int carId;
	private String stDt;
	private String edDt;
	private int drvrId;
	private int drvId;
	private String userId;
	private String sabun;
	private String drvSts;
	private int usgTyp;
	private String onDt;
	private String offDt;
	private float onDist;
	private float offDist;
	private String memNm;
	private String memPart;
	private String day;
	private String workStDt;
	private String workEdDt;
	
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getMemNm() {
		return memNm;
	}
	public void setMemNm(String memNm) {
		this.memNm = memNm;
	}
	public String getMemPart() {
		return memPart;
	}
	public void setMemPart(String memPart) {
		this.memPart = memPart;
	}
	public String getWorkStDt() {
		return workStDt;
	}
	public void setWorkStDt(String workStDt) {
		this.workStDt = workStDt;
	}
	public String getWorkEdDt() {
		return workEdDt;
	}
	public void setWorkEdDt(String workEdDt) {
		this.workEdDt = workEdDt;
	}
	public String getDrvSts() {
		return drvSts;
	}
	public void setDrvSts(String drvSts) {
		this.drvSts = drvSts;
	}
	public int getUsgTyp() {
		return usgTyp;
	}
	public void setUsgTyp(int usgTyp) {
		this.usgTyp = usgTyp;
	}
	public String getOnDt() {
		return onDt;
	}
	public void setOnDt(String onDt) {
		this.onDt = onDt;
	}
	public String getOffDt() {
		return offDt;
	}
	public void setOffDt(String offDt) {
		this.offDt = offDt;
	}
	public float getOnDist() {
		return onDist;
	}
	public void setOnDist(float onDist) {
		this.onDist = onDist;
	}
	public float getOffDist() {
		return offDist;
	}
	public void setOffDist(float offDist) {
		this.offDist = offDist;
	}
	
	public int getCheckTyp() {
		return checkTyp;
	}
	public void setCheckTyp(int checkTyp) {
		this.checkTyp = checkTyp;
	}
	public String getAuthKey() {
		return authKey;
	}
	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

	public int getCorpId() {
		return corpId;
	}
	public void setCorpId(int corpId) {
		this.corpId = corpId;
	}
	public String getCorpCode() {
		return corpCode;
	}
	public void setCorpCode(String corpCode) {
		this.corpCode = corpCode;
	}
	public String getReqTyp() {
		return reqTyp;
	}
	public void setReqTyp(String reqTyp) {
		this.reqTyp = reqTyp;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public String getStDt() {
		return stDt;
	}
	public void setStDt(String stDt) {
		this.stDt = stDt;
	}
	public String getEdDt() {
		return edDt;
	}
	public void setEdDt(String edDt) {
		this.edDt = edDt;
	}
	public int getDrvrId() {
		return drvrId;
	}
	public void setDrvrId(int drvrId) {
		this.drvrId = drvrId;
	}
	public int getDrvId() {
		return drvId;
	}
	public void setDrvId(int drvId) {
		this.drvId = drvId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getSabun() {
		return sabun;
	}
	public void setSabun(String sabun) {
		this.sabun = sabun;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ReqParam [checkTyp=");
		builder.append(checkTyp);
		builder.append(", authKey=");
		builder.append(authKey);
		builder.append(", corpId=");
		builder.append(corpId);
		builder.append(", corpCode=");
		builder.append(corpCode);
		builder.append(", reqTyp=");
		builder.append(reqTyp);
		builder.append(", memberId=");
		builder.append(memberId);
		builder.append(", carNum=");
		builder.append(carNum);
		builder.append(", carId=");
		builder.append(carId);
		builder.append(", stDt=");
		builder.append(stDt);
		builder.append(", edDt=");
		builder.append(edDt);
		builder.append(", drvrId=");
		builder.append(drvrId);
		builder.append(", drvId=");
		builder.append(drvId);
		builder.append(", userId=");
		builder.append(userId);
		builder.append(", sabun=");
		builder.append(sabun);
		builder.append("]");
		return builder.toString();
	}
	
	
	
}

package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "MwebCar")
public class MwebCar implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 7156401370446573607L;
	
	private String userId;
	private int carId;
	private String wellsId;
	private String carNumber;
	private String carName; 
	private String curSpotName;
	private float curLat;
	private float curLon;
	private float runDist;
	private String locationComment;
	private String defaultLocation;
	private int roadSearchCnt; // 길찾기 클릭 수
	private String imgPath;
	private String notice;
	private String phoneNumber;
	private int usgTyp;// LORA 주행 용도 (1:업무용, 2:출퇴근용, 3:비업무용) 교원웰스 활동중=1,준비중=2,3
	private String imgText;
	
	private int historyType; // 0 : 상담신청, 1 : 찾아가기, 2 : 전화걸기
	
	
	
	public int getHistoryType() {
		return historyType;
	}
	public void setHistoryType(int historyType) {
		this.historyType = historyType;
	}
	public String getWellsId() {
		return wellsId;
	}
	public void setWellsId(String wellsId) {
		this.wellsId = wellsId;
	}
	public String getImgText() {
		return imgText;
	}
	public void setImgText(String imgText) {
		this.imgText = imgText;
	}
	public int getUsgTyp() {
		return usgTyp;
	}
	public void setUsgTyp(int usgTyp) {
		this.usgTyp = usgTyp;
	}
	public int getRoadSearchCnt() {
		return roadSearchCnt;
	}
	public void setRoadSearchCnt(int roadSearchCnt) {
		this.roadSearchCnt = roadSearchCnt;
	}
	public String getImgPath() {
		return imgPath;
	}
	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	public String getNotice() {
		return notice;
	}
	public void setNotice(String notice) {
		this.notice = notice;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public String getCarNumber() {
		return carNumber;
	}
	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getCurSpotName() {
		return curSpotName;
	}
	public void setCurSpotName(String curSpotName) {
		this.curSpotName = curSpotName;
	}
	public float getCurLat() {
		return curLat;
	}
	public void setCurLat(float curLat) {
		this.curLat = curLat;
	}
	public float getCurLon() {
		return curLon;
	}
	public void setCurLon(float curLon) {
		this.curLon = curLon;
	}
	public float getRunDist() {
		return runDist;
	}
	public void setRunDist(float runDist) {
		this.runDist = runDist;
	}
	public String getLocationComment() {
		return locationComment;
	}
	public void setLocationComment(String locationComment) {
		this.locationComment = locationComment;
	}
	public String getDefaultLocation() {
		return defaultLocation;
	}
	public void setDefaultLocation(String defaultLocation) {
		this.defaultLocation = defaultLocation;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MwebCar [userId=");
		builder.append(userId);
		builder.append(", carId=");
		builder.append(carId);
		builder.append(", wellsId=");
		builder.append(wellsId);
		builder.append(", carNumber=");
		builder.append(carNumber);
		builder.append(", carName=");
		builder.append(carName);
		builder.append(", curSpotName=");
		builder.append(curSpotName);
		builder.append(", curLat=");
		builder.append(curLat);
		builder.append(", curLon=");
		builder.append(curLon);
		builder.append(", runDist=");
		builder.append(runDist);
		builder.append(", locationComment=");
		builder.append(locationComment);
		builder.append(", defaultLocation=");
		builder.append(defaultLocation);
		builder.append(", roadSearchCnt=");
		builder.append(roadSearchCnt);
		builder.append(", imgPath=");
		builder.append(imgPath);
		builder.append(", notice=");
		builder.append(notice);
		builder.append(", phoneNumber=");
		builder.append(phoneNumber);
		builder.append(", usgTyp=");
		builder.append(usgTyp);
		builder.append(", imgText=");
		builder.append(imgText);
		builder.append("]");
		return builder.toString();
	}

	
	
}

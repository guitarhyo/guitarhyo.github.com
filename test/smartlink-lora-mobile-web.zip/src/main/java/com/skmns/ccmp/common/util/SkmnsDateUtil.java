package com.skmns.ccmp.common.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class SkmnsDateUtil {

	protected SkmnsDateUtil() {
		throw new UnsupportedOperationException();
	}

	public static final String HH_MM_SS = "HH:mm:ss";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	public static final String YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";
	public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String YYYY_MM_DD_HH_MM_SS_SSS = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";

	/**
	 * 현재 날짜를 패턴형태로 리턴
	 *
	 * @param pattern
	 *            yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public static String getNowPattern(final String pattern) {
		return new DateTime().toLocalDateTime().toString(pattern);
	}

	/**
	 * 현재 일시
	 *
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	public static String getNow() {
		return SkmnsDateUtil.getNowPattern(YYYY_MM_DD_HH_MM_SS);
	}

	/**
	 * 오늘 날짜
	 *
	 * @return yyyy-MM-dd
	 */
	public static String getToday() {
		return SkmnsDateUtil.getNowPattern(YYYY_MM_DD);
	}

	/**
	 * 현재 시간
	 *
	 * @return HH:mm:ss
	 */
	public static String getNowTime() {
		return SkmnsDateUtil.getNowPattern(HH_MM_SS);
	}

	public static String getyyyyMMddHHmmss(final long timestamp) {
		return SkmnsDateUtil.getPattern(timestamp, YYYY_MM_DD_HH_MM_SS);
	}

	public static String getyyyyMMddHHmmss(final Date date) {
		return SkmnsDateUtil.getPattern(date.getTime(), YYYY_MM_DD_HH_MM_SS);
	}

	public static String getyyyyMMdd(final long timestamp) {
		return SkmnsDateUtil.getPattern(timestamp, YYYY_MM_DD);
	}

	public static String getyyyyMMdd(final Date date) {
		return SkmnsDateUtil.getPattern(date.getTime(), YYYY_MM_DD);
	}

	public static String getyyyyMMddHHmm(final String dateString) {
		return SkmnsDateUtil.getPattern(dateString, YYYY_MM_DD_HH_MM_SS_SSS, YYYY_MM_DD_HH_MM);
	}

	public static String getHHmmss(final long timestamp) {
		return SkmnsDateUtil.getPattern(timestamp, HH_MM_SS);
	}

	public static String getHHmmss(final Date date) {
		return SkmnsDateUtil.getPattern(date.getTime(), HH_MM_SS);
	}

	public static String getPattern(final long timestamp, final String partten) {
		return new DateTime(timestamp).toLocalDateTime().toString(partten);
	}

	public static String getPattern(final Date date, final String partten) {
		return SkmnsDateUtil.getPattern(date.getTime(), partten);
	}

	public static String getPattern(final String dateString, final String originPattern, final String newPattern) {
		DateTimeFormatter formatter = DateTimeFormat.forPattern(originPattern);
		DateTime dateTime = formatter.parseDateTime(dateString);
		return SkmnsDateUtil.getPattern(dateTime.toDate(), newPattern);
	}

	/**
	 * 기준 시간을 설정하고 지정한 분만큼 더하거나 빼준다
	 *
	 * @param format
	 * @param standardMinutes
	 * @param addMinutes
	 * @return
	 */
	public static String getStandardAddMinutes(final String pattern, final int standardMinutes, final int addMinutes) {
		Calendar cal = Calendar.getInstance();
		int nowMinutes = cal.get(Calendar.MINUTE);
		cal.add(Calendar.MINUTE, standardMinutes - nowMinutes + addMinutes);

		return getPattern(cal.getTime(), pattern);
	}

	/**
	 * 지정한 날 만큼 날짜를 더하거나 뺀 날짜를 지정한 포멧의 String 형태로 반환.
	 *
	 * @param format
	 *            날짜 포멧.
	 * @param designDay
	 *            더하거나 뺄 날짜 수.
	 * @return String 형태의 날짜.
	 * @see
	 */
	public static String DateDesign2String(final String format, final int designDay) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, designDay);

		SimpleDateFormat sdf = new SimpleDateFormat(format);

		return sdf.format(cal.getTime());
	}
	
	/**
	 * 현재 날짜를 String 형태로 반환
	 *
	 * @return 현재 날짜.
	 */
	public static String Date2String() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		return sdf.format(new Date());
	}

	/**
	 * 지정한 날짜를 지정한 포멧의 String 형태로 반환
	 *
	 * @param date
	 *            (지정일자)
	 * @param format
	 *            (지정 포멧)
	 * @return String형태의 날짜
	 */
	public static String Date2String(final Date date, final String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);

		return sdf.format(date);
	}

	/**
	 * 현재 날짜를 지정한 포멧의 String 형태로 반환
	 *
	 * @param format
	 * @return String형태의 날짜
	 */
	public static String Date2String(final String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);

		return sdf.format(new Date());
	}

	// 날짜 추가에 따른 값
		public static String getDatewithGap(final String field, final int gap,String formatStr) {
			if (field == null || field.equals("")) {
				return "";
			}

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new Date()); // current time

			if (field.toUpperCase().equals("YEAR")) {
				calendar.add(Calendar.YEAR, gap);
			} else if (field.toUpperCase().equals("MONTH")) {
				calendar.add(Calendar.MONTH, gap);
			} else if (field.toUpperCase().equals("DATE")) {
				calendar.add(Calendar.DATE, gap);
			} else if (field.toUpperCase().equals("HOUR")) {
				calendar.add(Calendar.HOUR, gap);
			} else if (field.toUpperCase().equals("MINUTE")) {
				calendar.add(Calendar.MINUTE, gap);
			} else if (field.toUpperCase().equals("SECOND")) {
				calendar.add(Calendar.SECOND, gap);
			}

			SimpleDateFormat format = new SimpleDateFormat(formatStr);
			return format.format(new Date(calendar.getTimeInMillis()));

		}
	
}

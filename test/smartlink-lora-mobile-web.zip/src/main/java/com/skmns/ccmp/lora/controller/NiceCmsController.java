package com.skmns.ccmp.lora.controller;

import java.io.OutputStream;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.skmns.ccmp.lora.model.DeliveryPlace;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.model.NiceCmsCar;
import com.skmns.ccmp.lora.model.Site;
import com.skmns.ccmp.lora.service.MakeExcelTemlete;
import com.skmns.ccmp.lora.service.NiceCmsService;

@Controller
@RequestMapping("/nicecms")
public class NiceCmsController {
	@Autowired
	private NiceCmsService service;
	
	private final Logger logger = LoggerFactory.getLogger(getClass());

	private void excelDown(HttpServletResponse response, Workbook workbook, String fileName) {
		OutputStream os = null;
		
		try {
			response.setHeader("Content-Type", "application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

			os = response.getOutputStream();
			workbook.write(os);
			os.flush();
		} catch ( Throwable t ) {
			t.printStackTrace();
		} finally {
			if (os != null) { try { os.close(); } catch ( Throwable t ) {} }
		}
	}
	
	private boolean isLogin(HttpSession session) {
		if ( session == null ) return false;
		
		Member member = (Member) session.getAttribute("member");
		
		if ( member == null || member.getCode() == null || !member.getCode().equals("0") ) return false;
		
		return true;
	}
	
	@RequestMapping("/login")
	@ResponseBody
	public Member login(HttpServletRequest request, @RequestParam String userId, @RequestParam String userPass) throws Throwable {
		return service.login(request, userId, userPass);
	}

	@RequestMapping("/logout")
	@ResponseBody
	public String logout(HttpSession session) throws Throwable {
		if ( isLogin(session) ) service.logout(session);
		
		return "{}";
	}

	@RequestMapping("/user")
	@ResponseBody
	public Member user(HttpSession session) throws Throwable {
		if ( !isLogin(session) ) {
			Member member = new Member();
			member.setCode("-1");
			return member;
		}
		
		return service.user(session);
	}

	@RequestMapping("/fundcenter/list")
	@ResponseBody
	public List<Map<String, Object>> fundCenterList(HttpSession session) throws Throwable {
		if ( !isLogin(session) ) return null;

		return service.fundCenterList();
	}
	
	@RequestMapping("/cashtransportteam/list")
	@ResponseBody
	public List<Map<String, Object>> cashTransportTeamList(HttpSession session, @RequestParam long fundCenterId) throws Throwable {
		if ( !isLogin(session) ) return null;

		return service.cashTransportTeamList(fundCenterId);
	}
	
	@RequestMapping("/car/list")
	@ResponseBody
	public List<Map<String, Object>> carList(HttpSession session, @RequestParam long fundCenterId, @RequestParam long cashTransportTeamId) throws Throwable {
		if ( !isLogin(session) ) return null;

		return service.carList(fundCenterId, cashTransportTeamId);
	}

	@RequestMapping("/site/list")
	@ResponseBody
	public List<Map<String, Object>> siteList(HttpSession session, @RequestParam long cashTransportTeamId) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.siteList(cashTransportTeamId);
	}
	
	@RequestMapping("/deliveryplan/create/excelup")
	@ResponseBody
	public List<Map<String, Object>> deliveryPlanCreateExcelUp(MultipartHttpServletRequest request, HttpSession session) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.deliveryPlanCreateExcelUp(request);
	}

	@RequestMapping("/deliveryplan/create/exceldown")
	public void deliveryPlanCreateExcelDown(HttpSession session, HttpServletResponse response, @RequestParam String siteList) throws Throwable {
		if ( !isLogin(session) ) return;

		try {
			excelDown(response
				,service.deliveryPlanCreateExcelDown(siteList)
				,"Delivery_Plan_Create_SiteList.xls");
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
	}

	@RequestMapping("/deliveryplan/optimize")
	@ResponseBody
	public String deliveryPlanOptimize(HttpSession session, @RequestParam long cashTransportTeamId, @RequestParam String siteList, @RequestParam String deliveryDate, @RequestParam long carId
			, @RequestParam int searchOption, @RequestParam int deliveryAccuracy, @RequestParam int searchOptionResult
			, @RequestParam String returnCenterId, @RequestParam int returnHour) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.deliveryPlanOptimize(cashTransportTeamId, siteList, deliveryDate, carId
				,searchOption, deliveryAccuracy, searchOptionResult, returnCenterId, returnHour);
	}
	
	@RequestMapping("/deliveryplan/list")
	@ResponseBody
	public List<Map<String, Object>> deliveryPlanList(HttpSession session, @RequestParam String deliveryDate, @RequestParam long fundCenterId, @RequestParam long cashTransportTeamId, @RequestParam String carNumber) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.deliveryPlanList(deliveryDate, fundCenterId, cashTransportTeamId, carNumber);
	}
	
	@RequestMapping("/deliveryplan/site/list")
	@ResponseBody
	public List<Map<String, Object>> deliveryPlanSiteList(HttpSession session, @RequestParam long deliveryPlanId) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.deliveryPlanSiteList(deliveryPlanId);
	}
	
	@RequestMapping("/deliveryplan/del")
	@ResponseBody
	public String deliveryPlanDel(HttpSession session, @RequestParam String deliveryPlanId) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.deliveryPlanDel(deliveryPlanId);
	}

	@RequestMapping("/deliveryplan/save")
	@ResponseBody
	public String deliveryPlanSave(HttpSession session, @RequestParam long cashTransportTeamId, @RequestParam String siteList, @RequestParam String deliveryDate, @RequestParam long carId
			, @RequestParam long deliveryPlanId) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.deliveryPlanSave(cashTransportTeamId, siteList, deliveryDate, carId, deliveryPlanId);
	}
	
	@RequestMapping("/deliveryplan/check/exceldown")
	public void deliveryPlanCheckExcelDown(HttpSession session, HttpServletResponse response
		,@RequestParam long deliveryPlanId
		,@RequestParam String deliveryDate
		,@RequestParam String carNumber
		,@RequestParam String teamName
		,@RequestParam String managerName
		,@RequestParam String workTime
		,@RequestParam String planTime
		,@RequestParam String planDist
	) throws Throwable {
		if ( !isLogin(session) ) return;
		
		try {
			excelDown(response
				,service.deliveryPlanCheckExcelDown(deliveryPlanId, deliveryDate, carNumber, teamName, managerName, workTime, planTime, planDist)
				,"Delivery_Plan_Check_SiteList.xls");
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
	}

	@RequestMapping("/delivery/list")
	@ResponseBody
	public List<Map<String, Object>> deliveryList(HttpSession session
		,@RequestParam String deliveryDateStart
		,@RequestParam String deliveryDateFinish
		,@RequestParam long fundCenterId
		,@RequestParam long cashTransportTeamId
		,@RequestParam String carNumber
	) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.deliveryList(deliveryDateStart, deliveryDateFinish, fundCenterId, cashTransportTeamId, carNumber);
	}
	
	@RequestMapping("/delivery/daily/exceldown")
	public void deliveryDailyExcelDown(HttpSession session, HttpServletResponse response
		,@RequestParam String deliveryDate
		,@RequestParam long fundCenterId
		,@RequestParam long cashTransportTeamId
		,@RequestParam String carNumber
		,@RequestParam String centerName
		,@RequestParam String teamName
	) throws Throwable {
		if ( !isLogin(session) ) return;
		
		try {
			excelDown(response
				,service.deliveryDailyExcelDown(deliveryDate, fundCenterId, cashTransportTeamId, carNumber, centerName, teamName)
				,"Delivery_Daily.xls");
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
	}
	
	@RequestMapping("/delivery/car/exceldown")
	public void deliveryCarExcelDown(HttpSession session, HttpServletResponse response
		,@RequestParam String deliveryDateStart
		,@RequestParam String deliveryDateFinish
		,@RequestParam long fundCenterId
		,@RequestParam long cashTransportTeamId
		,@RequestParam String carNumber
	) throws Throwable {
		if ( !isLogin(session) ) return;
		
		try {
			excelDown(response
				,service.deliveryCarExcelDown(deliveryDateStart, deliveryDateFinish, fundCenterId, cashTransportTeamId, carNumber)
				,"Delivery_Car.xls");
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
	}






































	/**
	 * 추가작업 시작
	 */
	/**
	 * 차량관리
	 */
	@RequestMapping("/manage/carlist")
	@ResponseBody
	public List<Map<String, Object>> manageCarlist(HttpSession session, @RequestParam String teamCode, @RequestParam String carNumber) throws Throwable {
		if ( !isLogin(session) ) return null;
		return service.manageCarlist(teamCode, carNumber);
	}
	
	@RequestMapping("/car/modellist")
	@ResponseBody
	public List<Map<String, Object>> carModellist(HttpSession session, String corpid) throws Throwable {
		if ( !isLogin(session) ) return null;
		return service.carModellist(corpid);
	}
	
	@RequestMapping("/manage/car/save")
	@ResponseBody
	public String manageCarSave(HttpSession session, final NiceCmsCar niceCmsCar) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		Member member = (Member) session.getAttribute("member");
		niceCmsCar.setuId(member.getUserId());
		
		return service.manageCarSave(niceCmsCar);
	}
	
	@RequestMapping(value = "/manage/car/update", produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String manageCarUpdate(HttpSession session, final NiceCmsCar niceCmsCar) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		String retVal = service.manageCarUpdate(niceCmsCar);
		if (retVal == null) retVal = "SUCCESS";
		
		return retVal;
	}

	
	
	@RequestMapping("/manage/site/list")
	@ResponseBody
	public List<Map<String, Object>> manageSiteList(HttpSession session,
			@RequestParam long fundCenterId,
			@RequestParam long cashTransportTeamId,
			@RequestParam long deliveryPlaceId,
			@RequestParam String siteName
			) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		if (siteName == null) siteName = "";
		
		return service.manageSiteList(fundCenterId, cashTransportTeamId, deliveryPlaceId, siteName);
	}
	
	@RequestMapping("/manage/site/save")
	@ResponseBody
	public String manageSiteSave(HttpSession session, final Site site) throws Throwable {
		if ( !isLogin(session) ) return null;

		return service.manageSiteSave(site);
	}
	
	@RequestMapping("/manage/site/excelup")
	@ResponseBody
	public String manageSiteExcelUp(HttpSession session, MultipartHttpServletRequest request) throws Throwable {
		if ( !isLogin(session) ) return null;

		String retVal = "SUCCESS";

		//String cashTransportTeamId = request.getParameter("excelCashTransportTeamId");
		String uId = request.getParameter("excelUId");
		
		MultipartFile file = request.getFile("excelfileup");
		
		if (file == null) {
			retVal = "FAIL";
		}else{
			String fileName = file.getOriginalFilename();
			if ( (fileName.endsWith(".xls")) || (fileName.endsWith(".xlsx")) ) {
				System.out.println("OK");
				retVal = service.manageSiteExcelUp(file, "0", uId); //엑셀에 팀정보가 포함돼서 삭제
			}else{
				retVal = "FILE_FAIL";
			}
		}

		return retVal;
	}

	//@RequestMapping(value = "/manage/site/update", method = RequestMethod.POST, produces="text/plain; charset=UTF-8")
	@ResponseBody
	@RequestMapping("/manage/site/update")
	public String manageSiteUpdate(HttpSession session, final Site site) throws Throwable {
		if ( !isLogin(session) ) return null;

		if ("".equals(site.getMachineNo().trim())) {
			site.setMachineNo("-");
		}

		return service.manageSiteUpdate(site);
	}
	
	@RequestMapping("/manage/site/dlvplace/update")
	@ResponseBody
	public String manageSiteDlvPlaceUpdate(HttpSession session, 
			@RequestParam String deliveryPlaceId, 
			@RequestParam String siteIds,
			@RequestParam String uId) throws Throwable {
		
		if ( !isLogin(session) ) return null;
		
		service.manageSiteDlvPlaceUpdate(deliveryPlaceId, siteIds, uId);
		
		return "SUCCESS";
	}
	
	@RequestMapping("/manage/site/deletes")
	@ResponseBody
	public String manageSiteDelete(
			HttpSession session, 
			@RequestParam String delSiteIds,
			@RequestParam String uId) throws Throwable {
		if ( !isLogin(session) ) return null;

		service.manageSiteDelete(delSiteIds, uId);
		
		return "SUCCESS";
	}
	
	@RequestMapping("/manage/site/order/updates")
	@ResponseBody
	public String manageSiteOrderUpdates(
			HttpSession session, 
			@RequestParam String siteOrderNums,
			@RequestParam String uId) throws Throwable {
		if ( !isLogin(session) ) return null;

		service.manageSiteOrderUpdates(siteOrderNums, uId);
		
		return "SUCCESS";
	}

	@RequestMapping("/manage/deliveryplace/list")
	@ResponseBody
	public List<Map<String, Object>> manageDeliveryplaceList(HttpSession session) throws Throwable {
		if ( !isLogin(session) ) return null;
		return service.manageDeliveryplaceList("");
	}

	@RequestMapping("/manage/dlvplace/list")
	@ResponseBody
	public List<Map<String, Object>> manageDlvPlaceList(HttpSession session, @RequestParam String searchDeliveryPlaceName) throws Throwable {
		if ( !isLogin(session) ) return null;
		return service.manageDeliveryplaceList(searchDeliveryPlaceName);
	}

	@RequestMapping("/manage/dlvplace/cycle/list")
	@ResponseBody
	public List<Map<String, Object>> manageDlvPlaceCycleList(HttpSession session
			, @RequestParam String search_dlvPlaceCycleDate
			, @RequestParam String search_dlvPlaceCycleCenter
			, @RequestParam String search_dlvPlaceCycleRemoveArea
			, @RequestParam String search_dlvPlaceCycleTime
			, @RequestParam String search_carNumber
			) throws Throwable {
		if ( !isLogin(session) ) return null;

		return service.manageDlvPlaceCycleList(search_dlvPlaceCycleDate, search_dlvPlaceCycleCenter, search_dlvPlaceCycleRemoveArea, search_dlvPlaceCycleTime, search_carNumber);
	}

	/**
	 * 주소를 안가져온 경우 다시 찾음
	 */
	@RequestMapping("/manage/dlvplace/cycle/adjustAddress")
	@ResponseBody
	public String manageDlvPlaceCycleadjustAddress(HttpSession session
			, @RequestParam String lat
			, @RequestParam String lon
			) throws Throwable {
		if ( !isLogin(session) ) return null;

		System.out.println("jgc debug lat="+lat);
		System.out.println("jgc debug lon="+lon);

		return service.manageDlvPlaceCycleAdjustAddress(lat, lon);
	}

	@RequestMapping("/manage/dlvplace/cycle/save")
	@ResponseBody
	public String manageDlvPlaceCycleSave(HttpSession session
			, @RequestParam String[] cycleaddress
			, @RequestParam String[] cyclelat
			, @RequestParam String[] cyclelon
			, @RequestParam String[] cyclechk
			, @RequestParam String uId
			) throws Throwable {
		if ( !isLogin(session) ) return null;
		
		return service.manageDlvPlaceCycleSave(cycleaddress, cyclelat, cyclelon, cyclechk, uId);
	}
	
	/**
	 * 미사용
	 */
	@RequestMapping("/manage/dlvplace/save")
	@ResponseBody
	public String manageDlvPlaceSave(HttpSession session, final DeliveryPlace deliveryPlace) throws Throwable {
		if ( !isLogin(session) ) return null;

		String retVal = service.manageDlvPlaceSave(deliveryPlace);
		if (retVal == null) retVal = "SUCCESS"; 

		return retVal;
	}

	@RequestMapping("/manage/dlvplace/update")
	@ResponseBody
	public String manageDlvPlaceUpdate(HttpSession session, final DeliveryPlace deliveryPlace) throws Throwable {
		if ( !isLogin(session) ) return null;

		String retVal = service.manageDlvPlaceUpdate(deliveryPlace);
		if (retVal == null) retVal = "SUCCESS"; 
		
		return retVal;
	}
	
	@RequestMapping("/manage/dlvplace/delete")
	@ResponseBody
	public String manageDlvPlaceDelete(
			HttpSession session, 
			@RequestParam String delDlvPlaceIds,
			@RequestParam String uId) throws Throwable {
		if ( !isLogin(session) ) return null;

		service.manageDlvPlaceDelete(delDlvPlaceIds, uId);
		
		return "SUCCESS";
	}
	
	@RequestMapping("/poi/list")
	@ResponseBody
	public List<Map<String, Object>> poiList(
			HttpSession session, 
			@RequestParam String carid) throws Throwable {
		if ( !isLogin(session) ) return null;

		return service.poiList(carid);
	}
	
	@RequestMapping("/poi/list2")
	@ResponseBody
	public List<Map<String, Object>> poiList2(
			HttpSession session, 
			@RequestParam String carid) throws Throwable {
		if ( !isLogin(session) ) return null;

		return service.poiList2(carid);
	}
	
	@RequestMapping("/deliveryplanplace/list")
	@ResponseBody
	public List<Map<String, Object>> deliveryPlanPlaceList(
			HttpSession session, 
			@RequestParam String planid) throws Throwable {
		if ( !isLogin(session) ) return null;

		return service.deliveryPlanPlaceList(planid);
	}

	@RequestMapping("/manage/exl/crt")
	public void exlcrt(
			HttpSession session,
			HttpServletRequest request, HttpServletResponse response,
			@RequestParam String siteName) throws Throwable {

		List<Map<String, Object>> aaa = service.manageSiteList(0, 0, 0, siteName);
		
		Map<String, Object> beans = new HashMap<String, Object>();
        beans.put("dataHeader1", "난 헤더1");
        beans.put("dataHeader2", "난 헤더2");
        beans.put("dataHeader3", "난 헤더3");
        beans.put("dataList", aaa);

        MakeExcelTemlete me = new MakeExcelTemlete();
		
		me.download(request, response, beans, "aaa", "tmp.xlsx");
	}

	@RequestMapping("/deliveryplan/check/exceldownNew")
	public void deliveryPlanCheckExcelDownNew(HttpSession session, HttpServletRequest request, HttpServletResponse response
		,@RequestParam long deliveryPlanId
		,@RequestParam String deliveryDate
		,@RequestParam String carNumber
		,@RequestParam String teamName
		,@RequestParam String managerName
		,@RequestParam String workTime
		,@RequestParam String planTime
		,@RequestParam String planDist
	) throws Throwable {
		if ( !isLogin(session) ) return;
		
		try {
			List<Map<String, Object>> list = service.deliveryPlanSiteListNew(deliveryPlanId);
			
			String fundCenterName = "";
			if (list.size() > 0) fundCenterName = (String) list.get(0).get("FUND_CENTER_NAME");
			
			Map<String, Object> beans = new HashMap<String, Object>();
	        beans.put("deliveryDate", deliveryDate);
	        beans.put("carNumber", carNumber);
	        beans.put("fundCenterName", fundCenterName);
	        beans.put("teamName", teamName);
	        beans.put("managerName", managerName);
	        beans.put("workTime", workTime);
	        beans.put("planTime", planTime);
	        beans.put("planDist", planDist);
	        beans.put("dataList", list);

	        MakeExcelTemlete me = new MakeExcelTemlete();
			
			me.download(request, response, beans, "Delivery_Plan_Check_SiteList", "Delivery_Plan_Check_SiteList_Tmp.xlsx");

		} catch ( Throwable t ) {
			t.printStackTrace();
		}
	}
	/**
	 * 추가작업 종료
	 */
}

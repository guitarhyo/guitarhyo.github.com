package com.skmns.ccmp.lora.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.Agree;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Corp;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.service.JoinService;

@Controller
@RequestMapping("/app/join")
public class JoinController {
	private static final Logger logger = LoggerFactory.getLogger(JoinController.class);
	private String jspPath = "/app/join";

	@Autowired
	private JoinService joinService;

	@Autowired
	private HttpServletRequest request;

	@RequestMapping("/agree")
	public String agree(final Agree agree) throws Exception {
		logger.debug("agree page start");

		// agree.setCategoryIds("1,2,3,4,5");
		List<Agree> result = this.joinService.selectTermsList(agree);
		this.request.setAttribute("dataList", result);

		return this.jspPath + "/agree";
	}

	@RequestMapping({ "", "/" })
	public String join() throws Exception {
		logger.debug("join page start");

		String deviceId = this.request.getHeader("Device-ID");
		logger.debug("deviceId : {}", deviceId);

		this.request.setAttribute("pushKey", deviceId);

		return this.jspPath + "/join";
	}

	@RequestMapping("/duplicateUserId")
	@ResponseBody
	public CommonResult duplicateUserId(final String userId) throws CommonResponseException {
		CommonResult result = this.joinService.selectUserIdCnt(userId);

		logger.debug("result : {}", result);

		return result;
	}

	@RequestMapping("/searchCorpList")
	@ResponseBody
	public List<Corp> searchCorpList(final String corpName) throws CommonResponseException {
		List<Corp> result = this.joinService.selectCorpList(corpName);

		logger.debug("result : {}", result);

		return result;
	}

	@RequestMapping("/searchCertCode")
	@ResponseBody
	public CommonResult searchCertCode(final Corp corp) throws CommonResponseException {
		CommonResult result = this.joinService.selectCertCode(corp);

		logger.debug("result : {}", result);

		return result;
	}

	@RequestMapping("/sendMsg")
	@ResponseBody
	public CommonResult sendMsg(final String mobilePhone) throws CommonResponseException {
		CommonResult result = this.joinService.sendMsg(mobilePhone);

		logger.debug("result : {}", result);

		return result;
	}

	@RequestMapping("/checkAuthkey")
	@ResponseBody
	public CommonResult checkAuthkey(final String mobilePhone, final String authKey) throws CommonResponseException {
		Map<String, String> map = new HashMap<>();

		map.put("mobilePhone", mobilePhone);
		map.put("authKey", authKey);

		CommonResult result = this.joinService.checkAuthKey(map);
		logger.debug("result : {}", result);

		return result;
	}

	@RequestMapping("/registerMember")
	@ResponseBody
	public CommonResult registerMember(final Member member) throws CommonResponseException {
		member.setGubun("일반회원");

		if (StringUtils.isNotBlank(member.getPushKey())) {
			// pushKey있으면 pushDevice 설정
			Device device = (Device) this.request.getAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE);
			logger.debug("isMobile : {}", device.isMobile());
			logger.debug("getDevicePlatform : {}", device.getDevicePlatform());
			String devicePlatform = device.getDevicePlatform().toString();
			if (!"IOS".equals(devicePlatform)) {
				devicePlatform = "Android"; // Push Service에서 대소문자 가림
			}
			member.setPushDevice(devicePlatform);
		}

		CommonResult result = this.joinService.createMember(member);
		logger.debug("result : {}", result);

		return result;
	}

	@RequestMapping("/checkEmpNumber")
	@ResponseBody
	public CommonResult checkDuplicatedEmpNumber(final Member member) throws CommonResponseException {
		CommonResult result = this.joinService.selectDuplicatedEmpNumber(member);
		logger.debug("result : {}", result);
		return result;
	}

}


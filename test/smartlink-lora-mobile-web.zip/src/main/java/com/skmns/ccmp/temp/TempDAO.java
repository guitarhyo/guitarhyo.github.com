package com.skmns.ccmp.temp;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class TempDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = TempDAO.class.getPackage().getName() + ".";

	public String getTimestamp() {
		return this.sqlSession.selectOne(NS + "Get_Date");
	}
}

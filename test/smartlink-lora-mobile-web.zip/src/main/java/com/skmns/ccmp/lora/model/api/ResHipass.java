package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResHipass")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResHipass implements Serializable {
	
	private static final long serialVersionUID = 1716468703654737531L;
	private BigDecimal drvId;
	private Integer drvrId;
	private Integer carId;
	private String carNum;
	private Integer fee;
	private String feeDt;
	private String tollGate;
	private String entGate;
	
	public BigDecimal getDrvId() {
		return drvId;
	}
	public void setDrvId(BigDecimal drvId) {
		this.drvId = drvId;
	}
	public Integer getDrvrId() {
		return drvrId;
	}
	public void setDrvrId(Integer drvrId) {
		this.drvrId = drvrId;
	}
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public Integer getFee() {
		return fee;
	}
	public void setFee(Integer fee) {
		this.fee = fee;
	}
	public String getFeeDt() {
		return feeDt;
	}
	public void setFeeDt(String feeDt) {
		this.feeDt = feeDt;
	}
	public String getTollGate() {
		return tollGate;
	}
	public void setTollGate(String tollGate) {
		this.tollGate = tollGate;
	}
	public String getEntGate() {
		return entGate;
	}
	public void setEntGate(String entGate) {
		this.entGate = entGate;
	}
	
}
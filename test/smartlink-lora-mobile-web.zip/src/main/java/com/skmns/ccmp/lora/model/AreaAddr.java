package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "AreaAddr")
public class AreaAddr  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5722822360538931641L;
	
	private int addrType;
	private String sido;
	private String sigungu;
	public int getAddrType() {
		return addrType;
	}
	public void setAddrType(int addrType) {
		this.addrType = addrType;
	}
	public String getSido() {
		return sido;
	}
	public void setSido(String sido) {
		this.sido = sido;
	}
	public String getSigungu() {
		return sigungu;
	}
	public void setSigungu(String sigungu) {
		this.sigungu = sigungu;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AreaAddr [addrType=");
		builder.append(addrType);
		builder.append(", sido=");
		builder.append(sido);
		builder.append(", sigungu=");
		builder.append(sigungu);
		builder.append("]");
		return builder.toString();
	}
	
	
}

package com.skmns.ccmp.lora.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.dao.AjaxDAO;
import com.skmns.ccmp.lora.model.Agree;
import com.skmns.ccmp.lora.model.CodeSection;

@Service
public class AjaxService {

	@Autowired
	private AjaxDAO ajaxDAO;

	/**
	 * 약관 상세 조회
	 *
	 * @param agree
	 * @return
	 * @throws CommonResponseException
	 */
	public Agree selectTerms(final Agree agree) throws CommonResponseException {
		return this.ajaxDAO.usp_api_Terms_FindByCategoryId(agree);
	}

	/**
	 * 공통 코드
	 *	
	 * @param CodeSection
	 * @return CodeSection
	 * @throws CommonResponseException
	 */
	public List<CodeSection> usp_api_CodeSectionValueBySection(final CodeSection codeSection) throws CommonResponseException {
		return this.ajaxDAO.usp_api_CodeSectionValueBySection(codeSection);
	}

	public List<CodeSection> usp_CodeSectionValue_FindByParentId(final CodeSection codeSection) throws CommonResponseException {
		return this.ajaxDAO.usp_CodeSectionValue_FindByParentId(codeSection);
	}
}
package com.skmns.ccmp.lora.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skmns.ccmp.common.TmapApiManager;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.dao.DriveHistDAO;
import com.skmns.ccmp.lora.model.Car;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Drive;
import com.skmns.ccmp.lora.model.Paging;

@Service
public class DriveHistService {
	
	private static final Logger logger = LoggerFactory.getLogger(DriveHistService.class);
	
	@Autowired
	private DriveHistDAO driveHistDAO;
	
	@Autowired
	private TmapApiManager tmap;
	
	/**
	 * 주행기록 요약 정보 조회
	 * 
	 * @param memberId 사용자 id
	 * @return Map 안에 key별로 Drive 객체가 포함되어 있음, JSP에서는 modelName.work.gpsDist의 형식으로 호출
	 * work - 업무용
	 * nonwork- 비업무용
	 * total - 총계, total.score=안전지수
	 * <br/>
	 * Drive 객체
	 * gpsDist - 거리
	 * cntRatio - 비율 (float type)
	 * gpsDistRatio - GSP 거리 비율 (float type)
	 * obdDistRatio - OBD 거리 비율 (float type)
	 * usrDistRatio - USER 거리 비율 (float type)
	 * 
	 * @throws CommonResponseException
	 */
	public Map<String, Drive> getDriveSummary(int memberId) throws CommonResponseException {
		
		final Drive defaultDrive = new Drive(); // 기본값
		Map<String, Drive> result = new HashMap<>();
		result.put("work", defaultDrive);
		result.put("nonwork", defaultDrive);
		result.put("total", defaultDrive);
		
		List<Drive> summList = driveHistDAO.usp_Lora_Web_Drive_Summ(memberId);
		
		if (summList != null && summList.size() > 0) {
			for (Drive summ : summList) {
				if (summ.getUsgTyp() == 1) {
					result.put("work", summ);
				} else if (summ.getUsgTyp() == 3) {
					result.put("nonwork", summ);
				} else {
					result.put("total", summ);
				}
			}
		}
		
		return result;
	}
	
	/**
	 * 주행기록 리스트 (검색)
	 * 
	 * @param drive
	 * <pre>
	 * drvrId - 사용자 ID
	 * drvSts - 운행 상태 (-1:전체=기본값, 0:종료, 1:주행중)
	 * searchStartDate - 검색 시작일시
	 * searchEndDate - 검색 종료일시
	 * </pre>
	 * @return
	 * @throws CommonResponseException
	 */
	public List<Drive> getDriveList(Drive drive, Paging paging) throws CommonResponseException {
		if (StringUtils.isEmpty(drive.getSearchStartDate())) {
			drive.setSearchStartDate("");
		}
		if (StringUtils.isEmpty(drive.getSearchEndDate())) {
			drive.setSearchEndDate("");
		}
		
		Map<String, Object> map = new HashMap<>();
		map.put("Drive", drive);
		map.put("Paging", paging != null ? paging : new Paging());
		
		return convertAddress(driveHistDAO.usp_Lora_Web_Drive_FindByTerm(map));
	}
	
	public List<Drive> getFixDriveList(Drive drive, Paging paging) throws CommonResponseException {
		if (StringUtils.isEmpty(drive.getSearchStartDate())) {
			drive.setSearchStartDate("");
		}
		if (StringUtils.isEmpty(drive.getSearchEndDate())) {
			drive.setSearchEndDate("");
		}
		
		Map<String, Object> map = new HashMap<>();
		map.put("Drive", drive);
		map.put("Paging", paging != null ? paging : new Paging());
		
		return convertAddress(driveHistDAO.usp_Lora_Web_Drive_FindByTerm_Fix(map));
	}
	
	private List<Drive> convertAddress(List<Drive> driveList) {
		if (driveList != null) {
			for (Drive d : driveList) {
				convertAddress(d);
			}
		}
		
		return driveList;
	}
	
	private Drive convertAddress(Drive drive) {
		if (drive != null) {
			String onAddr = null;
			String offAddr = null;
			
			if (StringUtils.isEmpty(drive.getOnAddr()) && drive.getOnLat() > 0 && drive.getOnLon() > 0) {
				onAddr = tmap.getFullAddress(Float.toString(drive.getOnLat()), Float.toString(drive.getOnLon()));
				drive.setOnAddr(onAddr);
			}
			
			if (StringUtils.isEmpty(drive.getOffAddr()) && drive.getOffLat() > 0 && drive.getOffLon() > 0) {
				offAddr = tmap.getFullAddress(Float.toString(drive.getOffLat()), Float.toString(drive.getOffLon()));
				drive.setOffAddr(offAddr);
			}
			
			if (StringUtils.isNotEmpty(onAddr) || StringUtils.isNotEmpty(offAddr)) {
				CommonResult result = driveHistDAO.usp_Lora_Web_Drive_UpdateAddr(drive);
				logger.debug("drvId: {}, result: {}", drive.getDrvId(), result);
			}
		}
		return drive;
	}

	public List<Drive> getDriveList(Drive drive) throws CommonResponseException {
		return getDriveList(drive, new Paging());
	}
	
	/**
	 * 완료된 운행의 용도 변경
	 * 
	 * @param drive
	 * <pre>
	 * drvId - 주행 ID
	 * usgTyp - 변경할 용도 (1:업무용, 2:출퇴근용, 3:비업무용)
	 * insId - 입력 사용자 로그인 ID
	 * </pre>
	 * @return
	 * @throws CommonResponseException
	 */
	public CommonResult updateDriveType(Drive drive) throws CommonResponseException {
		return driveHistDAO.usp_Lora_Web_Drive_Update(drive);
	}
	
	/**
	 * 주행 상세 정보
	 * 
	 * @param driveId
	 * @return
	 * @throws CommonResponseException
	 */
	public Drive getDriveInfo(int driveId) throws CommonResponseException {
		return driveHistDAO.usp_Lora_Web_Drive_FindById(driveId);
	}

	/**
	 * 메인페이지에서 사용되는 사용자의 최근 주행 정보
	 * 
	 * @param memberId
	 * @return
	 * @throws CommonResponseException
	 */
	public Drive getLatestDriveInfo(int memberId) throws CommonResponseException {
		return convertAddress(driveHistDAO.usp_Lora_Web_Drive_FindLatest(memberId));
	}
	
	/**
	 * 메인 화면에서 차량 연결 여부 확인시 사용
	 * 가장 최근 주행기록 상태값 조회
	 * 
	 * @param memberId
	 * @return
	 * code 0: 차량 연결, -1: 연결되지 않음
	 * message 설명
	 * @throws CommonResponseException
	 */
	public CommonResult getDriveStatus(int memberId) throws CommonResponseException {
		return driveHistDAO.usp_Lora_Web_Drive_GetStatus(memberId);
	}
	
	/**
	 * 메인 화면에서 차량연결시 아이폰일경우 차량번호 등록
	 * 
	 * @param carNumber memberId
	 * @return
	 * code 0: 성공
	 * @throws CommonResponseException
	 */
	public CommonResult regIosCarNumber(int carNumber, int memberId) throws CommonResponseException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("carNumber", carNumber);
		map.put("memberId", memberId);
		
		return driveHistDAO.usp_Lora_Web_PhoneReg_Ins(map);
	}
	
	public int carFixCnt(String userId) throws CommonResponseException {

		return driveHistDAO.usp_Car_Fix_Cnt(userId);
	}
	
	public List<Car> searchCarNoList(Map<String, Object> searchMap) throws CommonResponseException{
		return this.driveHistDAO.usp_CarSearchByKeyword_Fix_Req(searchMap);
	}
	
	public Drive usp_Lora_Web_Drive_CarLatestDist(Map<String, Object> searchMap) throws CommonResponseException{
		return this.driveHistDAO.usp_Lora_Web_Drive_CarLatestDist(searchMap);
	}
	
	public CommonResult usp_Lora_Web_Drive_Create(Drive drive) throws CommonResponseException {
		return this.driveHistDAO.usp_Lora_Web_Drive_Create(drive);
	}
	
	public CommonResult usp_Lora_Web_Drive_Update_Fix(Drive drive) throws CommonResponseException {
		return this.driveHistDAO.usp_Lora_Web_Drive_Update_Fix(drive);
	}
	
	
}

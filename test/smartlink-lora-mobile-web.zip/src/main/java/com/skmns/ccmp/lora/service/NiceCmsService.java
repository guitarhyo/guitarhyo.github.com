package com.skmns.ccmp.lora.service;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.skmns.ccmp.common.TmapApiManager;
import com.skmns.ccmp.common.util.CommonUtil;
import com.skmns.ccmp.lora.dao.NiceCmsDAO;
import com.skmns.ccmp.lora.model.DeliveryPlace;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.model.NiceCmsCar;
import com.skmns.ccmp.lora.model.Site;

@Service
public class NiceCmsService {
	@Autowired
	private NiceCmsDAO dao;
	
	@Autowired
	private TmapApiManager tmapApi;
	
	private final Logger logger = LoggerFactory.getLogger(getClass());

	public Member login(HttpServletRequest request, String userId, String userPass) {
		Member member = null;
		
		try {
			Map<String, Object> param = new HashMap<>();
			param.put("userId", userId);
			param.put("userPass", CommonUtil.clearDefaultXss(userPass) );
			
			member = dao.usp_nicecms_Login(param);
		} catch ( Throwable t ) {
			logger.error("", t);
		}

		request.getSession(true).setAttribute("member", member);
		
		return member;
	}
	
	public void logout(HttpSession session) {
		session.removeAttribute("member");
	}

	public Member user(HttpSession session) {
		return (Member) session.getAttribute("member");
	}

	public List<Map<String, Object>> fundCenterList() throws Throwable {
		return dao.usp_nicecms_FundCenterList();
	}

	public List<Map<String, Object>> cashTransportTeamList(long fundCenterId) throws Throwable {
		return dao.usp_nicecms_CashTransportTeamList(fundCenterId);
	}
	
	public List<Map<String, Object>> carList(long fundCenterId, long cashTransportTeamId) throws Throwable {
		Map<String, Object> param = new HashMap<>();
		param.put("FUND_CENTER_ID", fundCenterId);
		param.put("CASH_TRANSPORT_TEAM_ID", cashTransportTeamId);
		
		return dao.usp_nicecms_CarList(param);
	}

	public List<Map<String, Object>> siteList(long cashTransportTeamId) throws Throwable {
		Map<String, Object> param = new HashMap<>();
		param.put("CASH_TRANSPORT_TEAM_ID", cashTransportTeamId);
		
		return dao.usp_nicecms_SiteList(param);
	}
	
	public List<Map<String, Object>> deliveryPlanCreateExcelUp(MultipartHttpServletRequest request) throws Throwable {
		String siteList = "";
		MultipartFile file = request.getFile("excelUpFile");
		String fileName = file.getOriginalFilename();
		Workbook workbook = null;
		Sheet sheet = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		
		if ( fileName.endsWith(".xls") ) {
			workbook = new HSSFWorkbook( file.getInputStream() );
		} else if ( fileName.endsWith(".xlsx") ) {
			workbook = new XSSFWorkbook( file.getInputStream() );
		}
		
		if ( workbook == null ) return null;
		
		int sheetCount = workbook.getNumberOfSheets();
		
		for ( int sheetNo = 0 ; sheetNo < sheetCount ; ++sheetNo ) {
			sheet = workbook.getSheetAt(sheetNo);
			
			if ( sheet == null ) {
				continue;
			}
			
			int lastRow = sheet.getPhysicalNumberOfRows();
			
			if ( lastRow < 7 ) {
				continue;
			}
			
			Row row = sheet.getRow(2);
			Cell cell = row.getCell(0);
			
			if ( cell == null || cell.getStringCellValue() == null || !cell.getStringCellValue().trim().startsWith("현송일자") ) {
				continue;
			}
			
			cell = row.getCell(2);

			/*
			if ( cell == null || cell.getStringCellValue() == null ) {
				continue;
			}
			
			String deliveryDate = cell.getStringCellValue().trim();
			*/
			
			if ( cell == null ) {
				continue;
			}
			
			String deliveryDate = ((int) cell.getNumericCellValue() + "").trim();

			if ( deliveryDate.length() != 8 ) {
				continue;
			}
			
			try {
				sdf.parse( deliveryDate );
			} catch ( Throwable t ) {
				t.printStackTrace();
				continue;
			}
			
			
			row = sheet.getRow(3);
			cell = row.getCell(0);
			
			if ( cell == null || cell.getStringCellValue() == null || !cell.getStringCellValue().trim().startsWith("충전대상팀") ) {
				continue;
			}
			
			cell = row.getCell(2);
			
			if ( cell == null || cell.getStringCellValue() == null ) {
				continue;
			}
			
			String teamName = cell.getStringCellValue().trim();
			
			if ( teamName.length() == 0 ) {
				continue;
			}
			
			row = sheet.getRow(4);
			cell = row.getCell(6);
			
			if ( cell == null || cell.getStringCellValue() == null ) {
				continue;
			}
			
			String temp = cell.getStringCellValue().trim();
			
			if ( temp.length() == 0 ) {
				continue;
			}
			
			String centerName = "";
			
			if ( temp.indexOf(" ") == -1 ) {
				centerName = temp;
			} else {
				centerName = temp.substring(temp.indexOf(" ") + 1);
			}

			for ( int rowNo = 6 ; rowNo < lastRow ; ++rowNo ) {
				row = sheet.getRow(rowNo);
				
				if ( row == null ) continue;
				
				cell = row.getCell(0);
				
				if ( cell == null || getCellValue(row, 0, false) == null ) {
					continue;
				}

				String corpName = getCellValue(row, 0, false).trim();
				
				if ( corpName.length() == 0 || corpName.startsWith("합     계") ) {
					continue;
				}

				cell = row.getCell(1);
				
				if ( cell == null || cell.getStringCellValue() == null ) {
					continue;
				}

				String siteName = cell.getStringCellValue().trim(); 

				if ( siteName.length() == 0 ) {
					continue;
				}

				cell = row.getCell(3);
				
				if ( cell == null || getCellValue(row, 3, false) == null ) {
					continue;
				}

				String machineNo = getCellValue(row, 3, false).trim();
				
				if ( machineNo.length() == 0 ) {
					continue;
				}
				
				if ( machineNo.endsWith(".0") ) {
					machineNo = machineNo.substring(0, machineNo.length() - 2);
				}

				cell = row.getCell(4);
				String returnCenter = "";
				
				if ( cell != null && getCellValue(row, 4, false) != null ) {
					returnCenter = getCellValue(row, 4, false);
				}
				
				cell = row.getCell(5);
				String returnHour = "";
				
				if ( cell != null && getCellValue(row, 5, false) != null ) {
					returnHour = getCellValue(row, 5, false);
				}
				
				siteList += "^" + deliveryDate
							+ "^" + teamName
							+ "^" + centerName
							+ "^" + corpName
							+ "^" + siteName
							+ "^" + machineNo
							+ "^" + returnCenter
							+ "^" + returnHour
							;
			} // for rowNo
		} // for sheetNo
		
		
		workbook.close();
		
		if ( siteList.length() == 0 ) return null;
		
		Map<String, Object> param = new HashMap<>();
		param.put("siteList", siteList.substring(1));

		return dao.usp_nicecms_SiteList(param);
	}

	public Workbook deliveryPlanCreateExcelDown(String siteList) throws Throwable {
		Map<String, Object> param = new HashMap<>();
		param.put("siteIdList", siteList);

		List<Map<String, Object>> list = dao.usp_nicecms_SiteList(param);
		
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("site list");
		int rowNum = 0;
		int cellNum = 0;
		
		String[] title = {
			"사이트 코드"
			,"P_CD"
			,"사이트명"
			,"업체명"
			,"자금 센터"
			,"수행 현송팀"
			,"현송팀 코드"
			,"현송 주기"
			,"현송 요일"
			,"공휴일"
			,"사이트 주소"
			,"사이트 설명"
			,"시간제약"
			,"평균작업시간"
			,"소속 배송처"
		};
		
		HSSFRow row = sheet.createRow(rowNum++);

		HSSFCell cell = null;
		
		for ( int i = 0 ; i < title.length ; ++i ) {
			cell = row.createCell(cellNum++);
			cell.setCellValue(title[i]);
			
			sheet.setColumnWidth(i, 256 * 50);
		}
		
		++rowNum; // add blank row
		
		for ( Map<String, Object> map : list ) {
			row = sheet.createRow(rowNum++);
			cellNum = 0;
			
			cell = row.createCell(cellNum++);
			cell.setCellValue( (String) map.get("SITE_CODE") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("P_CD") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("SITE_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("CORP_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("FUND_CENTER_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("CASH_TRANSPORT_TEAM_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("CASH_TRANSPORT_TEAM_CODE") );
			
			String week = "";
			
			if ( (boolean) map.get("WORK_MON") ) week += "월";
			if ( (boolean) map.get("WORK_TUE") ) week += "화";
			if ( (boolean) map.get("WORK_WED") ) week += "수";
			if ( (boolean) map.get("WORK_THU") ) week += "목";
			if ( (boolean) map.get("WORK_FRI") ) week += "금";
			if ( (boolean) map.get("WORK_SAT") ) week += "토";
			if ( (boolean) map.get("WORK_SUN") ) week += "일";
			
			cell = row.createCell(cellNum++);		
			cell.setCellValue( "주" + week.length() + "회" );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( week );
			
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (boolean) map.get("WORK_HOLIDAY") ? "O" : "" );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("SITE_ADDRESS") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("SITE_DESC") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( map.get("TIME_LIMIT") == null ? "-" : ((Time) map.get("TIME_LIMIT")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (Short) map.get("AVG_WORK_TIME") + "분" );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("DELIVERY_PLACE_NAME") );
		}
		
		/*
		for ( int i = 0 ; i < rowNum ; ++i ) {
			row = sheet.getRow(i);
			
			for ( int k = 0 ; k < cellNum ; ++k ) {
				cell = row.getCell(k);
				
				HSSFCellStyle cellStyle = cell.getCellStyle();
				cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
				cell.setCellStyle(cellStyle);
			}
		}
		*/

		return workbook;
	}
	
	private String getTmapDate(String deliveryDate) {
		String repDate = deliveryDate.replace("-", "");
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date delivery = sdf.parse(repDate);
			Date now = new Date();
			
			if ( !delivery.after(now) ) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(now);
				
				int nowWeek = cal.get(Calendar.DAY_OF_WEEK);
				
				cal.setTime(delivery);
				
				int deliveryWeek = cal.get(Calendar.DAY_OF_WEEK);
				
				int diffDay = deliveryWeek - nowWeek;
				
				if ( diffDay <= 0 ) {
					diffDay += 7;
				}
				
				delivery.setTime(now.getTime() + diffDay * 86400000);
				
				repDate = sdf.format(delivery);
			}
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
		
		return repDate;
	}
	
	public String deliveryPlanOptimize(long cashTransportTeamId, String siteList, String deliveryDate, long carId
			,int searchOption, int deliveryAccuracy, int searchOptionResult, String returnCenterId, int returnHour) throws Throwable {
		int order = 0;
		int pointCount = 0;
		long centerStartTime = (returnHour - 1) * 3600000; // 60분 전 
		long centerEndTime = returnHour * 3600000 + 1800000; // 30분 후
		long deliveryEndTime = centerStartTime;
		
		Map<String, Object> param = new HashMap<>();
		param.put("CASH_TRANSPORT_TEAM_ID", cashTransportTeamId);
		param.put("DELIVERY_DATE", deliveryDate);
		param.put("CarId", carId);
		
		Map<String, Object> team = dao.usp_nicecms_CashTransportTeam(cashTransportTeamId);
		
		// 현송팀 없음
		if ( team == null ) {
			return null;
		}
		
		Map<String, Object> car = dao.usp_nicecms_DeliveryPlanCar(param);
		
		// 배송 차량 없음
		if ( car == null ) {
			return null;
		}
		
		/*
		param.put("carId", car.get("CarId"));
		*/

		Map<String, Object> plan = dao.usp_nicecms_DeliveryPlanAdd(param);
		
		long deliveryPlanId = ((BigDecimal) plan.get("DELIVERY_PLAN_ID")).longValue();
		
		for ( String site : siteList.split(",") ) {
			String siteId = site.trim();
			boolean returnCenter = returnCenterId.indexOf("," + siteId + ",") != -1;
			plan.put("SITE_ID", siteId);
			plan.put("SITE_ORDER", ++order);
			plan.put("RETURN_CENTER", returnCenter ? 1 : 0 );
			plan.put("RETURN_HOUR", returnCenter ? returnHour : 0 );
			dao.usp_nicecms_DeliveryPlanSiteAdd(plan);
		}
		
		List<Map<String, Object>> list = dao.usp_nicecms_DeliveryPlanPlaceList(deliveryPlanId);
		
		long prevDeliveryPlaceId = 0;
		long prevTimeLimit = 86400000;
		double prevLat = 0;
		double prevLon = 0;
		short workTimes = 0;
		boolean returnCenter = false;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmm");
		SimpleDateFormat sdfp = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdft = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
		ArrayNode viaPoints = new ArrayNode(JsonNodeFactory.instance);
		
		String tmapDeliveryDate = getTmapDate(deliveryDate);
		
		logger.trace("tmapDeliveryDate = {}", tmapDeliveryDate);
		
		ObjectNode req = (ObjectNode) new ObjectNode(JsonNodeFactory.instance)
		.put("startName", "Departure")
		.put("startX", car.get("DEPARTURE_LON").toString())
		.put("startY", car.get("DEPARTURE_LAT").toString())
		.put("startTime", tmapDeliveryDate + team.get("WORK_START_TIME").toString().replace(":", "").substring(0, 4) )
		.put("endName", "Arrive")
		.put("endX", car.get("DEPARTURE_LON").toString())
		.put("endY", car.get("DEPARTURE_LAT").toString())
		.put("searchOption", searchOption)
		.put("deliveryAccuracy", deliveryAccuracy)
		.set("viaPoints", viaPoints)
		;
		
		Map<Long, Map<String, String>> timeLimitMap = new HashMap<>();
		
		for ( Map<String, Object> map : list ) {
			long deliveryPlaceId = (long) map.get("DELIVERY_PLACE_ID");
			
			if ( prevDeliveryPlaceId != deliveryPlaceId ) {
				if ( prevDeliveryPlaceId != 0 ) {
					ObjectNode viaPoint = new ObjectNode(JsonNodeFactory.instance)
					.put("viaPointId", String.valueOf(prevDeliveryPlaceId))
					.put("viaPointName", "deliveryPlace")
					.put("viaX", String.valueOf(prevLon))
					.put("viaY", String.valueOf(prevLat))
					.put("viaTime", workTimes * 60)
					;
					
					if ( prevTimeLimit != 86400000 ) {
						viaPoint
						.put("wishStartTime", tmapDeliveryDate + "0000" )
						.put("wishEndTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + prevTimeLimit ) ) );
						
						Map<String, String> tm = new HashMap<>();
						tm.put("wishStartTime", tmapDeliveryDate + "0000");
						tm.put("wishEndTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + prevTimeLimit ) ) );
						
						timeLimitMap.put(prevDeliveryPlaceId, tm);
					}
					
					viaPoints.add(viaPoint);
					++pointCount;
					
					if ( returnCenter && timeLimitMap.get(-1L) == null ) {
						viaPoint = new ObjectNode(JsonNodeFactory.instance)
							.put("viaPointId", "-1")
							.put("viaPointName", "center")
							.put("viaX", car.get("DEPARTURE_LON").toString())
							.put("viaY", car.get("DEPARTURE_LAT").toString())
							.put("viaTime", 0)
							.put("wishStartTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + centerStartTime ) ) )
							.put("wishEndTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + centerEndTime ) ) );
							
						Map<String, String> tm = new HashMap<>();
						tm.put("wishStartTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + centerStartTime) ) );
						tm.put("wishEndTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + centerEndTime ) ) );
						tm.put("checkEndTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + centerEndTime + 1800000 ) ) ); // 30분 후
						
						timeLimitMap.put(-1L, tm);
						
						viaPoints.add(viaPoint);
						++pointCount;
						
						returnCenter = false;
					}
				}
				
				prevDeliveryPlaceId = deliveryPlaceId;
				prevLat = (double) map.get("DELIVERY_PLACE_LAT");
				prevLon = (double) map.get("DELIVERY_PLACE_LON");
				prevTimeLimit = 86400000;
				workTimes = 0;
			}
			
			short workTime = (short) map.get("AVG_WORK_TIME");
			workTimes += workTime;
			
			Date timeLimit = (Date) map.get("TIME_LIMIT");
			
			if ( !returnCenter )
				returnCenter = (boolean) map.get("RETURN_CENTER");
			
			if ( returnCenter && prevTimeLimit > deliveryEndTime )
				prevTimeLimit = deliveryEndTime;
			
			if ( prevTimeLimit == 86400000 && timeLimit == null ) continue;
			
			if ( timeLimit != null ) {
				long timeLimitMs = timeLimit.getTime() + 3600000 * 9; // GMT+09:00:00
				
				if ( prevTimeLimit > timeLimitMs )
					prevTimeLimit = timeLimitMs; 
			}
			
			prevTimeLimit -= workTime * 60000;
			
			map.put("prevTimeLimit", prevTimeLimit);
		} // for list
		
		if ( prevDeliveryPlaceId != 0 ) {
			ObjectNode viaPoint = new ObjectNode(JsonNodeFactory.instance)
			.put("viaPointId", String.valueOf(prevDeliveryPlaceId))
			.put("viaPointName", "test")
			.put("viaX", String.valueOf(prevLon))
			.put("viaY", String.valueOf(prevLat))
			.put("viaTime", workTimes * 60)
			;
			
			if ( prevTimeLimit != 86400000 ) {
				viaPoint
				.put("wishStartTime", tmapDeliveryDate + "0000" )
				.put("wishEndTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + prevTimeLimit ) ) );
				
				Map<String, String> tm = new HashMap<>();
				tm.put("wishStartTime", tmapDeliveryDate + "0000");
				tm.put("wishEndTime", sdf2.format( new Date( sdfp.parse(tmapDeliveryDate).getTime() + prevTimeLimit ) ) );
				
				timeLimitMap.put(prevDeliveryPlaceId, tm);
			}
			
			viaPoints.add(viaPoint);
			++pointCount;
		}
		
		try {
			int retryCount = 0;
			JsonNode res = null;
			
			while ( true ) {
				if ( ++retryCount > 2 ) break;
				
				res = tmapApi.routeOptimization(req.toString(), pointCount);
				
				if ( res.get("error") != null ) {
					return res.toString();
				}
				
				if ( checkTimeLimit(res, timeLimitMap) ) break;
			}
			
			JsonNode properties = res.get("properties");
			
			String totalDistance = properties.get("totalDistance").textValue(); 
			String totalTime = properties.get("totalTime").textValue();
			int totalMoveTime = 0;
			
			int featuresIndex = 0;
			ArrayNode features = (ArrayNode) res.get("features");
			
			for ( JsonNode feature : features ) {
				++featuresIndex;

				properties = feature.get("properties");
				String viaPointId = properties.get("viaPointId").textValue();
				String arriveTime = properties.get("arriveTime").textValue();
				String completeTime = properties.get("completeTime").textValue();
				String distance = properties.get("distance").textValue();
				String time = null;
				
				if ( properties.has("time") ) {
					time = properties.get("time").textValue();
					totalMoveTime += Integer.parseInt(time);
				}
				
				param.put("DELIVERY_PLAN_ID", deliveryPlanId);
				param.put("TMAP_INDEX", featuresIndex);
				param.put("TMAP_ARRIVE_TIME", sdft.format( sdf.parse(arriveTime) ) );
				param.put("TMAP_COMPLETE_TIME", sdft.format( sdf.parse(completeTime) ) );
				param.put("TMAP_DISTANCE", distance);
				param.put("TMAP_TIME", time);
				param.put("DELIVERY_PLACE_ID", viaPointId);
				
				dao.usp_nicecms_DeliveryPlanTmapAdd(param);

				JsonNode geometry = feature.get("geometry");
				String type = geometry.get("type").textValue(); 
				ArrayNode coordinates = (ArrayNode) geometry.get("coordinates");
				int coordIndex = 0;
				
				if ( type.equals("Point") ) {
					// 중복 방지를 위해 Point 에서만 합산
					totalMoveTime += Integer.parseInt( properties.get("deliveryTime").textValue() );
					totalMoveTime += Integer.parseInt( properties.get("waitTime").textValue() );

					++coordIndex;
					
					double lon = coordinates.get(0).doubleValue();
					double lat = coordinates.get(1).doubleValue();
					
					param.put("TMAP_COORD_INDEX", coordIndex);
					param.put("TMAP_LAT", lat);
					param.put("TMAP_LON", lon);
					
					dao.usp_nicecms_DeliveryPlanTmapCoordAdd(param);
				} else if ( type.equals("LineString") ) {
					for ( JsonNode coordinate : coordinates ) {
						++coordIndex;
						
						ArrayNode coord = (ArrayNode) coordinate;
						double lon = coord.get(0).doubleValue();
						double lat = coord.get(1).doubleValue();
						
						param.put("TMAP_COORD_INDEX", coordIndex);
						param.put("TMAP_LAT", lat);
						param.put("TMAP_LON", lon);
						
						dao.usp_nicecms_DeliveryPlanTmapCoordAdd(param);
					}
				}
			} // for features
			
			param.put("DELIVERY_PLAN_DIST", totalDistance);
			param.put("DELIVERY_PLAN_TIME", totalTime);
			param.put("DELIVERY_PLAN_MOVE_TIME", totalMoveTime);
			
			dao.usp_nicecms_DeliveryPlanUpd(param);
			
			dao.usp_nicecms_DeliveryPlanSiteUpd(deliveryPlanId);
param.put("searchOption", searchOption);
param.put("deliveryAccuracy", deliveryAccuracy);
param.put("searchOptionResult", searchOptionResult);
dao.usp_nicecms_TmapOptionAdd(param);
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
		
		return "{}";
	}
	
	private boolean checkTimeLimit(JsonNode res, Map<Long, Map<String, String>> timeLimitMap) {
		ArrayNode features = (ArrayNode) res.get("features");
		
		for ( JsonNode feature : features ) {
			JsonNode properties = feature.get("properties");
			String viaPointId = properties.get("viaPointId").textValue();
			
			if ( viaPointId.length() == 0 ) continue;
			
			Map<String, String> tm = timeLimitMap.get( Long.parseLong(viaPointId) );
			
			if ( tm == null ) continue;
			
			String arriveTime = properties.get("arriveTime").textValue().substring(0, 12);
			String checkEndTime = tm.get("checkEndTime");
			
			if ( checkEndTime == null ) checkEndTime = tm.get("wishEndTime");
			
			if ( arriveTime.compareTo( tm.get("wishStartTime") ) < 0 || arriveTime.compareTo( checkEndTime ) > 0 ) {
				logger.info("{} => {} / {} ~ {}", viaPointId, arriveTime, tm.get("wishStartTime"), checkEndTime);
				return false;
			}
		}
		
		return true;
	}
	
	public List<Map<String, Object>> deliveryPlanList(String deliveryDate, long fundCenterId, long cashTransportTeamId, String carNumber) throws Throwable {
		Map<String, Object> param = new HashMap<>();
		param.put("DELIVERY_DATE", deliveryDate);
		param.put("FUND_CENTER_ID", fundCenterId);
		param.put("CASH_TRANSPORT_TEAM_ID", cashTransportTeamId);
		param.put("CarNumber", carNumber);
		
		return dao.usp_nicecms_DeliveryPlanList(param);
	}
	
	public List<Map<String, Object>> deliveryPlanSiteList(long deliveryPlanId) throws Throwable {
		return dao.usp_nicecms_DeliveryPlanSiteList(deliveryPlanId);
	}
	
	public String deliveryPlanDel(String deliveryPlanId) throws Throwable {
		String[] deliveryPlanIds = deliveryPlanId.split(",");
		Map<String, Object> param = new HashMap<>();

		try {
			for ( String id : deliveryPlanIds ) {
				param.put("DELIVERY_PLAN_ID", id);
				
				dao.usp_nicecms_DeliveryPlanDel(param);
			}
		} catch ( Throwable t ) {
			logger.error("", t);
			
			return "{\"error\":\"Delivery Plan Delete Fail\"}";
		}
		
		return "{}";
	}

	public String deliveryPlanSave(long cashTransportTeamId, String siteList, String deliveryDate, long carId, long deliveryPlanId) throws Throwable {
		Map<String, Object> param = new HashMap<>();
		param.put("DELIVERY_PLAN_ID", deliveryPlanId);
		
		List<Map<String, Object>> returnCenter = dao.usp_nicecms_DeliveryPlanDel(param);
		String returnCenterId = "";
		int returnHour = 0;
		
		for ( Map<String, Object> map : returnCenter ) {
			returnCenterId += "," + map.get("SITE_ID").toString();
			returnHour = (int) map.get("RETURN_HOUR");
		}
		
		returnCenterId += ",";
		
		Map<String, Object> tmapOpt = dao.usp_nicecms_TmapOption(param);
		
		return deliveryPlanOptimize(cashTransportTeamId, siteList, deliveryDate, carId
				,tmapOpt != null ? (int) tmapOpt.get("searchOption") : 2
				,tmapOpt != null ? (int) tmapOpt.get("deliveryAccuracy") : 1
				,tmapOpt != null ? (int) tmapOpt.get("searchOptionResult") : 2
				,returnCenterId, returnHour);
	}
	
	public Workbook deliveryPlanCheckExcelDown(long deliveryPlanId, String deliveryDate, String carNumber, String teamName, String managerName, String workTime, String planTime, String planDist) throws Throwable {
		List<Map<String, Object>> list = deliveryPlanSiteList(deliveryPlanId);
		
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("plan site list");
		int rowNum = 0;
		int cellNum = 0;
		long preDeliveryPlaceId = 0;
		
		String[] title1 = {
			"순서"
			,"사이트 코드"
			,"P_CD"
			,"사이트명"
			,"업체명"
			,"자금 센터"
			,"수행 현송팀"
			,"현송팀 코드"
			,"현송 주기"
			,"현송 요일"
			,"공휴일"
			,"사이트 주소"
			,"사이트 설명"
			,"소속 배송처"
			,"시간제약"
			,"배송계획"
			,""
			,""
			,""
			,""
		};
		
		String[] title2 = {
				""
				,""
				,""
				,""
				,""
				,""
				,""
				,""
				,""
				,""
				,""
				,""
				,""
				,""
				,""
				,"도착시각"
				,"작업시간"
				,"출발시각"
				,"주행시간(분)"
				,"주행거리"
			};

		HSSFRow row = sheet.createRow(rowNum++);
		HSSFCell cell = null;
		
		cell = row.createCell(cellNum++);
		cell.setCellValue("배송일");
		
		cell = row.createCell(cellNum++);
		cell.setCellValue(deliveryDate);
		
		cell = row.createCell(cellNum++);
		cell.setCellValue("차량번호");

		cell = row.createCell(cellNum++);
		cell.setCellValue(carNumber);

		cell = row.createCell(cellNum++);
		cell.setCellValue("현송팀");

		cell = row.createCell(cellNum++);
		cell.setCellValue(teamName);

		cell = row.createCell(cellNum++);
		cell.setCellValue("배송담당자");

		cell = row.createCell(cellNum++);
		cell.setCellValue(managerName);

		row = sheet.createRow(rowNum++); // blank row

		row = sheet.createRow(rowNum++);
		cellNum = 0;

		for ( int i = 0 ; i < title1.length ; ++i ) {
			cell = row.createCell(cellNum++);
			cell.setCellValue(title1[i]);
			
			sheet.setColumnWidth(i, 256 * 50);
		}
		
		row = sheet.createRow(rowNum++);
		cellNum = 0;

		for ( int i = 0 ; i < title2.length ; ++i ) {
			cell = row.createCell(cellNum++);
			cell.setCellValue(title2[i]);
		}
		
		for ( int i = 0 ; i <= 14 ; ++i ) {
			sheet.addMergedRegion(new CellRangeAddress(2, 3, i, i));
		}
		
		sheet.addMergedRegion(new CellRangeAddress(2, 2, 15, 19));

		row = sheet.createRow(rowNum++); // 합계
		
		cell = row.createCell(0);
		cell.setCellValue("총 예상 주행거리 / 주행시간");
		sheet.addMergedRegion(new CellRangeAddress(4, 4, 0, 15));
		
		cell = row.createCell(16);
		cell.setCellValue(workTime);
		cell = row.createCell(17);
		cell = row.createCell(18);
		cell.setCellValue(planTime);
		cell = row.createCell(19);
		cell.setCellValue(planDist);
		
		
		for ( Map<String, Object> map : list ) {
			row = sheet.createRow(rowNum++);
			cellNum = 0;
			
			cell = row.createCell(cellNum++);
			cell.setCellValue( rowNum - 5 );

			// 출발 or 도착
			if ( map.get("SITE_CODE") == null ) {
				++cellNum;
				++cellNum;

				cell = row.createCell(cellNum++);
				cell.setCellValue( rowNum == 6 ? "출발지" : "도착지" );
				
				++cellNum;
				
				cell = row.createCell(cellNum++);		
				cell.setCellValue( (String) map.get("FUND_CENTER_NAME") );
				cell = row.createCell(cellNum++);		
				cell.setCellValue( (String) map.get("CASH_TRANSPORT_TEAM_NAME") );
				cell = row.createCell(cellNum++);		
				cell.setCellValue( (String) map.get("CASH_TRANSPORT_TEAM_CODE") );
				
				++cellNum;
				++cellNum;
				++cellNum;
				++cellNum;
				++cellNum;
				++cellNum;
				++cellNum;
				
				if ( rowNum == 6 ) {
					++cellNum;
				} else {
					cell = row.createCell(cellNum++);		
					cell.setCellValue( ((Time) map.get("TMAP_ARRIVE_TIME")).toString().substring(0, 5) );
				}
				
				++cellNum;

				if ( rowNum == 6 ) {
					cell = row.createCell(cellNum++);		
					cell.setCellValue( ((Time) map.get("TMAP_ARRIVE_TIME")).toString().substring(0, 5) );
				} else {
					++cellNum;
				}
				
				if ( rowNum == 6 ) {
					++cellNum;
				} else {
					cell = row.createCell(cellNum++);		
					cell.setCellValue( Math.round( (int) map.get("TMAP_TIME") / 60 ) + "분" );
				}

				if ( rowNum == 6 ) {
					++cellNum;
				} else {
					cell = row.createCell(cellNum++);		
					cell.setCellValue( Math.round( (int) map.get("TMAP_DISTANCE") / 1000 ) + "Km" );
				}

				continue;
			}

			cell = row.createCell(cellNum++);
			cell.setCellValue( (String) map.get("SITE_CODE") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("P_CD") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("SITE_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("CORP_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("FUND_CENTER_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("CASH_TRANSPORT_TEAM_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("CASH_TRANSPORT_TEAM_CODE") );
			
			String week = "";
			
			if ( (boolean) map.get("WORK_MON") ) week += "월";
			if ( (boolean) map.get("WORK_TUE") ) week += "화";
			if ( (boolean) map.get("WORK_WED") ) week += "수";
			if ( (boolean) map.get("WORK_THU") ) week += "목";
			if ( (boolean) map.get("WORK_FRI") ) week += "금";
			if ( (boolean) map.get("WORK_SAT") ) week += "토";
			if ( (boolean) map.get("WORK_SUN") ) week += "일";
			
			cell = row.createCell(cellNum++);		
			cell.setCellValue( "주" + week.length() + "회" );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( week );
			
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (boolean) map.get("WORK_HOLIDAY") ? "O" : "" );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("SITE_ADDRESS") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("SITE_DESC") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("DELIVERY_PLACE_NAME") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( map.get("TIME_LIMIT") == null ? "-" : ((Time) map.get("TIME_LIMIT")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("SITE_ARRIVE_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (Short) map.get("AVG_WORK_TIME") + "분" );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("SITE_COMPLETE_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (preDeliveryPlaceId != (long) map.get("DELIVERY_PLACE_ID") ? Math.round( (int) map.get("TMAP_TIME") / 60 ) + "분" : "") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (preDeliveryPlaceId != (long) map.get("DELIVERY_PLACE_ID") ? Math.round( (int) map.get("TMAP_DISTANCE") / 1000 ) + "Km" : "") );
			
			preDeliveryPlaceId = (long) map.get("DELIVERY_PLACE_ID");
		}
		
		return workbook;
	}

	public List<Map<String, Object>> deliveryList(String deliveryDateStart, String deliveryDateFinish, long fundCenterId, long cashTransportTeamId, String carNumber) throws Throwable {
		Map<String, Object> param = new HashMap<>();
		param.put("deliveryDateStart", deliveryDateStart);
		param.put("deliveryDateFinish", deliveryDateFinish);
		param.put("FUND_CENTER_ID", fundCenterId);
		param.put("CASH_TRANSPORT_TEAM_ID", cashTransportTeamId);
		param.put("CarNumber", carNumber);
		
		return dao.usp_nicecms_DeliveryList(param);
	}
	
	public Workbook deliveryDailyExcelDown(String deliveryDate, long fundCenterId, long cashTransportTeamId, String carNumber, String centerName, String teamName) throws Throwable {
		List<Map<String, Object>> list = deliveryList(deliveryDate, deliveryDate, fundCenterId, cashTransportTeamId, carNumber);
		
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("daily");
		int rowNum = 0;
		int cellNum = 0;
		
		String[] title1 = {
			"배송차량"
			,"배송담당자"
			,"※매칭율"
			,"최적화 계획"
			,""
			,""
			,"배송실행 결과"
			,""
			,""
			,"※T map 기준 산정"
			,""
			,""
		};
		
		String[] title2 = {
				""
				,""
				,""
				,"주행거리"
				,"이동시간"
				,"작업시간"
				,"주행거리"
				,"이동시간"
				,"작업시간"
				,"주행거리"
				,"이동시간"
				,"작업시간"
			};

		HSSFRow row = sheet.createRow(rowNum++);
		HSSFCell cell = null;
		
		cell = row.createCell(cellNum++);
		cell.setCellValue("배송일");
		
		cell = row.createCell(cellNum++);
		cell.setCellValue(deliveryDate);
		
		cell = row.createCell(cellNum++);
		cell.setCellValue("자금센터");

		cell = row.createCell(cellNum++);
		cell.setCellValue(centerName);

		cell = row.createCell(cellNum++);
		cell.setCellValue("현송팀");

		cell = row.createCell(cellNum++);
		cell.setCellValue(teamName);

		cell = row.createCell(cellNum++);
		cell.setCellValue("차량번호");

		cell = row.createCell(cellNum++);
		cell.setCellValue(carNumber);

		row = sheet.createRow(rowNum++); // blank row

		row = sheet.createRow(rowNum++);
		cellNum = 0;

		for ( int i = 0 ; i < title1.length ; ++i ) {
			cell = row.createCell(cellNum++);
			cell.setCellValue(title1[i]);
			
			sheet.setColumnWidth(i, 256 * 50);
		}
		
		row = sheet.createRow(rowNum++);
		cellNum = 0;

		for ( int i = 0 ; i < title2.length ; ++i ) {
			cell = row.createCell(cellNum++);
			cell.setCellValue(title2[i]);
		}
		
		for ( int i = 0 ; i <= 2 ; ++i ) {
			sheet.addMergedRegion(new CellRangeAddress(2, 3, i, i));
		}
		
		sheet.addMergedRegion(new CellRangeAddress(2, 2, 3, 5));
		sheet.addMergedRegion(new CellRangeAddress(2, 2, 6, 8));
		sheet.addMergedRegion(new CellRangeAddress(2, 2, 9, 11));

		HSSFRow totalRow = sheet.createRow(rowNum++); // 합계
		
		cell = totalRow.createCell(0);
		cell.setCellValue("합계");
		sheet.addMergedRegion(new CellRangeAddress(4, 4, 0, 1));
		
		for ( int i = 2 ; i <= 11 ; ++i ) {
			totalRow.createCell(i);
		}
		
		for ( Map<String, Object> map : list ) {
			row = sheet.createRow(rowNum++);
			cellNum = 0;
			
			cell = row.createCell(cellNum++);
			cell.setCellValue( (String) map.get("CarNumber") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (String) map.get("TRANSPORT_MANAGER") );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (int) Math.floor( (double) map.get("COMPLIANCE_RATIO") * 100) + "%");
			cell = row.createCell(cellNum++);		
			cell.setCellValue( Math.round( (double) map.get("DELIVERY_PLAN_DIST") / 1000) + "Km");
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("DELIVERY_PLAN_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("DELIVERY_PLAN_WORK_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( Math.round( (double) map.get("DELIVERY_DIST") ) + "Km");
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("DELIVERY_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("DELIVERY_WORK_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( Math.round( (double) map.get("TMAP_DIST") / 1000) + "Km");
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("TMAP_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("TMAP_WORK_TIME")).toString().substring(0, 5) );
			
			totalRow.getCell(2).setCellValue( (int) Math.floor( (double) map.get("avgComplianceRatio") * 100) + "%");
			
			totalRow.getCell(3).setCellValue( Math.round( (double) map.get("sumDeliveryPlanDist") / 1000) + "Km");
			totalRow.getCell(4).setCellValue( ((Time) map.get("sumDeliveryPlanTime")).toString().substring(0, 5) );
			totalRow.getCell(5).setCellValue( ((Time) map.get("sumDeliveryPlanWorkTime")).toString().substring(0, 5) );
			
			totalRow.getCell(6).setCellValue( Math.round( (double) map.get("sumDeliveryDist")) + "Km");
			totalRow.getCell(7).setCellValue( ((Time) map.get("sumDeliveryTime")).toString().substring(0, 5) );
			totalRow.getCell(8).setCellValue( ((Time) map.get("sumDeliveryWorkTime")).toString().substring(0, 5) );
			
			totalRow.getCell(9).setCellValue( Math.round( (double) map.get("sumTmapDist") / 1000) + "Km");
			totalRow.getCell(10).setCellValue( ((Time) map.get("sumTmapTime")).toString().substring(0, 5) );
			totalRow.getCell(11).setCellValue( ((Time) map.get("sumTmapWorkTime")).toString().substring(0, 5) );
		}

		row = sheet.createRow(rowNum++); // blank row

		row = sheet.createRow(rowNum++); // 주석1
		
		cell = row.createCell(0);
		cell.setCellValue("※ 계획대비 매칭율= 최적화 계획을 준수한 배송처의 개수 / 계획순번이 정해진 배송처의 개수");

		row = sheet.createRow(rowNum++); // 주석2
		
		cell = row.createCell(0);
		cell.setCellValue("※ 당일 배송실행 결과(순번)을 기준으로 T map 경로계산시 산출되는 주행거리와 이동시간 정보 (차량주행 실적과 T map최적화 경로의 거리/시간 비교 가능)");

		return workbook;
	}
	
	public Workbook deliveryCarExcelDown(String deliveryDateStart, String deliveryDateFinish, long fundCenterId, long cashTransportTeamId, String carNumber) throws Throwable {
		List<Map<String, Object>> list = deliveryList(deliveryDateStart, deliveryDateFinish, fundCenterId, cashTransportTeamId, carNumber);
		
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("car");
		int rowNum = 0;
		int cellNum = 0;
		
		String[] title1 = {
			"운행일"
			,"※매칭율"
			,"최적화 계획"
			,""
			,""
			,"배송실행 결과"
			,""
			,""
			,"※T map 기준 산정"
			,""
			,""
		};
		
		String[] title2 = {
				""
				,""
				,"주행거리"
				,"이동시간"
				,"작업시간"
				,"주행거리"
				,"이동시간"
				,"작업시간"
				,"주행거리"
				,"이동시간"
				,"작업시간"
			};

		HSSFRow row = sheet.createRow(rowNum++);
		HSSFCell cell = null;
		
		cell = row.createCell(cellNum++);
		cell.setCellValue("조회 시작일");
		
		cell = row.createCell(cellNum++);
		cell.setCellValue(deliveryDateStart);
		
		cell = row.createCell(cellNum++);
		cell.setCellValue("조회 종료일");
		
		cell = row.createCell(cellNum++);
		cell.setCellValue(deliveryDateFinish);

		cell = row.createCell(cellNum++);
		cell.setCellValue("차량번호");

		cell = row.createCell(cellNum++);
		cell.setCellValue(carNumber);

		row = sheet.createRow(rowNum++); // blank row

		row = sheet.createRow(rowNum++);
		cellNum = 0;

		for ( int i = 0 ; i < title1.length ; ++i ) {
			cell = row.createCell(cellNum++);
			cell.setCellValue(title1[i]);
			
			sheet.setColumnWidth(i, 256 * 50);
		}
		
		row = sheet.createRow(rowNum++);
		cellNum = 0;

		for ( int i = 0 ; i < title2.length ; ++i ) {
			cell = row.createCell(cellNum++);
			cell.setCellValue(title2[i]);
		}
		
		for ( int i = 0 ; i <= 1 ; ++i ) {
			sheet.addMergedRegion(new CellRangeAddress(2, 3, i, i));
		}
		
		sheet.addMergedRegion(new CellRangeAddress(2, 2, 2, 4));
		sheet.addMergedRegion(new CellRangeAddress(2, 2, 5, 7));
		sheet.addMergedRegion(new CellRangeAddress(2, 2, 8, 10));

		HSSFRow totalRow = sheet.createRow(rowNum++); // 합계
		
		cell = totalRow.createCell(0);
		cell.setCellValue("합계");
		
		for ( int i = 1 ; i <= 10 ; ++i ) {
			totalRow.createCell(i);
		}
		
		for ( Map<String, Object> map : list ) {
			row = sheet.createRow(rowNum++);
			cellNum = 0;
			
			cell = row.createCell(cellNum++);
			cell.setCellValue( ((Date) map.get("DELIVERY_DATE")).toString() );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( (int) Math.floor( (double) map.get("COMPLIANCE_RATIO") * 100) + "%");
			cell = row.createCell(cellNum++);		
			cell.setCellValue( Math.round( (double) map.get("DELIVERY_PLAN_DIST") / 1000) + "Km");
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("DELIVERY_PLAN_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("DELIVERY_PLAN_WORK_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( Math.round( (double) map.get("DELIVERY_DIST") ) + "Km");
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("DELIVERY_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("DELIVERY_WORK_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( Math.round( (double) map.get("TMAP_DIST") / 1000) + "Km");
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("TMAP_TIME")).toString().substring(0, 5) );
			cell = row.createCell(cellNum++);		
			cell.setCellValue( ((Time) map.get("TMAP_WORK_TIME")).toString().substring(0, 5) );
			
			totalRow.getCell(1).setCellValue( (int) Math.floor( (double) map.get("avgComplianceRatio") * 100) + "%");
			
			totalRow.getCell(2).setCellValue( Math.round( (double) map.get("sumDeliveryPlanDist") / 1000) + "Km");
			totalRow.getCell(3).setCellValue( ((Time) map.get("sumDeliveryPlanTime")).toString().substring(0, 5) );
			totalRow.getCell(4).setCellValue( ((Time) map.get("sumDeliveryPlanWorkTime")).toString().substring(0, 5) );
			
			totalRow.getCell(5).setCellValue( Math.round( (double) map.get("sumDeliveryDist")) + "Km");
			totalRow.getCell(6).setCellValue( ((Time) map.get("sumDeliveryTime")).toString().substring(0, 5) );
			totalRow.getCell(7).setCellValue( ((Time) map.get("sumDeliveryWorkTime")).toString().substring(0, 5) );
			
			totalRow.getCell(8).setCellValue( Math.round( (double) map.get("sumTmapDist") / 1000) + "Km");
			totalRow.getCell(9).setCellValue( ((Time) map.get("sumTmapTime")).toString().substring(0, 5) );
			totalRow.getCell(10).setCellValue( ((Time) map.get("sumTmapWorkTime")).toString().substring(0, 5) );
		}
		
		row = sheet.createRow(rowNum++); // blank row

		row = sheet.createRow(rowNum++); // 주석1
		
		cell = row.createCell(0);
		cell.setCellValue("※ 계획대비 매칭율= 최적화 계획을 준수한 배송처의 개수 / 계획순번이 정해진 배송처의 개수");

		row = sheet.createRow(rowNum++); // 주석2
		
		cell = row.createCell(0);
		cell.setCellValue("※ 당일 배송실행 결과(순번)을 기준으로 T map 경로계산시 산출되는 주행거리와 이동시간 정보 (차량주행 실적과 T map최적화 경로의 거리/시간 비교 가능)");

		return workbook;
	}




































	/**
	 * 추가작업 시작
	 */
	public List<Map<String, Object>> manageCarlist(String teamCode, String carNumber) throws Throwable {
		Map<String, Object> param = new HashMap<>();
		param.put("teamCode", teamCode);
		param.put("carNumber", carNumber);
		
		return dao.usp_nicecms_ManageCarlist(param);
	}

	public List<Map<String, Object>> carModellist(String corpid) throws Throwable {
		Map<String, Object> param = new HashMap<>();
		param.put("corpid", corpid);
		
		return dao.usp_nicecms_CarModellist(param);
	}

	public String manageCarSave(NiceCmsCar niceCmsCar) throws Throwable {
		niceCmsCar.setDepartureAddress(setEncodingRemove(niceCmsCar.getDepartureAddress()));
		return dao.usp_nicecms_ManageCarSave(niceCmsCar);
	}

	public String manageCarUpdate(NiceCmsCar niceCmsCar) throws Throwable {
		niceCmsCar.setDepartureAddress(setEncodingRemove(niceCmsCar.getDepartureAddress()));
		return dao.usp_nicecms_ManageCarUpdate(niceCmsCar);
	}

	
	
	
	public List<Map<String, Object>> manageSiteList(long fundCenterId, long cashTransportTeamId, long deliveryPlaceId, String siteName) throws Throwable {
		
		siteName = setEncodingRemove(siteName);
		
		Map<String, Object> param = new HashMap<>();
		param.put("FUND_CENTER_ID", fundCenterId);
		param.put("CASH_TRANSPORT_TEAM_ID", cashTransportTeamId);
		param.put("DELIVERY_PLACE_ID", deliveryPlaceId);
		param.put("SITE_NAME", siteName);
		
		return dao.usp_nicecms_ManageSiteList(param);
	}

	public List<Map<String, Object>> manageDeliveryplaceList(String searchDeliveryPlaceName) throws Throwable {
		
		searchDeliveryPlaceName = setEncodingRemove(searchDeliveryPlaceName);
		
		Map<String, Object> param = new HashMap<>();
		param.put("searchDeliveryPlaceName", searchDeliveryPlaceName);
		return dao.usp_nicecms_ManageDeliveryplaceList(param);
	}

	public List<Map<String, Object>> manageDlvPlaceCycleList(String searchDlvPlaceCycleDate, String searchDlvPlaceCycleCenter,
			String searchDlvPlaceCycleRemoveArea, String searchDlvPlaceCycleTime, String search_carNumber) throws Throwable {
		
		Map<String, Object> param = new HashMap<>();
		param.put("searchDlvPlaceCycleDate", searchDlvPlaceCycleDate);
		param.put("searchDlvPlaceCycleCenter", searchDlvPlaceCycleCenter);
		param.put("searchDlvPlaceCycleRemoveArea", searchDlvPlaceCycleRemoveArea);
		param.put("searchDlvPlaceCycleTime", searchDlvPlaceCycleTime);
		param.put("search_carNumber", search_carNumber);
		
		List<Map<String, Object>> listCycle = dao.usp_nicecms_ManageDlvPlaceCycleList(param);

		for(Map<String, Object> cycleData:listCycle) {

			String addressTxt = "";
			
			if (cycleData.get("GPS_ADDRESS") == null) {
				addressTxt = tmapApi.getFullAddress((String) cycleData.get("DEPARTURE_LAT"), (String) cycleData.get("DEPARTURE_LON"));
				
				Map<String, Object> param1 = new HashMap<>();
				param1.put("GPS_ID", cycleData.get("GPS_ID"));
				param1.put("GPS_ADDRESS", addressTxt);
				
				dao.usp_nicecms_ManageLoraLogGpsUpdate(param1);
			}else{
				addressTxt = (String) cycleData.get("GPS_ADDRESS");
			}

			if ("".equals(addressTxt)) {
				cycleData.put("DEPARTURE_ADDRESS", "NO_ADDRESS");
			}else{
				cycleData.put("DEPARTURE_ADDRESS", addressTxt);
			}
		}
		
		return listCycle;
	}

	/**
	 * 주소를 안가져온 경우 다시 찾음
	 */
	public String manageDlvPlaceCycleAdjustAddress(String lat, String lon) throws Throwable {
		String addressTxt = tmapApi.getFullAddress(lat, lon);
		
		if ("".equals(addressTxt)) {
			addressTxt = "NO_ADDRESS";
		}
		
		return addressTxt;
	}
	
	public String manageDlvPlaceCycleSave(String[] cycleaddress, String[] cyclelat, String[] cyclelon, String[] cyclechk, String uId) throws Throwable {
		
		for(int i=0;i<cyclechk.length;i++) {
		
			if ("Y".equals(cyclechk[i])) {
				
				String deliveryPlaceName = "";
				String[] deliveryPlaceNameArr = cycleaddress[i].split(" ");
				
				if (deliveryPlaceNameArr.length >= 3) {
					deliveryPlaceName = deliveryPlaceNameArr[0]+" "+deliveryPlaceNameArr[1]+" "+deliveryPlaceNameArr[2];
				}else if (deliveryPlaceNameArr.length == 2) {
					deliveryPlaceName = deliveryPlaceNameArr[0]+" "+deliveryPlaceNameArr[1];
				}else if (deliveryPlaceNameArr.length == 1) {
					deliveryPlaceName = deliveryPlaceNameArr[0];
				}else{
					deliveryPlaceName = "배송지";
				}
				
				DeliveryPlace deliveryPlace = new DeliveryPlace();
				deliveryPlace.setDeliveryPlaceName(deliveryPlaceName);
				deliveryPlace.setDeliveryPlaceDesc("CYCLE");
				deliveryPlace.setDeliveryPlaceAddress(cycleaddress[i]);
				deliveryPlace.setDeliveryPlaceLat(cyclelat[i]);
				deliveryPlace.setDeliveryPlaceLon(cyclelon[i]);
				deliveryPlace.setuId(uId);
				
				dao.usp_nicecms_ManageDlvPlaceSave(deliveryPlace);
			}
		}
		
		return "SUCCESS";
	}

	public String manageSiteSave(Site site) throws Throwable {

		if ("".equals(site.getMachineNo().trim())) {
			site.setMachineNo("-");
		}
		
		site.setSiteName(setEncodingRemove(site.getSiteName()));
		site.setSiteDesc(setEncodingRemove(site.getSiteDesc()));
		site.setSiteAddress(setEncodingRemove(site.getSiteAddress()));
		
		return dao.usp_nicecms_ManageSiteSave(site);
	}

	public String manageSiteUpdate(Site site) throws Throwable {

		site.setSiteName(setEncodingRemove(site.getSiteName()));
		site.setSiteDesc(setEncodingRemove(site.getSiteDesc()));
		site.setSiteAddress(setEncodingRemove(site.getSiteAddress()));

		return dao.usp_nicecms_ManageSiteUpdate(site);
	}

	public void manageSiteDlvPlaceUpdate(String deliveryPlaceId, String siteIds, String uId) throws Throwable {
		
		String[] siteIdArr = siteIds.split(",");
		
		//해당 배송지에 엮인 사이트 먼저 삭제 후 재 작업
		Map<String, Object> param1 = new HashMap<>();
		param1.put("deliveryPlaceId", deliveryPlaceId);
		param1.put("uId", uId);
		dao.usp_nicecms_ManageSiteDlvPlaceUpdateClear(param1);

		for(String val:siteIdArr) {
			Map<String, Object> param = new HashMap<>();
			param.put("siteId", val);
			param.put("deliveryPlaceId", deliveryPlaceId);
			param.put("uId", uId);
			
			dao.usp_nicecms_ManageSiteDlvPlaceUpdate(param);
		}
	}

	public String manageDlvPlaceSave(DeliveryPlace deliveryPlace) throws Throwable {

		deliveryPlace.setDeliveryPlaceName(setEncodingRemove(deliveryPlace.getDeliveryPlaceName()));
		deliveryPlace.setDeliveryPlaceAddress(setEncodingRemove(deliveryPlace.getDeliveryPlaceAddress()));
		
		return dao.usp_nicecms_ManageDlvPlaceSave(deliveryPlace);
	}

	public String manageDlvPlaceUpdate(DeliveryPlace deliveryPlace) throws Throwable {

		deliveryPlace.setDeliveryPlaceName(setEncodingRemove(deliveryPlace.getDeliveryPlaceName()));
		deliveryPlace.setDeliveryPlaceAddress(setEncodingRemove(deliveryPlace.getDeliveryPlaceAddress()));
		
		return dao.usp_nicecms_ManageDlvPlaceUpdate(deliveryPlace);
	}
	
	public void manageDlvPlaceDelete(String delDlvPlaceIds, String uId) throws Throwable {
		
		String[] dlvPlaceIdArr = delDlvPlaceIds.split(",");
		
		for(String val:dlvPlaceIdArr) {
			Map<String, Object> param = new HashMap<>();
			param.put("deliveryPlaceId", val);
			param.put("uId", uId);
			
			dao.usp_nicecms_ManageDlvPlaceDelete(param);
		}
	}

	public void manageSiteDelete(String delSiteIds, String uId) throws Throwable {
		
		String[] delSiteIdArr = delSiteIds.split(",");
		
		for(String val:delSiteIdArr) {
			Map<String, Object> param = new HashMap<>();
			param.put("siteId", val);
			param.put("uId", uId);
			
			dao.usp_nicecms_ManageSiteDelete(param);
		}
	}

	public void manageSiteOrderUpdates(String siteOrderNums, String uId) throws Throwable {
		
		String[] siteOrderNumArr = siteOrderNums.split(",");
		
		for(String val:siteOrderNumArr) {
			String[] valArr = val.split("/");
			Map<String, Object> param = new HashMap<>();
			param.put("siteId", valArr[0]);
			param.put("siteOrder", valArr[1]);
			param.put("uId", uId);
			
			dao.usp_nicecms_ManageSiteOrderUpdate(param);
		}
	}

	public String manageSiteExcelUp(MultipartFile file, String cashTransportTeamId, String uId) throws Throwable {
		String fileName = file.getOriginalFilename();
		Workbook workbook = null;
		Sheet sheet = null;
		
		if ( fileName.endsWith(".xls") ) {
			workbook = new HSSFWorkbook( file.getInputStream() );
		} else if ( fileName.endsWith(".xlsx") ) {
			workbook = new XSSFWorkbook( file.getInputStream() );
		}
		
		if ( workbook == null ) return null;
		
		//
		Date currentTime = new Date ();
		long mills = currentTime.getTime();
		String keyCode = "999_"+mills;
		//
		
		for (int i=0;i<workbook.getNumberOfSheets();i++) {
		//for (int i=0;i<1;i++) {
			sheet = workbook.getSheetAt(i);
			
			if ( sheet == null ) {
				break;
			}else{
				if (!"예시".equals(sheet.getSheetName())) {
					excelUpProcess2(sheet, keyCode, cashTransportTeamId, uId, i);
				}
			}
		}
		workbook.close();

		//엑셀 데이터 변경으로 삭제
		//dao.usp_nicecms_ManageSiteXlsSave();
		
		return "SUCCESS";
	}


	
	/**
	 * 엑셀의 각각의 sheet를 읽고 해당  sheet의 타이틀의 위치 읽어서 각 컬럼별 데이터 추출 후 site table에 저장
	 * @param sheet
	 * @return
	 */
	private String excelUpProcess2(Sheet sheet, String keyCode, String cashTransportTeamId, String uId, int sheetcnt) throws Throwable {
		
		int lastRow = sheet.getPhysicalNumberOfRows();
		
		if ( lastRow < 1 ) {
			return null;
		}

		for(int rowindex=1;rowindex<lastRow;rowindex++){
		    //행을 읽는다
			Row row=sheet.getRow(rowindex);

		    if(row !=null){

		    	Site site = new Site();

				site.setCorpName(getCellValue(row, 0, false)); //기관명
				if (!"".equals(getCellValue(row, 1, true))) { //사이트코드
					site.setSiteCode(getCellValue(row, 1, false));
				}else{
					site.setSiteCode("-");
				}
				site.setSiteName(getCellValue(row, 2, false)); //사이트명
				site.setSiteAddress(getCellValue(row, 3, false)); //사이트주소
				site.setTeamName(getCellValue(row, 4, false)); //팀명
				site.setTeamCode(getCellValue(row, 5, false)); //팀코드
				
				if (!"".equals(getCellValue(row, 6, true))) { //기번
					//문자로 사용할건데 숫자로 받혀서 ###.0이 나오는 경우 처리
					String legacyRowStr = getCellValue(row, 6, false).toString();
					if(legacyRowStr.contains(".0")){
					    legacyRowStr = legacyRowStr.substring(0, legacyRowStr.length()-2);
					}
					
					site.setMachineNo(legacyRowStr);
				}else{
					site.setMachineNo("-");
				}

				if (!"".equals(getCellValue(row, 7, false))) { //공휴일
					site.setWorkHoliday((int) Double.parseDouble(getCellValue(row, 7, false)));
				}else{
					site.setWorkHoliday(0);
				}
				
				if (!"".equals(getCellValue(row, 8, false))) { //월
					site.setWorkMon((int) Double.parseDouble(getCellValue(row, 8, false)));
				}else{
					site.setWorkMon(0);
				}
				
				if (!"".equals(getCellValue(row, 9, false))) { //화
					site.setWorkTue((int) Double.parseDouble(getCellValue(row, 9, false)));
				}else{
					site.setWorkTue(0);
				}
				
				if (!"".equals(getCellValue(row, 10, false))) { //수
					site.setWorkWed((int) Double.parseDouble(getCellValue(row, 10, false)));
				}else{
					site.setWorkWed(0);
				}
				
				if (!"".equals(getCellValue(row, 11, false))) { //목
					site.setWorkThu((int) Double.parseDouble(getCellValue(row, 11, false)));
				}else{
					site.setWorkThu(0);
				}
				
				if (!"".equals(getCellValue(row, 12, false))) { //금
					site.setWorkFri((int) Double.parseDouble(getCellValue(row, 12, false)));
				}else{
					site.setWorkFri(0);
				}
				
				if (!"".equals(getCellValue(row, 13, false))) { //토
					site.setWorkSat((int) Double.parseDouble(getCellValue(row, 13, false)));
				}else{
					site.setWorkSat(0);
				}
				
				if (!"".equals(getCellValue(row, 14, false))) { //일
					site.setWorkSun((int) Double.parseDouble(getCellValue(row, 14, false)));
				}else{
					site.setWorkSun(0);
				}
				
				if (!"".equals(getCellValue(row, 15, true))) { //시간제약
					site.setTimeLimit(adjustTimeLimit(getCellValue(row, 15, true)));
				}
				
				if (!"".equals(getCellValue(row, 16, false))) { //평균작업시간
					site.setAvgWorkTime(getCellValue(row, 16, false));
				}

				site.setSiteOrder("0");
				//site.setCashTransportTeamId(Integer.parseInt(cashTransportTeamId));
				site.setuId(uId);
				site.setSiteDesc("test-001");
				
				if ( (!"".equals(site.getSiteName())) && (!"".equals(site.getSiteAddress())) 
				  && (!"철수".equals(site.getTeamName())) && (!"철수".equals(site.getMachineNo())) 
				  && (!"철수".equals(site.getSiteAddress()))
				  ) {

					Map<String, Object> geoMap = tmapApi.getGeoInfo(URLEncoder.encode(site.getSiteAddress(), "UTF-8"));
					
					String latStr = (String) geoMap.get("lat");
					String lonStr = (String) geoMap.get("lon");
					
					if ("0".equals(latStr)) latStr = "38";
					if ("0".equals(lonStr)) lonStr = "130";
					
					site.setSiteLat(latStr);
					site.setSiteLon(lonStr);
					//dao.usp_nicecms_ManageSiteXlsSave(site);
					dao.usp_nicecms_ManageSiteSave(site);
				}
		    }
		}

		return null;
	}
	
	/**
	 * 원하는 cell index 로 해당 cell data 값 return
	 * @param row
	 * @param columnindex
	 * @return
	 */
	private String getCellValue(Row row, int columnindex, boolean isDateType) {
		String value = "";

        Cell cell=row.getCell(columnindex);

        if(cell==null){
            return "";
        }else{
            //타입별로 내용 읽기
            switch (cell.getCellType()){
	            case HSSFCell.CELL_TYPE_FORMULA:
	                value=cell.getCellFormula();
	                break;
	            case HSSFCell.CELL_TYPE_NUMERIC:
	            	if (isDateType) {
	            		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
	            		value = sdf.format(cell.getDateCellValue());
	            	}else{
	            		value = cell.getNumericCellValue()+"";
	            	}
	                break;
	            case HSSFCell.CELL_TYPE_STRING:
	                value=cell.getStringCellValue()+"";
	                break;
	            case HSSFCell.CELL_TYPE_BLANK:
	                //value=cell.getBooleanCellValue()+"";
	            	value="";
	                break;
	            case HSSFCell.CELL_TYPE_ERROR:
	                //value=cell.getErrorCellValue()+"";
	            	value="";
	                break;
            }
        }
		return value;
	}
	
	private String setEncodingRemove(String str) {

		str = str.replaceAll("&#40;", "(").replaceAll("&#41;", ")").replaceAll("&amp;", "&");
		
		return str;
	}
	
	private String adjustTimeLimit(String str) {
		System.out.println("jgc debug str1 = " + str);
		int index = str.indexOf("까지");
		System.out.println("jgc debug index = " + index);
		if (index > 0) {
			str = str.substring(0,index);
			index = str.indexOf("분");
			if (index > 0) {
				str = str.replace("시", ":").replace("분", "");
			}else{
				str = str.replace("시", ":") + "00";
			}
			return str;
		}else{
			return str;
		}
	}

	public List<Map<String, Object>> poiList(String carid) throws Throwable {
		return dao.usp_nicecms_poiList(carid);
	}

	public List<Map<String, Object>> poiList2(String carid) throws Throwable {
		return dao.usp_nicecms_poiList2(carid);
	}

	public List<Map<String, Object>> deliveryPlanPlaceList(String planid) throws Throwable {
		return dao.usp_nicecms_ManageDeliveryPlanPlaceList(planid);
	}

	public List<Map<String, Object>> deliveryPlanSiteListNew(long deliveryPlanId) {
		List<Map<String, Object>> newList = new ArrayList<Map<String, Object>>();
		try {
			List<Map<String, Object>> list = deliveryPlanSiteList(deliveryPlanId);
			
			int rowcnt = 0;
			long preDeliveryPlaceId = 0;

			for ( Map<String, Object> map : list ) {
				rowcnt++;
				
				Map<String, Object> newMap = new HashMap<String, Object>();
				
				if (map.get("SITE_CODE") == null)  {
					if ( (rowcnt < (list.size()-1)) && (rowcnt > 1) )  {
						newMap.put("rowcnt", rowcnt);
						newMap.put("SITE_NAME", "반납");
						newMap.put("CORP_NAME", "-");
						newMap.put("MACHINE_NO", "-");
						newList.add(newMap);
					}					
					continue;
				}
//				if (map.get("SITE_CODE") == null) {
//					if (rowcnt == 1) {
//						siteName = "출발지";
//						newMap.put("SITE_COMPLETE_TIME", ((Time) map.get("TMAP_ARRIVE_TIME")).toString().substring(0, 5) );
//					}else{
//						siteName = "도착지";
//						newMap.put("SITE_ARRIVE_TIME", ((Time) map.get("TMAP_ARRIVE_TIME")).toString().substring(0, 5) );
//						newMap.put("TMAP_TIME", Math.round( (int) map.get("TMAP_TIME") / 60 ) + "분" );
//						newMap.put("TMAP_DISTANCE", Math.round( (int) map.get("TMAP_DISTANCE") / 1000 ) + "Km" );
//					}
//
//					newMap.put("rowcnt", rowcnt);
//					newMap.put("SITE_NAME", siteName);
//					newMap.put("FUND_CENTER_NAME", map.get("FUND_CENTER_NAME"));
//					newMap.put("CASH_TRANSPORT_TEAM_NAME", map.get("CASH_TRANSPORT_TEAM_NAME"));
//					newMap.put("CASH_TRANSPORT_TEAM_CODE", map.get("CASH_TRANSPORT_TEAM_CODE"));
//
//					//newList.add(newMap);
//					
//					continue;
//				}
				
				newMap.put("rowcnt", rowcnt);
				newMap.put("SITE_CODE", map.get("SITE_CODE"));
				newMap.put("P_CD", map.get("P_CD"));
				newMap.put("SITE_NAME", map.get("SITE_NAME"));
				newMap.put("CORP_NAME", map.get("CORP_NAME"));
				newMap.put("FUND_CENTER_NAME", map.get("FUND_CENTER_NAME"));
				newMap.put("CASH_TRANSPORT_TEAM_NAME", map.get("CASH_TRANSPORT_TEAM_NAME"));
				newMap.put("CASH_TRANSPORT_TEAM_CODE", map.get("CASH_TRANSPORT_TEAM_CODE"));
				newMap.put("MACHINE_NO", map.get("MACHINE_NO"));
				
				String week = "";
				
				if ( (boolean) map.get("WORK_MON") ) week += "월";
				if ( (boolean) map.get("WORK_TUE") ) week += "화";
				if ( (boolean) map.get("WORK_WED") ) week += "수";
				if ( (boolean) map.get("WORK_THU") ) week += "목";
				if ( (boolean) map.get("WORK_FRI") ) week += "금";
				if ( (boolean) map.get("WORK_SAT") ) week += "토";
				if ( (boolean) map.get("WORK_SUN") ) week += "일";
				
				newMap.put("weeklength", "주" + week.length() + "회");
				newMap.put("week", week);
				newMap.put("WORK_HOLIDAY", (boolean) map.get("WORK_HOLIDAY") ? "O" : "");
				newMap.put("SITE_ADDRESS", map.get("SITE_ADDRESS"));
				newMap.put("SITE_DESC", map.get("SITE_DESC"));
				newMap.put("DELIVERY_PLACE_NAME", map.get("DELIVERY_PLACE_NAME"));
				newMap.put("TIME_LIMIT", map.get("TIME_LIMIT") == null ? "-" : ((Time) map.get("TIME_LIMIT")).toString().substring(0, 5));
				newMap.put("SITE_ARRIVE_TIME", ((Time) map.get("SITE_ARRIVE_TIME")).toString().substring(0, 5));
				newMap.put("AVG_WORK_TIME", (Short) map.get("AVG_WORK_TIME") + "분");
				newMap.put("SITE_COMPLETE_TIME", ((Time) map.get("SITE_COMPLETE_TIME")).toString().substring(0, 5));
				newMap.put("TMAP_TIME", (preDeliveryPlaceId != (long) map.get("DELIVERY_PLACE_ID") ? Math.round( (int) map.get("TMAP_TIME") / 60 ) + "분" : ""));
				newMap.put("TMAP_DISTANCE", (preDeliveryPlaceId != (long) map.get("DELIVERY_PLACE_ID") ? Math.round( (int) map.get("TMAP_DISTANCE") / 1000 ) + "Km" : ""));

				preDeliveryPlaceId = (long) map.get("DELIVERY_PLACE_ID");
				
				newList.add(newMap);
			}
		} catch ( Throwable t ) {
			t.printStackTrace();
		}
		
		return newList;
	}

}

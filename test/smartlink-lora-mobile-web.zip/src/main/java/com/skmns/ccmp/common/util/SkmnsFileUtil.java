package com.skmns.ccmp.common.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.protocol.CommonResultCode;
import com.skmns.ccmp.lora.model.FileInfo;

public class SkmnsFileUtil {
	private static final String STR_INFO_MESSAGE = "Target for uploading file : ";
	private static final String STR_UNDERLINE = "_";
	private static final String STR_DOT = ".";
	private static final String STR_EXTENSION = "jpeg";
	private static final String STR_FILE_NAME = "fileName";
	private static final String STR_FILE_TYPE = "fileType";
	private static final String STR_FILE_PATH = "filePath";
	
	private static final ObjectMapper mapper = new ObjectMapper();

	protected SkmnsFileUtil() {
		throw new UnsupportedOperationException();
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(SkmnsFileUtil.class);

	public static boolean isExistsFile(final HttpServletRequest request, final String filePath) throws CommonResponseException {
		String fileRootPath = SkmnsDebuggingUtil.getFileRootPath(request);
		File file = new File(fileRootPath + filePath);

		return file.exists();
	}

	public static String tcmsUploadFileBase64(String base64Imge, final String uploadRoot, final String filePath, final String downloadRoot, final String fileId)
			throws CommonResponseException {

		LOGGER.debug("base64Image : {}", base64Imge);
		String imgPath = "";

		try {
			// 이미지가 있으면 URL디코딩 하여 String DATA 추출
			// data:image/jpeg;_base_64,[String DATA]
			base64Imge = URLDecoder.decode(base64Imge, "UTF-8");
			String data = base64Imge.split("\\,")[1];

			// 추출된 String basce64 디코딩하여 바이트 배열로 전환
			byte[] imageBytes = DatatypeConverter.parseBase64Binary(data);

			BufferedImage bufImg = ImageIO.read(new ByteArrayInputStream(imageBytes));

			// logger.debug("uploadPath {}", uploadRoot + filePath);
			String fileName = "CarMntnCost_" + fileId + "_" + SkmnsDateUtil.getNowPattern("yyyyMMddHHmmss") + STR_DOT + STR_EXTENSION;

			File file = new File(uploadRoot + filePath, fileName);
			if (!file.exists()) {
				file.mkdirs();
			}
			
			ImageIO.write(bufImg, STR_EXTENSION, file);

			imgPath = downloadRoot + filePath + File.separator + file.getName();

			LOGGER.info(STR_INFO_MESSAGE + file.toPath().toString());
		} catch (IllegalStateException e) {
			LOGGER.error(ExceptionUtils.getMessage(e));
			throw new CommonResponseException(e);
		} catch (IOException e) {
			LOGGER.error(ExceptionUtils.getMessage(e));
			throw new CommonResponseException(e);
		}

		return imgPath;

	}

	public static Map<String, String> tcmsUploadFile(final MultipartHttpServletRequest mRequest, final MultipartFile multipartFile,
			final String tempRootFilePath, final String firstName, final String userId) throws CommonResponseException {

		String nowData = SkmnsDateUtil.getNowPattern("yyyyMMdd");
		String tempPath = "";
		Map<String, String> fileInfo = new HashMap<>();
		// TODO 세차정비 모드일때 경로 확인 필요
		String tempFilePath = tempPath.concat(File.separator).concat("reservimg").concat(File.separator).concat(nowData).concat(File.separator).concat(userId)
				.concat(File.separator);
		String filePath = tempRootFilePath + tempFilePath;
		String fileName = null;
		File file = null;

		if (!multipartFile.isEmpty()) {
			file = new File(filePath);
			if (!file.exists()) {
				file.mkdirs();
			}

			if ("attFile".equals(multipartFile.getOriginalFilename())) {
				fileName = firstName + SkmnsDateUtil.getNowPattern(SkmnsDateUtil.YYYYMMDDHHMMSS) + STR_DOT + STR_EXTENSION;
			} else {
				if (multipartFile.getOriginalFilename().lastIndexOf(STR_DOT) > 0) {
					fileName = multipartFile.getOriginalFilename().substring(0, multipartFile.getOriginalFilename().lastIndexOf(STR_DOT))
							+ SkmnsDateUtil.getNowPattern(SkmnsDateUtil.YYYYMMDDHHMMSS)
							+ multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf(STR_DOT));
				} else {
					fileName = multipartFile.getOriginalFilename();
				}
			}

			file = new File(filePath, fileName);

			try {
				multipartFile.transferTo(file);

				fileInfo.put("fileName", fileName);
				fileInfo.put("filePath", "/" + filePath.substring(filePath.indexOf("uploads")));
			} catch (IllegalStateException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			} catch (IOException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}
			LOGGER.info(STR_INFO_MESSAGE + file.toPath().toString());
		}

		return fileInfo;
	}

	public static FileInfo tcmsTargetMoveFile(final String targetRootFilePath, final String tempRootFilePath, final String firstName, final FileInfo fileInfo)
			throws CommonResponseException {

		String tempPath = "";

		String targetFilePath = tempPath.concat(File.separator).concat(SkmnsDateUtil.getNowPattern("yyyy")).concat(File.separator)
				.concat(fileInfo.getReservId()).concat(File.separator);
		String inFilePath = tempRootFilePath.substring(0, tempRootFilePath.indexOf("uploads")) + fileInfo.getFilePath();
		String fileName = firstName + SkmnsDateUtil.getNowPattern(SkmnsDateUtil.YYYYMMDDHHMMSS) + STR_DOT + STR_EXTENSION;
		String outFilePath = targetRootFilePath + targetFilePath + fileName;

		File file = null;

		file = new File(targetRootFilePath + targetFilePath);
		if (!file.exists()) {
			file.mkdirs();
		}

		try {
			fileMove(inFilePath, outFilePath);

			fileInfo.setImgPath("/" + outFilePath.substring(outFilePath.indexOf("uploads")));

		} catch (IllegalStateException e) {
			LOGGER.error(ExceptionUtils.getMessage(e));
			throw new CommonResponseException(e);
		}

		return fileInfo;
	}

	public static File uploadFile(final MultipartHttpServletRequest mRequest, final MultipartFile multipartFile, final String filePath)
			throws CommonResponseException {

		String fileRootPath = SkmnsDebuggingUtil.getFileRootPath(mRequest);

		String fileName = null;
		File file = null;
		if (!multipartFile.isEmpty()) {
			file = new File(fileRootPath + filePath);
			if (!file.exists()) {
				file.mkdirs();
			}
			if (multipartFile.getOriginalFilename().lastIndexOf(STR_DOT) > 0) {
				fileName = multipartFile.getOriginalFilename().substring(0, multipartFile.getOriginalFilename().lastIndexOf(STR_DOT)) + STR_UNDERLINE
						+ SkmnsDateUtil.getNowPattern(SkmnsDateUtil.YYYYMMDDHHMMSS)
						+ multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf(STR_DOT));
			} else {
				fileName = multipartFile.getOriginalFilename();
			}
			file = new File(fileRootPath + filePath, fileName);
			try {
				multipartFile.transferTo(file);
			} catch (IllegalStateException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			} catch (IOException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}
			LOGGER.info(STR_INFO_MESSAGE + file.toPath().toString());
		}
		return file;
	}

	public static List<File> uploadAllFiles(final MultipartHttpServletRequest mRequest, final String filePath) throws CommonResponseException {

		String fileRootPath = SkmnsDebuggingUtil.getFileRootPath(mRequest);

		Iterator<String> fileNames = mRequest.getFileNames();
		Map<String, MultipartFile> fileMap = mRequest.getFileMap();

		List<File> savedFiles = new ArrayList<>();
		File file;

		if (fileMap.size() > 0) {
			file = new File(fileRootPath + filePath);
			if (!file.exists()) {
				file.mkdirs();
			}
		}
		while (fileNames.hasNext()) {
			String fileParameter = fileNames.next();
			MultipartFile multipartFile = fileMap.get(fileParameter);

			String fileName = null;
			if (multipartFile.getOriginalFilename().lastIndexOf(STR_DOT) > 0) {
				fileName = multipartFile.getOriginalFilename().substring(0, multipartFile.getOriginalFilename().lastIndexOf(STR_DOT)) + STR_UNDERLINE
						+ SkmnsDateUtil.getNowPattern(SkmnsDateUtil.YYYYMMDDHHMMSS)
						+ multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf(STR_DOT));
			} else {
				fileName = multipartFile.getOriginalFilename();
			}
			file = new File(fileRootPath + filePath, fileName);
			try {
				multipartFile.transferTo(file);
			} catch (IllegalStateException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			} catch (IOException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}
			savedFiles.add(file);
			LOGGER.info(STR_INFO_MESSAGE + file.toPath().toString());
		}

		return savedFiles;
	}

	public static File deleteFile(final HttpServletRequest request, final String filePath) throws CommonResponseException {
		String fileRootPath = SkmnsDebuggingUtil.getFileRootPath(request);
		File file = new File(fileRootPath + filePath);

		if (!file.delete()) {
			try {
				throw new FileNotFoundException();
			} catch (FileNotFoundException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}
		}
		LOGGER.info("Target for deleting file : " + file.getName());
		return file;
	}

	public static List<File> deleteAllFiles(final HttpServletRequest request, final String filePath, final boolean deleteSelfYn) throws CommonResponseException {
		String fileRootPath = SkmnsDebuggingUtil.getFileRootPath(request);
		File file = new File(fileRootPath + filePath);

		if (!file.exists()) {
			throw new CommonResponseException(CommonResultCode.ERROR_PATH_NOT_FOUND);
		}

		File[] fileList = file.listFiles();
		List<File> deletedFiles = new ArrayList<>();

		if (fileList != null) {
			for (int i = 0; i < fileList.length; i++) {
				if (fileList[i].isDirectory()) {
					deleteDirectory(fileList[i], deletedFiles);
				} else {
					if (fileList[i].delete()) {
						deletedFiles.add(fileList[i]);
					}
				}
			}
		}
		if (deleteSelfYn) {
			if (file.delete()) {
				deletedFiles.add(file);
			}
		}

		LOGGER.info("Target for deleting files : " + SkmnsDebuggingUtil.getPathRemoveRootPath(request, file.getAbsolutePath()));

		return deletedFiles;
	}

	private static boolean deleteDirectory(final File path, final List<File> savedFiles) throws CommonResponseException {
		if (!path.exists()) {
			return false;
		}

		File[] files = path.listFiles();
		if (files != null) {

			for (File file : files) {
				if (file.isDirectory()) {
					deleteDirectory(file, savedFiles);
				} else {
					if (file.delete()) {
						savedFiles.add(file);
					}
				}
			}
		}
		return path.delete();
	}

	public static File downloadFile(final HttpServletRequest request, final String filePath) throws CommonResponseException {
		String fileRootPath = SkmnsDebuggingUtil.getFileRootPath(request);
		File file = new File(fileRootPath + filePath);

		if (!file.exists()) {
			try {
				throw new FileNotFoundException();
			} catch (FileNotFoundException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}
		}

		return file;
	}

	public static ObjectNode getFileList(final HttpServletRequest request, final String path) throws CommonResponseException {
		List<String> list = new ArrayList<>();
		ObjectNode jsonObject = mapper.createObjectNode();

		String fileRootPath = SkmnsDebuggingUtil.getFileRootPath(request) + path;
		jsonObject.put(STR_FILE_PATH, SkmnsDebuggingUtil.getPathRemoveRootPath(request, fileRootPath + File.separator));
		jsonObject.put(STR_FILE_TYPE, "D");

		// String message = null;
		File filePath = new File(fileRootPath);

		if (!filePath.exists()) {
			throw new CommonResponseException(CommonResultCode.ERROR_PATH_NOT_FOUND);
		}
		File[] fileList = filePath.listFiles();
		int tab = 1;
		ArrayNode jsonArray = mapper.createArrayNode();
		if (fileList != null) {
			for (int i = 0; i < fileList.length; i++) {
				ObjectNode jsonObject2 = mapper.createObjectNode();
				if (fileList[i].isFile()) {
					// message = "[파일] ";
					// message += fileList[i].getName();
					// System.out.println(message);
					jsonObject2.put(STR_FILE_PATH, SkmnsDebuggingUtil.getPathRemoveRootPath(request, fileList[i].getPath()));
					jsonObject2.put(STR_FILE_TYPE, "F");
					jsonObject2.put(STR_FILE_NAME, fileList[i].getName());
					jsonArray.add(jsonObject2);
				}
			}
			for (int i = 0; i < fileList.length; i++) {
				ObjectNode jsonObject2 = mapper.createObjectNode();
				if (fileList[i].isDirectory()) {
					// message = "[디렉토리] ";
					// message += fileList[i].getName();

					// System.out.println(message);

					jsonObject2.put(STR_FILE_PATH, SkmnsDebuggingUtil.getPathRemoveRootPath(request, fileList[i].getPath()));
					jsonObject2.put(STR_FILE_TYPE, "D");
					jsonObject2.put(STR_FILE_NAME, fileList[i].getName());
					jsonObject2.set("files", subDirList(request, list, fileRootPath + File.separator + fileList[i].getName(), tab));

					Collections.reverse(list);

					// for (String str : list) {
					// System.out.println(str);
					// }
					list.clear();
					jsonArray.add(jsonObject2);
				}
			}
		}
		jsonObject.set("files", jsonArray);
		LOGGER.debug(jsonObject.toString());

		return jsonObject;
	}

	private static ArrayNode subDirList(final HttpServletRequest request, final List<String> list, final String source, final int tab)
			throws CommonResponseException {
		ArrayNode jsonArray = mapper.createArrayNode();
		File dir = new File(source);
		File[] fileList = dir.listFiles();

		StringBuffer strTab = new StringBuffer();
		for (int i = 0; i < tab; i++) {
			strTab.append("\t");
		}

		if (fileList != null) {
			try {
				for (int i = 0; i < fileList.length; i++) {
					ObjectNode jsonObject2 = mapper.createObjectNode();
					File file = fileList[i];
					if (file.isFile()) {
						// 파일이 있다면 파일 이름 출력
						if (i == 0) {
							// System.out.println("[디렉토리 이름] = " + dir.getPath() );
							list.add("[디렉토리 이름1] = " + dir.getPath());
						}
						// System.out.println(sTab + " 파일 이름 = " + file.getName());
						list.add(strTab.toString() + " 파일 이름 = " + file.getName());
						jsonObject2.put(STR_FILE_PATH, SkmnsDebuggingUtil.getPathRemoveRootPath(request, fileList[i].getPath()));
						jsonObject2.put(STR_FILE_TYPE, "F");
						jsonObject2.put(STR_FILE_NAME, fileList[i].getName());
						jsonArray.add(jsonObject2);
					}
				}
				for (int i = 0; i < fileList.length; i++) {
					ObjectNode jsonObject2 = mapper.createObjectNode();
					File file = fileList[i];
					if (file.isDirectory()) {
						list.add("[디렉토리 이름2] = " + dir.getPath());
						// System.out.println("[디렉토리 이름] = " + dir.getPath() );
						jsonObject2.put(STR_FILE_PATH, SkmnsDebuggingUtil.getPathRemoveRootPath(request, fileList[i].getPath()));
						jsonObject2.put(STR_FILE_TYPE, "D");
						jsonObject2.put(STR_FILE_NAME, fileList[i].getName());
						jsonObject2.set("files", subDirList(request, list, file.getCanonicalPath().toString(), tab + 1));
						jsonArray.add(jsonObject2);
					}
				}
			} catch (IOException e) {
				LOGGER.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}
		}

		return jsonArray;
	}

	public static void fileMove(final String inFileName, final String outFileName) throws CommonResponseException {
		try {
			FileInputStream fis = new FileInputStream(inFileName);
			FileOutputStream fos = new FileOutputStream(outFileName);

			int data = 0;
			while ((data = fis.read()) != -1) {
				fos.write(data);
			}
			fis.close();
			fos.close();

			// 복사한뒤 원본파일을 삭제함
			File del = new File(inFileName);
			del.delete();

		} catch (IOException e) {
			LOGGER.error(ExceptionUtils.getMessage(e));
			throw new CommonResponseException(e);
		}
	}
}

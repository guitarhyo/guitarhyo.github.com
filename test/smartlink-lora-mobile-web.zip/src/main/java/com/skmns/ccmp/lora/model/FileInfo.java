package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "FileInfo")
public class FileInfo implements Serializable {

	private static final long serialVersionUID = -1226227431807507625L;

	/** 사진아이디 */
	private String reservImgId;
	/** 예약아이디 */
	private String reservId;
	/** 이미지분류(‘운행전’,’운행후’) */
	private String category;
	/** 회원아이디 */
	private String userId;
	/** 이미지 URL 경로 */
	private String imgPath;
	/** 썸이미지 경로 */
	private String thumbPath;
	/** 정비 세차 종류 */
	private String imgKind;
	/** 정비 세차 아이디 */
	private String maintainId;
	/** 정비 세차 이미지 아이디 */
	private String maintain2ImgId;
	/** 파일 이름 */
	private String fileName;
	/** 파일 경로 */
	private String filePath;
	/** 내용 */
	private String comment;

	/**
	 * @return the comment
	 */
	public String getComment() {
		return this.comment;
	}

	/**
	 * @param comment
	 *            the comment to set
	 */
	public void setComment(final String comment) {
		this.comment = comment;
	}

	/**
	 * @return the imgKind
	 */
	public String getImgKind() {
		return this.imgKind;
	}

	/**
	 * @param imgKind
	 *            the imgKind to set
	 */
	public void setImgKind(final String imgKind) {
		this.imgKind = imgKind;
	}

	/**
	 * @return the maintainId
	 */
	public String getMaintainId() {
		return this.maintainId;
	}

	/**
	 * @param maintainId
	 *            the maintainId to set
	 */
	public void setMaintainId(final String maintainId) {
		this.maintainId = maintainId;
	}

	/**
	 * @return the maintain2ImgId
	 */
	public String getMaintain2ImgId() {
		return this.maintain2ImgId;
	}

	/**
	 * @param maintain2ImgId
	 *            the maintain2ImgId to set
	 */
	public void setMaintain2ImgId(final String maintain2ImgId) {
		this.maintain2ImgId = maintain2ImgId;
	}

	/**
	 * @return the reservImgId
	 */
	public String getReservImgId() {
		return this.reservImgId;
	}

	/**
	 * @param reservImgId
	 *            the reservImgId to set
	 */
	public void setReservImgId(final String reservImgId) {
		this.reservImgId = reservImgId;
	}

	/**
	 * @return the reservId
	 */
	public String getReservId() {
		return this.reservId;
	}

	/**
	 * @param reservId
	 *            the reservId to set
	 */
	public void setReservId(final String reservId) {
		this.reservId = reservId;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return this.category;
	}

	/**
	 * @param category
	 *            the category to set
	 */
	public void setCategory(final String category) {
		this.category = category;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(final String userId) {
		this.userId = userId;
	}

	/**
	 * @return the imgPath
	 */
	public String getImgPath() {
		return this.imgPath;
	}

	/**
	 * @param imgPath
	 *            the imgPath to set
	 */
	public void setImgPath(final String imgPath) {
		this.imgPath = imgPath;
	}

	/**
	 * @return the thumbPath
	 */
	public String getThumbPath() {
		return this.thumbPath;
	}

	/**
	 * @param thumbPath
	 *            the thumbPath to set
	 */
	public void setThumbPath(final String thumbPath) {
		this.thumbPath = thumbPath;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * @param fileName
	 *            the fileName to set
	 */
	public void setFileName(final String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the filePath
	 */
	public String getFilePath() {
		return this.filePath;
	}

	/**
	 * @param filePath
	 *            the filePath to set
	 */
	public void setFilePath(final String filePath) {
		this.filePath = filePath;
	}

}
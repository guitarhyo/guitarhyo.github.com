package com.skmns.ccmp.lora.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.dao.MwebDAO;
import com.skmns.ccmp.lora.model.AreaAddr;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.MwebCar;

@Service
public class MwebService {

	@Autowired
	private MwebDAO mwebDAO;


	public List<MwebCar> selectCarList(final MwebCar param) throws CommonResponseException {
		return this.mwebDAO.mweb_Car_FindByCarList(param);
	}
	
	public List<MwebCar> selectMovingCafeCarList(final MwebCar param) throws CommonResponseException {
		return this.mwebDAO.Mweb_MovingCafe_Car_FindByCarList(param);
	}
	public int selectMovingCafeCarUpdateCnt(final MwebCar param) throws CommonResponseException {
		return this.mwebDAO.Mweb_MovingCafe_Car_Update_Count(param);
	}
	
	public MwebCar Mweb_MovingCafe_Car_FindByCarInfo(final MwebCar param) throws CommonResponseException {
		return this.mwebDAO.Mweb_MovingCafe_Car_FindByCarInfo(param);
	}
	public CommonResult Mweb_MovingCafe_Car_Create(final MwebCar param) throws CommonResponseException {
		return this.mwebDAO.Mweb_MovingCafe_Car_Create(param);
	}
	
	public List<AreaAddr> selectMovingCafeAreaAddressList(final AreaAddr param) throws CommonResponseException {
		return this.mwebDAO.Mweb_MovingCafe_Area_AddressList(param);
	}
	
	
}

package com.skmns.ccmp.lora.model.api;

import org.apache.ibatis.type.Alias;

@Alias(value = "ResDrvHeader")
public class ResDrvHeader {

	private int code;
	private String message;

	ResDrvHeader() {
		this.code = 0;
		this.message = "success";
	}

	ResDrvHeader(final int c, final String m) {
		this.code = c;
		this.message = m;
	}

	public int getCode() {
		return this.code;
	}

	public void setCode(final int code) {
		this.code = code;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(final String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseHeader [code=");
		builder.append(code);
		builder.append(", message=");
		builder.append(message);
		builder.append("]");
		return builder.toString();
	}

	
}

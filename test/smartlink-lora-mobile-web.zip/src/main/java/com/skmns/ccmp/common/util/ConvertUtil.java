package com.skmns.ccmp.common.util;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ConvertUtil
 * 
 * @deprecated use com.skmns.ccmp.lora.util.ByteUtil
 * @author sh.yu
 *
 */
@Deprecated
public class ConvertUtil {
	private static final Logger logger = LoggerFactory.getLogger(ConvertUtil.class);

	public static byte[] hexStringToByteArray(final String hexString) {
		/*
		 * http://stackoverflow.com/questions/8890174/in-java-how-do-i-convert-a-hex-string-to-a-byte
		 *
		 * String s="f263575e7b00a977a8e9a37e08b9c215feb9bfb2f992b2b8f11e"; byte[] b = new BigInteger(s,16).toByteArray();
		 *
		 */

		byte[] bArr = new BigInteger(hexString, 16).toByteArray();

		if (logger.isDebugEnabled()) {
			String logStr = "";
			for (int i = 0; i < bArr.length; i++) {
				if (i > 0) {
					logStr += ",";
				}
				logStr += bArr[i];
			}
			logger.debug("byteArr.length : {}", bArr.length);
			logger.debug("byteArr : {}", logStr);
		}

		return bArr;
	}

	/**
	 *
	 * @param bytes
	 * @return
	 */
	public static int byteArrayToInt(final byte[] bytes) {
		int x = java.nio.ByteBuffer.wrap(bytes).getInt();
		return x;

		//		int i = 0;
		//		if (bytes.length == 4) {
		//			i = bytes[0] << 24 | (bytes[1] & 0xFF) << 16 | (bytes[2] & 0xFF) << 8 | bytes[3] & 0xFF;
		//			logger.debug("i : {}", i);
		//			return i;
		//		}
		//		do {
		//
		//			if (bytes.length == 3) {
		//				return (bytes[0] & 0xFF) << 16 | 0x0 | (bytes[1] & 0xFF) << 8 | bytes[2] & 0xFF;
		//			}
		//			if (bytes.length == 2) {
		//				return (bytes[0] & 0xFF) << 8 | 0x0 | bytes[1] & 0xFF;
		//			}
		//		} while (bytes.length != 1);
		//		return bytes[0] & 0xFF | 0x0;
	}

	public static short byteArrayToShort(final byte[] bytes) {
		short x = java.nio.ByteBuffer.wrap(bytes).getShort();
		return x;

		//		short i = 0;
		//		if (bytes.length == 2) {
		//			i = (short) ((bytes[0] & 0xFF) << 8 | bytes[1] & 0xFF);
		//			logger.debug("i : {}", i);
		//			return i;
		//		}
		//		do {
		//		} while (bytes.length != 1);
		//		return (short) (bytes[0] & 0xFF | 0x0);
	}
	
	/**
	 * int형을 byte배열로 바꿈
	 * 
	 * @author LimKyungTae
	 * @param integer
	 * @param buffSize
	 * @return
	 */
	public static byte[] intToByteArray(int integer, int buffSize) {
 
		ByteBuffer buff = ByteBuffer.allocate(buffSize);
		buff.order(ByteOrder.BIG_ENDIAN);
 
		buff.putInt(integer);
 
		logger.debug("intToByteArray result ::: {}", buff);
		return buff.array();
	}
	
	/**
	 * Header ~ Body bytearray를 xor 연산
	 * 
	 * @author LimKyungTae
	 * @param data
	 * @return checkSumNum
	 */
	public static int makeCheckSum(byte[] headerByteArray, byte[] bodyByteArray){
		
		int checkSumNum = 0;

		for (int i=0; i < headerByteArray.length; i++) {
			checkSumNum = (byte) (headerByteArray[i] ^ checkSumNum);
		}
		
		for (int i=0; i < bodyByteArray.length; i++) {
			checkSumNum = (byte) (bodyByteArray[i] ^ checkSumNum);
		}
		
		logger.debug("# CHECK SUM NUM	:::  {}",checkSumNum);
		
		return checkSumNum;
		
	}
	
	/**
	 * checksum 유효성 검증
	 * @param bytes
	 * @return	boolean
	 */
	public static boolean chksum(byte[] bytes) {
		
		int j = 0;
		int i = 0;
		int k = bytes.length;

		while (i < k - 1) {
			j = (byte) (bytes[i] ^ j);
			i += 1;
		}

		if (j != bytes[(k - 1)]) {
			logger.info("GetData CRC Error (" + j + ") pktcrc (" + bytes[(k - 1)] + ")");
			return Boolean.FALSE.booleanValue();
		}
		return Boolean.TRUE.booleanValue();
	}
}

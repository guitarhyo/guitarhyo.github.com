package com.skmns.ccmp.lora.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.Agree;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Corp;
import com.skmns.ccmp.lora.model.Member;

@Repository
public class JoinDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = JoinDAO.class.getPackage().getName() + ".";

	public List<Agree> usp_api_Terms_FindByCategoryIds(final Agree agree) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_api_Terms_FindByCategoryIds", agree);
	}

	public CommonResult usp_api_Member_ExistByUserId(final String userId) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_api_Member_ExistByUserId", userId);
	}

	public List<Corp> usp_api_Corp_FindByCorpName(final String corpName) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_api_Corp_FindByCorpName", corpName);
	}

	public CommonResult usp_api_Corp_CheckCertCode(final Corp corp) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_api_Corp_CheckCertCode", corp);
	}

	public CommonResult usp_api_AuthPhone_Create(final String mobilePhone) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_api_AuthPhone_Create", mobilePhone);
	}

	public CommonResult usp_api_AuthPhone_AuthkeyCheck(final Map<String, String> map) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_api_AuthPhone_AuthkeyCheck", map);
	}

	public CommonResult usp_Lora_Web_Member_Create(final Member member) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Member_Create", member);
	}

	public int select_Duplicated_EmpNumber(final Member member) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "select_Duplicated_EmpNumber", member);
	}

}

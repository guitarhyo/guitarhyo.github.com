package com.skmns.ccmp.common.constant;

import com.skmns.ccmp.common.protocol.CommonResultCode;

public class ConstantCode4WebContents {
	protected ConstantCode4WebContents() {
		throw new UnsupportedOperationException();
	}

	public static final String PATH_LOGIN = "/login?returnUrl=";
	public static final String PATH_JS = "/resources/js";
	public static final String PATH_IMAGE = "/resources/images";
	public static final String PATH_JQUERY = "/resources/plugin/jquery";
	public static final String PATH_CSS = "/resources/css";
	public static final String PATH_PLUGIN = "/resources/plugin";

	public static final String AJAX_CONNECTION_ERROR = "장애발생! 다시 시도해주세요.<br>계속된 장애 발생시 관리자에게 연갈바랍니다.";
	public static final String TITLE = "SKMNS Standard Web ver0.1";

	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String Y = "Y";
	public static final String N = "N";

	public static final String INSERT_MODE = "I";
	public static final String UPDATE_MODE = "U";
	public static final String DELETE_MODE = "D";

	public static final String RESPONSE_CODE = "responseCode";
	public static final String RESPONSE_MESSAGE = "responseMessage";
	public static final String RESPONSE_DATA = "responseData";
	public static final String ADDITIONAL_MESSAGE = "additionalMessage";

	public static final String SUCCESS_CODE = CommonResultCode.SUCCESS_NORMAL.getCode();
	public static final String SUCCESS_MESSAGE = CommonResultCode.SUCCESS_NORMAL.getMessage();

	/**
	 * 파일 업로드 SIZE
	 */
	public static final long FILE_UPLOAD_SIZE_MB = 300;
	public static final long FILE_UPLOAD_SIZE_BYTE = 300 * 1024;

	/**
	 * 파일 업로드 ERROR CODE
	 */
	public static final String FILE_ERROR_DATA_CODE = "EF00";
	public static final String FILE_ERROR_DATA_MESSAGE = "데이터 정보 누락 입니다.";
	public static final String FILE_ERROR_SIZE_CODE = "EF01";
	public static final String FILE_ERROR_SIZE_MESSAGE = "파일 크기가 ".concat(String.valueOf(FILE_UPLOAD_SIZE_MB)).concat("KB보다 큽니다.");
	public static final String FILE_ERROR_CONTENTS_TYPE_CODE = "EF02";
	public static final String FILE_ERROR_CONTENTS_TYPE_MESSAGE = "지원하지 않는 파일 형식입니다.";
	public static final String FILE_ERROR_EXTENSION_CODE = "EF03";
	public static final String FILE_ERROR_EXTENSION_MESSAGE = "지원하지 않는 확장자입니다.";
	public static final String FILE_EXTENSION_CODE = "EF04";
	public static final String FILE_EXTENSION_MESSAGE = "서버오류 입니다.";

	/**
	 * 파일 콘텐츠 타입
	 */
	public static final String FILE_CONTENTS_TYPE_PJPEG = "image/pjpeg"; // pjpeg
	public static final String FILE_CONTENTS_TYPE_JPEG = "image/jpeg"; // jpeg
	public static final String FILE_CONTENTS_TYPE_PNG = "image/png"; // png

	/**
	 * 파일 확장자
	 */
	public static final String FILE_EXTENSION_JPG = "JPG"; // JPG
	public static final String FILE_EXTENSION_JPEG = "JPEG"; // JPEG
	public static final String FILE_EXTENSION_PNG = "PNG"; // PNG

	/**
	 * 파일 다운로드 PATH
	 */
	public static final String FILE_DOWNLOAD_PATH = "";

	/**
	 * 파일 업로드 PATH
	 */
	public static final String FILE_PATH_TMP_CAR_IMAGE = "tmp/car/";
	public static final String FILE_PATH_CAR_IMAGE = "car/";
}

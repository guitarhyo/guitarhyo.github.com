package com.skmns.ccmp.common.interceptor;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.skmns.ccmp.common.constant.ConstantCode4WebContents;
import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.protocol.CommonResultCode;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.service.MemberService;

/**
 * AuthInterceptor
 *
 * <pre>
 *
 * </pre>
 *
 * @author 201510077
 *
 */
public class AuthInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger(AuthInterceptor.class);

	@Autowired
	SessionManager sessionManager;

	@Autowired
	private MemberService memberService;

	@Override
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler) throws CommonResponseException {
		logger.debug("request.getContextPath() : {}", request.getContextPath());
		logger.debug("getMaxInactiveInterval : {} sec", "" + this.sessionManager.getMaxInactiveInterval(request));
		logger.debug("sessionManager.isLogin(request) : {}", "" + this.sessionManager.isLogin(request));

		String requestURI = request.getRequestURI();
		if (!this.sessionManager.isLogin(request)) {
			if (request.getHeader("Accept").indexOf(MediaType.APPLICATION_JSON_VALUE) > -1) {
				// Ajax 요청 처리
				logger.debug("has JSON header : {}", MediaType.APPLICATION_JSON_VALUE);
				throw new CommonResponseException(CommonResultCode.ERROR_NOT_ALLOWED_MEMBER);
				
			}

			try {
				String rU = "/app/login";
				String loginUrl = ConstantCode4WebContents.PATH_LOGIN;
				if (requestURI.startsWith("/app")) {
					// authKey
					String authKey = request.getHeader("AuthKey");
					if ("null".equals(authKey)) {
						authKey = null;
						logger.debug("authKey is not null -> authKey is 'null' String.");
					}

					if (StringUtils.isNotBlank(authKey)) {
						// 자동로그인 처리
						logger.info("doAutoLogin by authKey ");
						authKey = URLDecoder.decode(authKey, "UTF-8");
						String deviceId = request.getHeader("Device-ID");
						logger.debug("deviceId pushKey : {}", deviceId);

						Member member = this.memberService.doAutoLogin(request, authKey, deviceId);
						if (!"0".equals(member.getCode()) && !"-4".equals(member.getCode())) {
							logger.debug("doAutoLogin FAIL. code : {}", member.getCode());
							loginUrl = "/app/login?returnUrl=";
							rU = request.getContextPath() + loginUrl + request.getRequestURL();
						} else {
							// 자동로그인 성공
							logger.debug("doAutoLogin success");
							return true;
						}
					} else {
						loginUrl = "/app/login?returnUrl=";
						rU = request.getContextPath() + loginUrl + request.getRequestURL();
					}
				}

				response.sendRedirect(rU);

			} catch (IOException e) {
				e.printStackTrace();
				logger.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}
			return false;
		} else { // 로그인 이지만 상태값 확인필요 CMS에서 상태 바뀔경우 체크필요
			try {
				String rU = "/app/login";

				if (requestURI.startsWith("/app")) {
					if (this.sessionManager.isLogin(request)) {
						Member param = this.sessionManager.getMember(request);
						Member member = this.memberService.getMemberInfo(param);

						if (member == null || "탈퇴회원".equals(member.getGubun()) || "정지회원".equals(member.getGubun()) || "휴면회원".equals(member.getGubun())) {
							rU = request.getContextPath() + "/app/login";
							this.sessionManager.removeSession(request);
							response.sendRedirect(rU);
							return false;
						} else {
							logger.debug("getMember success");
							return true;
						}
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				logger.error(ExceptionUtils.getMessage(e));
				throw new CommonResponseException(e);
			}

		}
		
		

		return true;
	}
}

package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "LoginVO")
public class LoginVO implements Serializable {

	private static final long serialVersionUID = 2047018251207704151L;

	/** 회원 ID */
	private String memberId;
	/** 고객사 명 */
	private String custNm;
	/** 고객사 아이디 */
	private String custId;
	/** 로그인 ID */
	private String loginId;
	/** 로그인 명 */
	private String loginNm;
	/** 비밀번호 */
	private String passwd;
	/** 마지막 비밀번호 변경 일시 */
	private String lastPasswdUpdDt;
	/** 권한 코드 */
	private String authCd;
	/** 사번 */
	private String custMemberId;
	/** 휴대 전화 번호 */
	private String cellTelNo;
	/** 이메일 */
	private String email;
	/** 마지막 로그인 일시 */
	private String lastLoginDt;
	/** 로그인 실패 수 */
	private int loginFailCnt;
	/** 계약 시작 일자 */
	private String contractStartDt;
	/** 계약 종료 일자 */
	private String contractEndDt;
	/** 가입 상태 코드 */
	private String joinStatusCd;
	/** 가입 일시 */
	private String joinDt;
	/** 탈퇴 일시 */
	private String withdrawDt;
	/** 휴먼 일시 */
	private String humanDt;
	/** 사용 중지 일시 */
	private String useStopDt;
	/** 메모 */
	private String memo;
	/** 부서 */
	private String departmentNm;

	// private int corpId ;

	public String getDepartmentNm() {
		return this.departmentNm;
	}

	public void setDepartmentNm(final String departmentNm) {
		this.departmentNm = departmentNm;
	}

	/** 회원 ID */
	public String getMemberId() {
		return this.memberId;
	}

	/** 회원 ID */
	public void setMemberId(final String memberId) {
		this.memberId = memberId;
	}

	/** 고객사 명 */
	public String getCustNm() {
		return this.custNm;
	}

	/** 고객사 명 */
	public void setCustNm(final String custNm) {
		this.custNm = custNm;
	}

	/** 고객사 아이디 */
	public String getCustId() {
		return this.custId;
	}

	/** 고객사 아이디 */
	public void setCustId(final String custId) {
		this.custId = custId;
	}

	/** 로그인 ID */
	public String getLoginId() {
		return this.loginId;
	}

	/** 로그인 ID */
	public void setLoginId(final String loginId) {
		this.loginId = loginId;
	}

	/** 로그인 명 */
	public String getLoginNm() {
		return this.loginNm;
	}

	/** 로그인 명 */
	public void setLoginNm(final String loginNm) {
		this.loginNm = loginNm;
	}

	/** 비밀번호 */
	public String getPasswd() {
		return this.passwd;
	}

	/** 비밀번호 */
	public void setPasswd(final String passwd) {
		this.passwd = passwd;
	}

	/** 마지막 비밀번호 변경 일시 */
	public String getLastPasswdUpdDt() {
		return this.lastPasswdUpdDt;
	}

	/** 마지막 비밀번호 변경 일시 */
	public void setLastPasswdUpdDt(final String lastPasswdUpdDt) {
		this.lastPasswdUpdDt = lastPasswdUpdDt;
	}

	/** 권한 코드 */
	public String getAuthCd() {
		return this.authCd;
	}

	/** 권한 코드 */
	public void setAuthCd(final String authCd) {
		this.authCd = authCd;
	}

	/** 사번 */
	public String getCustMemberId() {
		return this.custMemberId;
	}

	/** 사번 */
	public void setCustMemberId(final String custMemberId) {
		this.custMemberId = custMemberId;
	}

	/** 휴대 전화 번호 */
	public String getCellTelNo() {
		return this.cellTelNo;
	}

	/** 휴대 전화 번호 */
	public void setCellTelNo(final String cellTelNo) {
		this.cellTelNo = cellTelNo;
	}

	/** 이메일 */
	public String getEmail() {
		return this.email;
	}

	/** 이메일 */
	public void setEmail(final String email) {
		this.email = email;
	}

	/** 마지막 로그인 일시 */
	public String getLastLoginDt() {
		return this.lastLoginDt;
	}

	/** 마지막 로그인 일시 */
	public void setLastLoginDt(final String lastLoginDt) {
		this.lastLoginDt = lastLoginDt;
	}

	/** 로그인 실패 수 */
	public int getLoginFailCnt() {
		return this.loginFailCnt;
	}

	/** 로그인 실패 수 */
	public void setLoginFailCnt(final int loginFailCnt) {
		this.loginFailCnt = loginFailCnt;
	}

	/** 계약 시작 일자 */
	public String getContractStartDt() {
		return this.contractStartDt;
	}

	/** 계약 시작 일자 */
	public void setContractStartDt(final String contractStartDt) {
		this.contractStartDt = contractStartDt;
	}

	/** 계약 종료 일자 */
	public String getContractEndDt() {
		return this.contractEndDt;
	}

	/** 계약 종료 일자 */
	public void setContractEndDt(final String contractEndDt) {
		this.contractEndDt = contractEndDt;
	}

	/** 가입 상태 코드 */
	public String getJoinStatusCd() {
		return this.joinStatusCd;
	}

	/** 가입 상태 코드 */
	public void setJoinStatusCd(final String joinStatusCd) {
		this.joinStatusCd = joinStatusCd;
	}

	/** 가입 일시 */
	public String getJoinDt() {
		return this.joinDt;
	}

	/** 가입 일시 */
	public void setJoinDt(final String joinDt) {
		this.joinDt = joinDt;
	}

	/** 탈퇴 일시 */
	public String getWithdrawDt() {
		return this.withdrawDt;
	}

	/** 탈퇴 일시 */
	public void setWithdrawDt(final String withdrawDt) {
		this.withdrawDt = withdrawDt;
	}

	/** 휴먼 일시 */
	public String getHumanDt() {
		return this.humanDt;
	}

	/** 휴먼 일시 */
	public void setHumanDt(final String humanDt) {
		this.humanDt = humanDt;
	}

	/** 사용 중지 일시 */
	public String getUseStopDt() {
		return this.useStopDt;
	}

	/** 사용 중지 일시 */
	public void setUseStopDt(final String useStopDt) {
		this.useStopDt = useStopDt;
	}

	/** 메모 */
	public String getMemo() {
		return this.memo;
	}

	/** 메모 */
	public void setMemo(final String memo) {
		this.memo = memo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}

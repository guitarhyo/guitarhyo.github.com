package com.skmns.ccmp.lora.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.Car;
import com.skmns.ccmp.lora.model.MaintenanceReport;

@Repository
public class MaintenanceReportDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = MaintenanceReportDAO.class.getPackage().getName() + ".";

	public int usp_CarMntnCostHst_Ins(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CarMntnCostHst_Ins", reportVO);
	}

	public List<MaintenanceReport> usp_CarMntnCostHst_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCostHst_Req", reportVO);
	}

	/**
	 * 상세 조회
	 *
	 * @param reportVO
	 * @return
	 * @throws CommonResponseException
	 */
	public List<MaintenanceReport> usp_CarMntnCostDtl_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCostDtl_Req", reportVO);
	}

	public int insertImage(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.insert(NS + "insertImage", reportVO);
	}

	public void usp_CarMntnCostHst_Upd(final MaintenanceReport reportVO) throws CommonResponseException {
		this.sqlSession.selectOne(NS + "usp_CarMntnCostHst_Upd", reportVO);
	}

	public void usp_CarMntnCostHst_Del(final MaintenanceReport reportVO) throws CommonResponseException {
		this.sqlSession.selectOne(NS + "usp_CarMntnCostHst_Del", reportVO);
	}

	public int updateImage(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.update(NS + "updateImage", reportVO);
	}

	public List<MaintenanceReport> usp_CarMntnCostItemSumStat_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCostItemSumStat_Req", reportVO);
	}


	public List<Car> usp_CarSearchByKeyword_Req(final Map<String, String> searchMap) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarSearchByKeyword_Req", searchMap);
	}
	
	public Car usp_Car_FindByID(final int carId) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Car_FindByID", carId);
	}
	
	public List<Map<String, Object>> usp_CarMntnCostDate_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCostDate_Req", reportVO);
	}

	public List<Map<String, Object>> usp_CarMntnCostDateCnt_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCostDateCnt_Req", reportVO);
	}

	public List<Map<String, Object>> usp_CarMntnCostItem_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCostItem_Req", reportVO);
	}

	public List<Map<String, Object>> usp_CarMntnCalcDistCnt_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCalcDistCnt_Req", reportVO);
	}

	public List<Map<String, Object>> usp_CarMntnCalcDist_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCalcDist_Req", reportVO);
	}

	public List<Map<String, Object>> usp_CarMntnCalcDistTotal_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCalcDistTotal_Req", reportVO);
	}

	public List<Map<String, Object>> usp_CarMntnCalcHst_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCalcHst_Req", reportVO);
	}

	public List<Map<String, Object>> usp_CarMntnCalcTotal_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CarMntnCalcTotal_Req", reportVO);
	}

	public MaintenanceReport usp_CarMntnCalcCnt_Req(final MaintenanceReport reportVO) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CarMntnCalcCnt_Req", reportVO);
	}
	
}

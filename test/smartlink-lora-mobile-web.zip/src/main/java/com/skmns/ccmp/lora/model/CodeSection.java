package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "CodeSection")
public class CodeSection implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String section;
	private String corpId;
	private String parentId;
	private String sectionValue;
	private String sectionValueID;
	private String code;
	private String sort;

	public CodeSection() {

	}

	public CodeSection(final String section, final String corpId) {
		this.section = section;
		this.corpId = corpId;
	}

	/**
	 * @return the parentId
	 */
	public String getParentId() {
		return this.parentId;
	}

	/**
	 * @param parentId
	 *            the parentId to set
	 */
	public void setParentId(final String parentId) {
		this.parentId = parentId;
	}

	/**
	 * @return the selection
	 */
	public String getSection() {
		return this.section;
	}

	/**
	 * @param selection
	 *            the selection to set
	 */
	public void setSection(final String section) {
		this.section = section;
	}

	/**
	 * @return the corpId
	 */
	public String getCorpId() {
		return this.corpId;
	}

	/**
	 * @param corpId
	 *            the corpId to set
	 */
	public void setCorpId(final String corpId) {
		this.corpId = corpId;
	}

	/**
	 * @return the sectionValue
	 */
	public String getSectionValue() {
		return this.sectionValue;
	}

	/**
	 * @param sectionValue
	 *            the sectionValue to set
	 */
	public void setSectionValue(final String sectionValue) {
		this.sectionValue = sectionValue;
	}

	/**
	 * @return the sectionValueID
	 */
	public String getSectionValueID() {
		return this.sectionValueID;
	}

	/**
	 * @param sectionValueID
	 *            the sectionValueID to set
	 */
	public void setSectionValueID(final String sectionValueID) {
		this.sectionValueID = sectionValueID;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(final String code) {
		this.code = code;
	}

	/**
	 * @return the sort
	 */
	public String getSort() {
		return this.sort;
	}

	/**
	 * @param sort
	 *            the sort to set
	 */
	public void setSort(final String sort) {
		this.sort = sort;
	}

}

package com.skmns.ccmp.common.util;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.transform.stream.StreamSource;

import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;

/**
 * XMLConverter
 * 
 * http://www.mkyong.com/spring3/spring-objectxml-mapping-example/
 * 
 * @author sh.yu
 *
 */
@Deprecated
public class XMLConverter {
	private Marshaller marshaller;
	private Unmarshaller unmarshaller;

	public Marshaller getMarshaller() {
		return marshaller;
	}

	public void setMarshaller(Marshaller marshaller) {
		this.marshaller = marshaller;
	}

	public Unmarshaller getUnmarshaller() {
		return unmarshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller) {
		this.unmarshaller = unmarshaller;
	}

	public void convertObjectToXML(Object object, String filepath)
		throws IOException {

//		FileOutputStream os = null;
//		try {
//			os = new FileOutputStream(filepath);
//			getMarshaller().marshal(object, new StreamResult(os));
//		} finally {
//			if (os != null) {
//				os.close();
//			}
//		}
	}

	public Object convertXMLToObject(String xmlStr) throws IOException {
		StringReader sr = new StringReader(xmlStr);
		return getUnmarshaller().unmarshal(new StreamSource(sr));
	}

}

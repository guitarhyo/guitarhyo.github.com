package com.skmns.ccmp.common;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skmns.ccmp.common.exception.CommonResponseException;

@Component
public final class TmapApiManager {

	private static final Logger logger = LoggerFactory.getLogger(TmapApiManager.class);
	private ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	private MessageSourceAccessor msa;

	/**
	 * 현재 주행위치 행정동 명으로 반환
	 *
	 * @param latitude
	 * @param longitude
	 * @return
	 * @throws CommonResponseException
	 */
	private JsonNode getLocationDesc(final String latitude, final String longitude) throws CommonResponseException {

		final String locationURL = msa.getMessage("con.tmap.api.locationUrl");
		String targetUrl = locationURL.replace("[lat]", latitude).replace("[lon]", longitude).replace("[callback]", "");
		JsonNode jsonObject = httpSender(targetUrl);

		return jsonObject.get("addressInfo");
	}

	private JsonNode httpSender(final String targetUrl) throws CommonResponseException {

		final String appKey = msa.getMessage("con.tmap.api.appKey");
		logger.debug("appKey: {}, url: {}", appKey, targetUrl);
		
		String responseJSon = "";
		JsonNode jsonObject = null;
		try {
			URL url = new URL(targetUrl);
			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			connection.setDoOutput(true); // xml내용을 전달하기 위해서 출력 스트림을 사용
			connection.setConnectTimeout(3000);
			connection.setInstanceFollowRedirects(false); // Redirect처리 하지 않음
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("appKey", appKey);

			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));

			String output;
			while ((output = br.readLine()) != null) {
				responseJSon += output;
			}
			br.close();

			jsonObject = mapper.readTree(responseJSon);
		} catch (Exception e) {
			throw new CommonResponseException(e);
		}

		return jsonObject;

	}

	public String getFullAddress(final String latitude, final String longitude) throws CommonResponseException {
		String fullAddress = "";
		try {

			if (StringUtils.isEmpty(latitude) || StringUtils.isEmpty(longitude) || StringUtils.equals(latitude, "0") || StringUtils.equals(longitude, "0") || StringUtils.equals(latitude, "0.0")
					|| StringUtils.equals(longitude, "0.0")) {
			} else {
				fullAddress = getLocationDesc(latitude, longitude).get("fullAddress").textValue();
			}

		} catch (Exception e) {
			logger.error("getFullAddress Exception : ", e);
		}
		return fullAddress;
	}
	
	private JsonNode post(final String targetUrl, final String body) throws Throwable {

		final String appKey = msa.getMessage("con.tmap.api.appKey");
		logger.info("appKey: {}, url: {}", appKey, targetUrl);
		logger.info("body : {}", body);
		
		String responseJSon = "";
		
		try {
			URL url = new URL(targetUrl);
			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			connection.setDoOutput(true); // xml내용을 전달하기 위해서 출력 스트림을 사용
			connection.setConnectTimeout(3000);
			connection.setInstanceFollowRedirects(false); // Redirect처리 하지 않음
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("appKey", appKey);
			
			OutputStream os = connection.getOutputStream();
			os.write(body.getBytes("UTF-8"));
			
			BufferedReader br = null;
			
			if ( connection.getResponseCode() == 200 )
				br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
			else
				br = new BufferedReader(new InputStreamReader(connection.getErrorStream(), "utf-8"));

			String output;
			while ((output = br.readLine()) != null) {
				responseJSon += output;
			}
			br.close();
			
			logger.info("response : {}", responseJSon);
			
			return mapper.readTree(responseJSon);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CommonResponseException(e);
		}

	}
	
	public JsonNode routeOptimization(final String body, final int pointCount) throws Throwable {
		String routeOptimization = msa.getMessage("con.tmap.api.routeOptimization100");
		
		if ( pointCount <= 10 ) {
			routeOptimization = msa.getMessage("con.tmap.api.routeOptimization10");
		} else if ( pointCount <= 20 ) {
			routeOptimization = msa.getMessage("con.tmap.api.routeOptimization20");
		} else if ( pointCount <= 30 ) {
			routeOptimization = msa.getMessage("con.tmap.api.routeOptimization30");
		}
		
		return post(routeOptimization, body);
	}

	public JsonNode routeSequential(final String body) throws Throwable {
		return post(msa.getMessage("con.tmap.api.routeSequential"), body);
	}

	public static void main(String[] args) {
		TmapApiManager m = new TmapApiManager();//37.510731	127.063814
		String latitude = "37.511932";
		String longitude = "127.078354";
		//lon=127.078354, lat=37.511932
		System.out.println(m.getFullAddress(latitude, longitude));
		
	}

















	/**
	 * 추가작업
	 */
	public Map<String, Object> getGeoInfo(String addressTxt) throws CommonResponseException {
		Map<String, Object> geoMap = new HashMap<>();
		String lat = "0";
		String lon = "0";
		try {
			final String locationURL = msa.getMessage("con.tmap.api.locationUrlGeo");
			String targetUrl = locationURL.replace("[addressFlag]", "F01").replace("[fullAddr]", addressTxt).replace("[callback]", "");
			JsonNode jsonObject = httpSender(targetUrl);

			lat = jsonObject.get("coordinateInfo").get("coordinate").get(0).get("lat").textValue();
			lon = jsonObject.get("coordinateInfo").get("coordinate").get(0).get("lon").textValue();
		} catch (Exception e) {
			logger.error("getGeoInfo Exception : ", e);
		}
		
		if ( ("0".equals(lat)) || ("0".equals(lon)) ) {
			try {
				final String locationURL = msa.getMessage("con.tmap.api.locationUrlGeo");
				String targetUrl = locationURL.replace("[addressFlag]", "F02").replace("[fullAddr]", addressTxt).replace("[callback]", "");
				JsonNode jsonObject = httpSender(targetUrl);

				lat = jsonObject.get("coordinateInfo").get("coordinate").get(0).get("newLat").textValue();
				lon = jsonObject.get("coordinateInfo").get("coordinate").get(0).get("newLon").textValue();
			} catch (Exception e) {
				logger.error("getGeoInfo Exception : ", e);
			}
			
		}
		
		geoMap.put("lat", lat);
		geoMap.put("lon", lon);
		
		return geoMap;
	}
}

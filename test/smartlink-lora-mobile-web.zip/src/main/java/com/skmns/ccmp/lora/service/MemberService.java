package com.skmns.ccmp.lora.service;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skmns.ccmp.common.enc.AES;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.common.util.SkmnsDateUtil;
import com.skmns.ccmp.lora.dao.MemberDAO;
import com.skmns.ccmp.lora.dao.MwebDAO;
import com.skmns.ccmp.lora.dao.MypageDAO;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Member;

/**
 * 회원 서비스
 *
 * @author shyu
 *
 */
@Service
public class MemberService {
	private static final Logger logger = LoggerFactory.getLogger(MemberService.class);

	@Autowired
	SessionManager sessionManager;

	@Autowired
	private MemberDAO memberDAO;

	@Autowired
	private MypageDAO mypageDAO;
	
	@Autowired
	private MwebDAO mwebDAO;

	@Autowired
	private HttpServletRequest request;
	
	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * 로그인 처리
	 *
	 * @param request
	 * @param member
	 * @param isPesist
	 * @return
	 */
	public Member doLogin(final HttpServletRequest request, final Member member, final boolean isPersist) {
		this.setPushInfo(request, member);

		String osVersion = request.getHeader("os-version");
		member.setOsVersion(osVersion);
		String modelName = request.getHeader("Model-Name");
		member.setModelName(modelName);
		
		Member mem = this.memberDAO.usp_Lora_Web_Member_Login(member);

		logger.debug("code : {}", mem.getCode());
		logger.debug("message : {}", mem.getMessage());
		String code = mem.getCode();
		String title = mem.getMessage();
		String message = mem.getMessage();
		if ("0".equals(mem.getCode()) || "-4".equals(mem.getCode())) {
			// 세션데이터 저장
			mem = this.mypageDAO.usp_api_Member_FindByUserId(member);
			if (mem == null) {// 관리자권한이면 null이나옴
				mem = new Member();
				mem.setCode("-1");
				mem.setMessage("아이디 또는 비밀번호가 틀립니다.");
				mem.setTitle("로그인에 실패하였습니다.");
				return mem;
			}
			mem.setUserId(member.getUserId()); // 프로시저 결과에 없으니..
			mem.setCode(code);
			mem.setTitle(title);
			mem.setMessage(message);

			logger.debug("isPersist : {} ", isPersist);
			mem.setAutoLogin("N");
			if (isPersist) {
				mem.setAutoLogin("Y");
			}

			// 무조건 key만들어서 보내기로 수정 2016-10-11
			//JsonObject autoLogin = new JsonObject();
			Map<String, String> autoLogin = new HashMap<>();
			autoLogin.put("loginId", mem.getUserId());
			autoLogin.put("passwd", member.getUserPass()); // 로그인한 패스워드
			autoLogin.put("corpId", mem.getCorpId()); // corpId
			autoLogin.put("loginDt", SkmnsDateUtil.getNow()); // 로그인 시간
			String autoLoginString = null;
			try {
				autoLoginString = mapper.writeValueAsString(autoLogin);
			} catch (JsonProcessingException e1) {
				e1.printStackTrace();
			}
			logger.debug("autoLogin : " + autoLoginString);

			try {
				String authKey = URLEncoder.encode(AES.encrypt(autoLoginString), "UTF-8");
				logger.debug("authKey : {} ", authKey);

				mem.setAuthKey(authKey);
			} catch (Exception e) {
				logger.info("autoLogin AES FAIL : " + e.toString());
				// retJsonObj.addProperty("autoLogin", "null");
			}
			mem.setIsLoginYn("Y");
			mem.setFirstNofeeYn("N");
			mem.setFirstNotiYn("N");
			mem.setFirstCoachYn("N");
			this.sessionManager.setMember(request, mem);
			this.request.setAttribute("isLogin", this.sessionManager.isLogin(request));

			this.request.setAttribute("member", mem);
			logger.debug("member.userId : {}", mem.getUserId());
			logger.debug("sessionManager  Member : {}", this.sessionManager.isLogin(request));

		} else {
			this.sessionManager.removeSession(request);
		}

		return mem;
	}

	/**
	 * 유저 상태 확인용
	 *
	 * @param member
	 * @return
	 */
	public Member getMemberInfo(final Member member) {

		return this.mypageDAO.usp_api_Member_FindByUserId(member);
	}

	/**
	 * 자동 로그인 처리
	 *
	 * @param loginKey
	 * @return
	 * @throws Exception
	 */
	public Member doAutoLogin(final HttpServletRequest reqest, final String authKey, final String pushKey) throws Exception {
		logger.info("doAutoLogin");
		logger.debug("pushKey : {}", pushKey);
		Member param = this.decryptAuthKey(authKey);
		//if (StringUtils.isNotBlank(pushKey)) {
			Device device = (Device) this.request.getAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE);
			logger.debug("isMobile : {}", device.isMobile());
			logger.debug("getDevicePlatform : {}", device.getDevicePlatform());
			String devicePlatform = device.getDevicePlatform().toString();
			if (!"IOS".equals(devicePlatform)) {
				devicePlatform = "Android"; // Push Service에서 대소문자 가림
			}
			param.setPushDevice(devicePlatform);
			param.setPushKey(pushKey);
		//}

		Member member = this.doLogin(reqest, param, true);

		logger.info(member.toString());

		return member;
	}
	
	/**
	 *
	 * @param authKey
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Member decryptAuthKey(final String authKey) {
		Member member = new Member();
		try {
			logger.debug("decryptAuthKey : " + authKey);
			String authStr = AES.decrypt(authKey);
			
			//JsonObject loginJson = SkmnsMapperUtil.writeObjectAsJsonObject(authStr);
			HashMap<String, String> loginJson = mapper.readValue(authStr, HashMap.class);

			member.setUserId(loginJson.get("loginId"));
			member.setUserPass(loginJson.get("passwd"));
			if (loginJson.get("corpId") != null) {
				member.setCorpId(loginJson.get("corpId"));
			}
			logger.debug("member.toString() : " + member.toString());

		} catch (Exception e) {
			logger.warn(e.getMessage());
			e.printStackTrace();
		}

		return member;
	}

	/**
	 * 로그아웃
	 *
	 * @param request
	 */
	public void doLogout(final HttpServletRequest request) {
		this.sessionManager.removeSession(request);
	}

	/**
	 * 아이디 찾기 발송
	 *
	 * @param Member
	 * @return CommonResult
	 */
	public CommonResult findId(final Member member) {
		return this.memberDAO.usp_api_Member_FindUserIdByNamePhone(member);
	}

	/**
	 * 비밀번호 초기화 발송
	 *
	 * @param Member
	 * @return CommonResult
	 */
	public CommonResult passInit(final Member member) {
		return this.memberDAO.usp_api_Member_UserPassByMobilePhone(member);
	}

	/**
	 * 핸드폰번호 및 이름 인증번호 발송
	 *
	 * @param Member
	 * @return CommonResult
	 */
	public CommonResult namePhoneSend(final Member member) {
		return this.memberDAO.usp_api_AuthPhone_ByMemberName(member);
	}

	/**
	 * 휴면회원 일반 전환
	 *
	 * @param Member
	 * @return CommonResult
	 */
	public CommonResult updateHumanLogin(final Member member) {
		return this.memberDAO.usp_api_Member_ResetLastLogin(member);
	}

	/**
	 * Http 헤더에 있는 Device-ID 값을 가져와서 세팅한다 (inApp)
	 *
	 * @param request
	 *            httprequest
	 * @param member
	 *            값 설정할 회원 객체
	 * @return
	 */
	public Member setPushInfo(final HttpServletRequest request, final Member member) {
		Member m = (Member) request.getAttribute("AUTH");
		if (m != null) {
			if (StringUtils.isNotBlank(m.getPushKey())) {
				member.setPushKey(m.getPushKey());
				member.setPushDevice(m.getPushDevice());
			}
		}
		return member;
	}
	
	
	/**
	 * 모바일 웹용 로그인
	 *
	 * @param request
	 *            httprequest
	 * @param member
	 *        
	 * @return
	 */
	public Member doMwebLogin(final HttpServletRequest request, final Member member) {
		this.setPushInfo(request, member);


		Member mem = new Member();
		mem.setCode("0");
		
		//사용자 접근 체크
		int ret = mwebDAO.usp_Admin_LoginCheck(member);
		if (ret < 1) {
			mem = new Member();
			mem.setCode("-99");
			return mem;
		}

		mem = this.mypageDAO.usp_api_Member_FindByUserId(member);
		if (mem == null) {// 관리자권한이면 null이나옴
			mem = new Member();
			mem.setCode("-98");
			return mem;
		}else{
			mem.setUserId(member.getUserId());
		}

		this.sessionManager.setMwebMember(request, mem);
		this.request.setAttribute("isLogin", this.sessionManager.isMwebLogin(request));

		this.request.setAttribute("member", mem);
		logger.debug("member.userId : {}", mem.getUserId());
		logger.debug("sessionManager  Member : {}", this.sessionManager.isMwebLogin(request));

		return mem;
	}

}

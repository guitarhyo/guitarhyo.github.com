package com.skmns.ccmp.lora.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.lora.model.AreaAddr;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.MwebCar;
import com.skmns.ccmp.lora.service.MwebService;

@Controller
@RequestMapping("/movingcafe")
public class MovingCafeController {
	private static final Logger logger = LoggerFactory.getLogger(MovingCafeController.class);
	private String jspPath = "/movingcafe";

	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private MwebService mwebService;


	
	/**
	 * 교원웰스 무빙카페 모니터링 및 길찾기
	 *
	 */
	@RequestMapping("/maps")
	public String movingCafeMaps() throws Exception {
		logger.debug("maps page start");
		AreaAddr areaAddr = new AreaAddr();
		areaAddr.setAddrType(0);//시도만
		List<AreaAddr>  list= mwebService.selectMovingCafeAreaAddressList(areaAddr);
		request.setAttribute("addressList", list);
		
		return this.jspPath + "/cafeMaps";
	}
	
	@RequestMapping("/maps/carList")
	@ResponseBody
	public List<MwebCar> movingCafeCarList(MwebCar param) throws Exception {
		
		List<MwebCar> list = mwebService.selectMovingCafeCarList(param);
		
		return list;
	}
	
	@RequestMapping("/maps/updateCnt")
	@ResponseBody
	public String carList(MwebCar param) throws Exception {

		int ret= mwebService.selectMovingCafeCarUpdateCnt(param);
		String retStr = String.valueOf(ret);
		
		return retStr;
	}
	
	@RequestMapping("/maps/carInfo")
	@ResponseBody
	public MwebCar carInfo(MwebCar param) throws Exception {

		MwebCar ret= mwebService.Mweb_MovingCafe_Car_FindByCarInfo(param);
		
		return ret;
	}
	
	@RequestMapping("/carReg")
	public String movingCafeRegPage() throws Exception {
		logger.debug("carReg page start");

		return this.jspPath + "/carReg";
	}
	
	@RequestMapping("/carReg/carInfo")
	@ResponseBody
	public CommonResult movingCafeReg(MwebCar param) throws Exception {

		CommonResult ret= mwebService.Mweb_MovingCafe_Car_Create(param);
		
		return ret;
	}
	
	@RequestMapping("/areaAddr/addressList")
	@ResponseBody
	public List<AreaAddr> movingCafeAreaAddressList(AreaAddr param) throws Exception {

		List<AreaAddr>  list = mwebService.selectMovingCafeAreaAddressList(param);
		
		return list;
	}
	
}

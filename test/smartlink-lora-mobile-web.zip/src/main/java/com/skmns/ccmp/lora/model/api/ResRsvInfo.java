package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResRsvInfo")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResRsvInfo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4761776059072632426L;

	private Integer rsvId;
	private String rsvUsg;
	private String svcTyp;
	private String svcSts;
	private String contrctCd;
	private String CarModl;
	private String carNum;
	private String memNm;
	private String sabun;
	private String part;
	private String rsvReqDt;
	private String rsvStDt;
	private String rsvEdDt;
	private String drvStDt;
	private String drvEdDt;
	private String returnDt;
	private String spot;
	private Integer useTm;
	private Float drvDist;
	private Integer cost;
	private String destination;
	private String memo;
	
	public String getMemNm() {
		return memNm;
	}
	public void setMemNm(String memNm) {
		this.memNm = memNm;
	}
	public Integer getRsvId() {
		return rsvId;
	}
	public void setRsvId(Integer rsvId) {
		this.rsvId = rsvId;
	}
	public String getRsvUsg() {
		return rsvUsg;
	}
	public void setRsvUsg(String rsvUsg) {
		this.rsvUsg = rsvUsg;
	}
	public String getSvcTyp() {
		return svcTyp;
	}
	public void setSvcTyp(String svcTyp) {
		this.svcTyp = svcTyp;
	}
	public String getSvcSts() {
		return svcSts;
	}
	public void setSvcSts(String svcSts) {
		this.svcSts = svcSts;
	}
	public String getContrctCd() {
		return contrctCd;
	}
	public void setContrctCd(String contrctCd) {
		this.contrctCd = contrctCd;
	}
	public String getCarModl() {
		return CarModl;
	}
	public void setCarModl(String carModl) {
		CarModl = carModl;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getSabun() {
		return sabun;
	}
	public void setSabun(String sabun) {
		this.sabun = sabun;
	}
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public String getRsvReqDt() {
		return rsvReqDt;
	}
	public void setRsvReqDt(String rsvReqDt) {
		this.rsvReqDt = rsvReqDt;
	}
	public String getRsvStDt() {
		return rsvStDt;
	}
	public void setRsvStDt(String rsvStDt) {
		this.rsvStDt = rsvStDt;
	}
	public String getRsvEdDt() {
		return rsvEdDt;
	}
	public void setRsvEdDt(String rsvEdDt) {
		this.rsvEdDt = rsvEdDt;
	}
	public String getDrvStDt() {
		return drvStDt;
	}
	public void setDrvStDt(String drvStDt) {
		this.drvStDt = drvStDt;
	}
	public String getDrvEdDt() {
		return drvEdDt;
	}
	public void setDrvEdDt(String drvEdDt) {
		this.drvEdDt = drvEdDt;
	}
	public String getReturnDt() {
		return returnDt;
	}
	public void setReturnDt(String returnDt) {
		this.returnDt = returnDt;
	}
	public String getSpot() {
		return spot;
	}
	public void setSpot(String spot) {
		this.spot = spot;
	}
	public Integer getUseTm() {
		return useTm;
	}
	public void setUseTm(Integer useTm) {
		this.useTm = useTm;
	}
	public Float getDrvDist() {
		return drvDist;
	}
	public void setDrvDist(Float drvDist) {
		this.drvDist = drvDist;
	}
	public Integer getCost() {
		return cost;
	}
	public void setCost(Integer cost) {
		this.cost = cost;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
		
}
package com.skmns.ccmp.lora.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.Corp;
import com.skmns.ccmp.lora.model.DriveInfo;
import com.skmns.ccmp.lora.model.api.ReqCheck;
import com.skmns.ccmp.lora.model.api.ReqParam;
import com.skmns.ccmp.lora.model.api.ResCarDist;
import com.skmns.ccmp.lora.model.api.ResCarInfo;
import com.skmns.ccmp.lora.model.api.ResDiagCode;
import com.skmns.ccmp.lora.model.api.ResDrvDyStat;
import com.skmns.ccmp.lora.model.api.ResDrvHst;
import com.skmns.ccmp.lora.model.api.ResDrvStat;
import com.skmns.ccmp.lora.model.api.ResGps;
import com.skmns.ccmp.lora.model.api.ResHipass;
import com.skmns.ccmp.lora.model.api.ResMemberInfo;
import com.skmns.ccmp.lora.model.api.ResMntnCost;
import com.skmns.ccmp.lora.model.api.ResPanelty;
import com.skmns.ccmp.lora.model.api.ResRsvInfo;
import com.skmns.ccmp.lora.model.api.ResSafeStats;
import com.skmns.ccmp.lora.model.api.ResponseResult;
import com.skmns.ccmp.lora.model.api.ResFrstLstDrvDt;

@Repository
public class ApiDriveDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = ApiDriveDAO.class.getPackage().getName() + ".";
	
	public Corp usp_Corp_FindById(String cropId) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Corp_FindById", cropId);
	}
	
	public ReqCheck usp_CustAPI_ReqValidation_Check(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CustAPI_ReqValidation_Check", reqParam);
	}

	public ResponseResult usp_CustAPI_AuthKey_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CustAPI_AuthKey_Req", reqParam);
	}
	
	public List<DriveInfo> usp_CustAPI_DrvHstGps_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_DrvHstGps_Req", reqParam);
	}
	
	public  List<ResGps> usp_CustAPI_DrvGpsDist_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_DrvGpsDist_Req", param);
	}
	
	public  List<ResMemberInfo> usp_CustAPI_MemberInfo_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_MemberInfo_Req", param);
	}
	
	public  List<ResCarInfo> usp_CustAPI_CarInfo_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_CarInfo_Req", param);
	}
	
	public  List<ResDrvHst> usp_CustAPI_DrvHst_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_DrvHst_Req", param);
	}
	public  List<ResGps> usp_CustAPI_DrvGps_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_DrvGps_Req", param);
	}
	
	public  List<ResDrvStat> usp_CustAPI_DrvStat_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_DrvStat_Req", param);
	}
	
	public  List<ResDrvStat> usp_CustAPI_DrvStatBySearchWord_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_DrvStatBySearchWord_Req", param);
	}
	
	public  List<ResMntnCost> usp_CustAPI_MntnCost_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_MntnCost_Req", param);
	}
	
	public  List<ResPanelty> usp_CustAPI_LawPanelty_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_LawPanelty_Req", param);
	}
	
	public  ResFrstLstDrvDt usp_CustAPI_FrstLstDrvDt_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CustAPI_FrstLstDrvDt_Req", param);
	}
	
	public  List<ResDiagCode> usp_CustAPI_DiagCode_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_DiagCode_Req", param);
	}
	
	public int usp_CustAPI_DrvUpd_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CustAPI_DrvHst_Upd", param);
	}
	
	public  ResCarDist usp_CustAPI_CarDist_Req(ReqParam param) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CustAPI_CarDist_Req", param);
	}
	
	public List<ResGps> usp_CustAPI_CarGps_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_CarGps_Req", reqParam);
	}
	
	public List<ResHipass> usp_CustAPI_Hipass_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_Hipass_Req", reqParam);
	}

	public int usp_CustAPI_MemReg_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CustAPI_Member_Ins", reqParam);
	}
	
	public int usp_CustAPI_DrvUpdDrvr_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CustAPI_DrvDrvr_Upd", reqParam);
	}
	
	public List<ResSafeStats> usp_CustAPI_SafeStats_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_SafeStats_Req", reqParam);
	}
	
	public ResDrvDyStat usp_CustAPI_DrvDyStat_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_CustAPI_DrvDyStat_Req", reqParam);
	}
	
	public List<ResRsvInfo> usp_CustAPI_RsvInfo_Req(ReqParam reqParam) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_CustAPI_RsvInfo_Req", reqParam);
	}
	
	
}

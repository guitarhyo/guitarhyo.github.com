package com.skmns.ccmp.lora.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.util.CommonUtil;
import com.skmns.ccmp.lora.dao.JoinDAO;
import com.skmns.ccmp.lora.model.Agree;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Corp;
import com.skmns.ccmp.lora.model.Member;

@Service
public class JoinService {

	@Autowired
	private JoinDAO joinDAO;

	public List<Agree> selectTermsList(final Agree agree) throws CommonResponseException {
		return this.joinDAO.usp_api_Terms_FindByCategoryIds(agree);
	}

	public CommonResult selectUserIdCnt(final String userId) throws CommonResponseException {
		return this.joinDAO.usp_api_Member_ExistByUserId(userId);
	}

	public List<Corp> selectCorpList(final String corpName) throws CommonResponseException {
		return this.joinDAO.usp_api_Corp_FindByCorpName(CommonUtil.clearDefaultXss(corpName));
	}

	public CommonResult selectCertCode(final Corp corp) throws CommonResponseException {
		return this.joinDAO.usp_api_Corp_CheckCertCode(corp);
	}

	public CommonResult sendMsg(final String mobilePhone) throws CommonResponseException {
		return this.joinDAO.usp_api_AuthPhone_Create(mobilePhone);
	}

	public CommonResult checkAuthKey(final Map<String, String> map) throws CommonResponseException {
		return this.joinDAO.usp_api_AuthPhone_AuthkeyCheck(map);
	}

	public CommonResult createMember(final Member member) throws CommonResponseException {
		return this.joinDAO.usp_Lora_Web_Member_Create(member);
	}

	public CommonResult selectDuplicatedEmpNumber(final Member member) throws CommonResponseException {
		CommonResult result;
		int count = this.joinDAO.select_Duplicated_EmpNumber(member);
		if (count == 0) {
			result = new CommonResult("0", "중복확인이 완료되었습니다.", "입력하신 사번은 사용 가능합니다.");
		} else {
			result = new CommonResult("-1", "이미 사용중인 사번입니다.", "이미 사용중인 사번입니다.");
		}

		return result;
	}

}

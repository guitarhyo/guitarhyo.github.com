package com.skmns.ccmp.lora.model.api;

import org.apache.ibatis.type.Alias;

@Alias(value = "ReqCheck")
public class ReqCheck {

	private int code;
	private String message;
	private int corpId =0;
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getCorpId() {
		return corpId;
	}
	public void setCorpId(int corpId) {
		this.corpId = corpId;
	}

	
	
}

package com.skmns.ccmp.lora.model.api;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResponseData {

	/**
	 * 공통 헤더
	 */
	private ResDrvHeader header;

	private List<ResMemberInfo> members;
	private List<ResCarInfo> cars;
	private List<ResDrvHst> drvHsts;
	private List<ResGps> gps;
	private List<ResDrvStat> drvStats;
	private List<ResMntnCost> mntnCosts;
	private List<ResPanelty> penalties;
	private List<ResDiagCode> diagInfo;
	private List<ResHipass> hipassInfo;
	private List<ResRsvInfo> rsvs;
	
	private String 	frstDrvDt;
	private String 	LstDrvDt;
	private Integer rowCnt;
	private Float 	lstDist;
	private String 	distDt;
	private ResDrvDyStat drvDyStat;
	
	
	/**
	 * constructor
	 */
	public ResponseData() {
		this.header = new ResDrvHeader();
	}

	/**
	 * constructor
	 *
	 * @param code
	 * @param message
	 */
	public ResponseData(final int code, final String message) {
		this.header = new ResDrvHeader(code, message);
	}
	

	/*
	 * getter & setter
	 */

	public ResDrvHeader getHeader() {
		return this.header;
	}

	public void setHeader(final ResDrvHeader header) {
		this.header = header;
	}
	
	public String getFrstDrvDt() {
		return frstDrvDt;
	}

	public void setFrstDrvDt(String frstDrvDt) {
		this.frstDrvDt = frstDrvDt;
	}

	public String getLstDrvDt() {
		return LstDrvDt;
	}

	public void setLstDrvDt(String lstDrvDt) {
		LstDrvDt = lstDrvDt;
	}

	public List<ResMemberInfo> getMembers() {
		return members;
	}

	public void setMembers(List<ResMemberInfo> members) {
		this.members = members;
	}
	

	public List<ResCarInfo> getCars() {
		return cars;
	}

	public void setCars(List<ResCarInfo> cars) {
		this.cars = cars;
	}

	public List<ResDrvHst> getDrvHsts() {
		return drvHsts;
	}

	public void setDrvHsts(List<ResDrvHst> drvHsts) {
		this.drvHsts = drvHsts;
	}
	
	public List<ResGps> getGps() {
		return gps;
	}

	public void setGps(List<ResGps> gps) {
		this.gps = gps;
	}

	public List<ResDrvStat> getDrvStats() {
		return drvStats;
	}

	public void setDrvStats(List<ResDrvStat> drvStats) {
		this.drvStats = drvStats;
	}
	
	public List<ResMntnCost> getMntnCosts() {
		return mntnCosts;
	}

	public void setMntnCosts(List<ResMntnCost> mntnCosts) {
		this.mntnCosts = mntnCosts;
	}
	

	public List<ResPanelty> getPenalties() {
		return penalties;
	}

	public void setPenalties(List<ResPanelty> penalties) {
		this.penalties = penalties;
	}

	public List<ResDiagCode> getDiagInfo() {
		return diagInfo;
	}

	public void setDiagInfo(List<ResDiagCode> diagInfo) {
		this.diagInfo = diagInfo;
	}
	
	public List<ResHipass> getHipassInfo() {
		return hipassInfo;
	}

	public void setHipassInfo(List<ResHipass> hipassInfo) {
		this.hipassInfo = hipassInfo;
	}
	
	public Float getLstDist() {
		return lstDist;
	}

	public void setLstDist(Float lstDist) {
		this.lstDist = lstDist;
	}

	public String getDistDt() {
		return distDt;
	}

	public void setDistDt(String distDt) {
		this.distDt = distDt;
	}

	public Integer getRowCnt() {
		return rowCnt;
	}

	public void setRowCnt(Integer rowCnt) {
		this.rowCnt = rowCnt;
	}
	
	public List<ResRsvInfo> getRsvs() {
		return rsvs;
	}

	public void setRsvs(List<ResRsvInfo> rsvs) {
		this.rsvs = rsvs;
	}

	public ResDrvDyStat getDrvDyStat() {
		return drvDyStat;
	}

	public void setDrvDyStat(ResDrvDyStat drvDyStat) {
		this.drvDyStat = drvDyStat;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseHanKuk [header=");
		builder.append(header);
		builder.append("]");
		return builder.toString();
	}

	
}

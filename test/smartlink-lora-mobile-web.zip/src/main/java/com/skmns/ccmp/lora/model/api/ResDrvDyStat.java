package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResDrvDyStat")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResDrvDyStat implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4761776059072632426L;

	private Integer carId;
	private String carNum;
	private String day;
	private Integer drvCnt;
	private Float dist;
	private Integer time;
	private List<ResSafeStats> safeStats;
	
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public Integer getDrvCnt() {
		return drvCnt;
	}
	public void setDrvCnt(Integer drvCnt) {
		this.drvCnt = drvCnt;
	}
	public Float getDist() {
		return dist;
	}
	public void setDist(Float dist) {
		this.dist = dist;
	}
	public Integer getTime() {
		return time;
	}
	public void setTime(Integer time) {
		this.time = time;
	}
	public List<ResSafeStats> getSafeStats() {
		return safeStats;
	}
	public void setSafeStats(List<ResSafeStats> safeStats) {
		this.safeStats = safeStats;
	}

	
		
}
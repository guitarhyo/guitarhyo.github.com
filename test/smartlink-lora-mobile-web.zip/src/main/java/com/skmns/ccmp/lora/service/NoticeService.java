package com.skmns.ccmp.lora.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Service;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.dao.NoticeDAO;
import com.skmns.ccmp.lora.model.Notice;
import com.skmns.ccmp.lora.model.Paging;

@Service
public class NoticeService {

	@Autowired
	private NoticeDAO noticeDAO;

	@Autowired
	private SessionManager sessionManager;

	@Autowired
	private HttpServletRequest request;

	public List<Notice> selectNoticeList(final Map<String, Object> map) throws CommonResponseException {
		return this.noticeDAO.usp_api_Notice_FindByPage(map);
	}

	/**
	 * selectMainNoticeList
	 *
	 * 메인페이지용 공지사항/이벤트
	 *
	 * @return
	 * @throws CommonResponseException
	 */
	public List<Notice> selectMainNoticeList(final String category) throws CommonResponseException {
		Map<String, Object> map = new HashMap<>();
		Notice notice = new Notice();
		notice.setCorpId(this.sessionManager.getMember(this.request).getCorpId());
		Device device = (Device) this.request.getAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE);

		if (device.isMobile()) {
			notice.setDevice("MOBILE");
		} else {
			notice.setDevice("PC");
		}

		notice.setCategory(category);
		notice.setIsMainOpen("1");

		Paging paging = new Paging();
		paging.setPageNum(1);
		paging.setPageRows(5);

		map.put("Notice", notice);
		map.put("Paging", paging);

		return this.noticeDAO.usp_api_Notice_FindByPage(map);
	}

	public List<Notice> selectPopNoticeList(final Notice notice) throws CommonResponseException {
		return this.noticeDAO.usp_api_Popup_FindByDevice(notice);
	}

}

package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResMntnCost")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResMntnCost implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -6094716930295690299L;
	private Integer drvrId;
	private Integer carId;
	private String carNum;
	private String costTyp;
	private String costDtl;
	private String costDy;
	private Integer costs;
	private Integer unitCost;
	private String payTyp;
	private Integer refund;
	
	public Integer getDrvrId() {
		return drvrId;
	}
	public void setDrvrId(Integer drvrId) {
		this.drvrId = drvrId;
	}
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getCostTyp() {
		return costTyp;
	}
	public void setCostTyp(String costTyp) {
		this.costTyp = costTyp;
	}
	public String getCostDtl() {
		return costDtl;
	}
	public void setCostDtl(String costDtl) {
		this.costDtl = costDtl;
	}
	public String getCostDy() {
		return costDy;
	}
	public void setCostDy(String costDy) {
		this.costDy = costDy;
	}
	public Integer getCosts() {
		return costs;
	}
	public void setCosts(Integer costs) {
		this.costs = costs;
	}
	public Integer getUnitCost() {
		return unitCost;
	}
	public void setUnitCost(Integer unitCost) {
		this.unitCost = unitCost;
	}
	public String getPayTyp() {
		return payTyp;
	}
	public void setPayTyp(String payTyp) {
		this.payTyp = payTyp;
	}
	public Integer getRefund() {
		return refund;
	}
	public void setRefund(Integer refund) {
		this.refund = refund;
	}
	
	
	
	
}
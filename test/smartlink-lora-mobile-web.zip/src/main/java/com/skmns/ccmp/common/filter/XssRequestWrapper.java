package com.skmns.ccmp.common.filter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class XssRequestWrapper extends HttpServletRequestWrapper {

	public XssRequestWrapper(final HttpServletRequest request) {
		super(request);
	}

	@Override
	public String getParameter(final String parameter) {

		String value = super.getParameter(parameter);
		if (value == null) {
			return null;
		}
		return this.clearDefaultXss(value);
	}

	@Override
	public String[] getParameterValues(final String parameter) {

		String[] values = super.getParameterValues(parameter);
		if (values == null) {
			return null;
		}
		int count = values.length;
		String[] encodedValues = new String[count];
		for (int i = 0; i < count; i++) {
			encodedValues[i] = this.clearDefaultXss(values[i]);
		}
		return encodedValues;
	}

	@Override
	public Map<String, String[]> getParameterMap() {

		Map<String, String[]> map = new HashMap<>(super.getParameterMap());
		Iterator<String> iter = map.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			map.put(key, this.getParameterValues(key));
		}

		return map;
	}

	@Override
	public String getHeader(final String header) {
		String value = super.getHeader(header);
		if (value == null) {
			return null;
		}

		value = this.clearDefaultXss(value);
		return value;
	}

	public String clearDefaultXss(String str) {
		if (str == null) {
			return null;
		}

		str = str.replaceAll("&", "&amp;");
		str = str.replaceAll("#", "&#35;");
		str = str.replaceAll("<", "&lt;");
		str = str.replaceAll(">", "&gt;");
		str = str.replaceAll("\\(", "&#40;");
		str = str.replaceAll("\\)", "&#41;");
		str = str.replaceAll("'", "&#39;");
		str = str.replaceAll("\"", "&quot;");

		return str;
	}

	public String clearXss(String str) {

		if (str == null) {
			return null;
		}

		str = this.clearDefaultXss(str);

		String filstr = "<script>,javascript,%3Cscript,JaVaScRiPt,ScRiPt%20%0a%0d,ja%0Av%0Aa %0As%0Ac%0Aript,script,vbscript,binding,allowscriptaccess,expression,appl et,meta,xml,blink,link,style,embed,object,iframe,frame,frameset,background,layer,ilayer,bgsound,title,base,eval,innerHTML,charset,refresh,string,void,cre ate,append,%3Ealert,alert,msgbox,document,cookie,href,nabort,@import,\\+ADw,\\+AD4,aim:,%0da=eval,xmlns:html,http-equiv=refresh,httpequiv=\"refresh\",xmlns:html=,<htmlxmln,list-style-image,xscriptlet,echo\\(,0%0d%0a%00,mozbinding,res://,#exec,%u0,&#x,fromcharcode,firefoxurl,<br size=,wvsxss,acunetix_wvs,lowsrc,dynsrc,behavior,activexobject,microsoft.xmlhttp,clsi d:cafeefac-dec7-0000-0000-abcdeffedcba,application/npruntimescriptableplugin,deploymenttoolkit,onactivae,onafterprint,onafterupdate,onbefore,on beforeactivate,onbeforecopy,onbeforecut,onbeforedeactivate,onbeforeeditf ocus,onbeforepaste,onbeforeprint,onbeforeunload,onbeforeupdate,onblur, onbounce,oncellchange,onchange,onclick,oncontextmenu,oncontrolselect, oncopy,oncut,ondataavailable,ondatasetchanged,ondatasetcomplete,ondbl click,ondeactivate,ondrag,ondragend,ondragenter,ondragleave,ondragover, ondragstart,ondrop,onerror,onerrorupdate,onfilterchange,onfinish,onfocus, onfocusin,onfocusout,onhelp,onkeydown,onkeypress,onkeyup,onlayoutco mplete,onload,onlosecapture,onmousedown,onmouseenter,onmouseleave,onmousemove,onmouseout,onmouseover,onmouseup,onmousewheel,onm ove,onmoveend,onmovestart,onpaste,onpropertychange,onreadystatechan ge,onreset,onresize,onresizeend,onresizestart,onrowenter,onrowexit,onrows delete,onrowsinserted,onscroll,onselect,onselectionchange,onselectstart,on start,onsto,onsubmit,onunload,\";,onMessage,onRowDelete,;//,onOffline,o nRowInserted,FSCommand,onOnline,onSeek,onAbort,onOutOfSync,onStora ge,onActivate,onPause,onSyncRestored,onBegin,onPopState,onTimeError,onDragDrop,onProgress,onTrackChange,onEnd,onRedo,onUndo,onHashChange,onRepeat,onURLFlip,onInput,onResume,seekSegmentTime,onMediaComplete,onReverse,onRowsEnter,onMediaError,java.lang.Runtime,getRuntime"; // 필터링
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																									// 문자열
		filstr = filstr.replaceAll(" ", "");
		if (!str.equals("")) {
			String[] st = filstr.split(",");
			for (int x = 0; x < st.length; x++) {
				str = str.replaceAll("(?i)" + st[x], "_" + st[x] + "_");
			}
		}

		return str;
	}

}

package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "Corp")
public class Corp implements Serializable {

	private static final long serialVersionUID = 6624199960978829166L;

	private String corpId = "";
	private String corpName = "";
	private String regImgPath = "";
	private String corpNumber = "";
	private String ceo = "";
	private String phone = "";
	private String comment = "";
	private String manager = "";
	private String mangerPhone = "";
	private String certCode = "";

	public String getCorpId() {
		return this.corpId;
	}

	public void setCorpId(final String corpId) {
		this.corpId = corpId;
	}

	public String getCorpName() {
		return this.corpName;
	}

	public void setCorpName(final String corpName) {
		this.corpName = corpName;
	}

	public String getRegImgPath() {
		return this.regImgPath;
	}

	public void setRegImgPath(final String regImgPath) {
		this.regImgPath = regImgPath;
	}

	public String getCorpNumber() {
		return this.corpNumber;
	}

	public void setCorpNumber(final String corpNumber) {
		this.corpNumber = corpNumber;
	}

	public String getCeo() {
		return this.ceo;
	}

	public void setCeo(final String ceo) {
		this.ceo = ceo;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(final String phone) {
		this.phone = phone;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(final String comment) {
		this.comment = comment;
	}

	public String getManager() {
		return this.manager;
	}

	public void setManager(final String manager) {
		this.manager = manager;
	}

	public String getMangerPhone() {
		return this.mangerPhone;
	}

	public void setMangerPhone(final String mangerPhone) {
		this.mangerPhone = mangerPhone;
	}

	public String getCertCode() {
		return this.certCode;
	}

	public void setCertCode(final String certCode) {
		this.certCode = certCode;
	}

}

package com.skmns.ccmp.common.exception;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skmns.ccmp.common.protocol.CommonResultCode;

public class CommonResponseException extends RuntimeException {
	public CommonResponseException(CommonResultCode errorNotAllowedMember) {
		// TODO Auto-generated constructor stub
	}
	public CommonResponseException(IOException e) {
		// TODO Auto-generated constructor stub
	}
	public CommonResponseException(Exception e) {
		// TODO Auto-generated constructor stub
	}
	private static final long serialVersionUID = 1L;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	

}

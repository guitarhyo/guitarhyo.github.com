package com.skmns.ccmp.temp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TempService {
	
	@Autowired
	private TempDAO dao;
	
	public String getTimestamp() {
		return dao.getTimestamp();
	}

}

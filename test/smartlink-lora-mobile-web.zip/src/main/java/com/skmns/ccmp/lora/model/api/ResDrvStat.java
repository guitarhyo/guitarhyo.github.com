package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResDrvStat")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResDrvStat implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4761776059072632426L;

	private Integer carId;
	private String carNum;
	private Float bizDist;
	private Float nobizDist;
	private Float commutDist;
	private Integer drvrId;
	private String drvrNum;
	private String drvrNm;
	
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public Float getBizDist() {
		return bizDist;
	}
	public void setBizDist(Float bizDist) {
		this.bizDist = bizDist;
	}
	public Float getNobizDist() {
		return nobizDist;
	}
	public void setNobizDist(Float nobizDist) {
		this.nobizDist = nobizDist;
	}
	public Float getCommutDist() {
		return commutDist;
	}
	public void setCommutDist(Float commutDist) {
		this.commutDist = commutDist;
	}
	public Integer getDrvrId() {
		return drvrId;
	}
	public void setDrvrId(Integer drvrId) {
		this.drvrId = drvrId;
	}
	public String getDrvrNum() {
		return drvrNum;
	}
	public void setDrvrNum(String drvrNum) {
		this.drvrNum = drvrNum;
	}
	public String getDrvrNm() {
		return drvrNm;
	}
	public void setDrvrNm(String drvrNm) {
		this.drvrNm = drvrNm;
	}
		
}
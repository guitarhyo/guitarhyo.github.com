package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResDiagCode")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResDiagCode implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1716468703654737531L;
	private Integer carId;
	private String carNum;
	private String onDt;
	private String diagCodes;
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getOnDt() {
		return onDt;
	}
	public void setOnDt(String onDt) {
		this.onDt = onDt;
	}
	public String getDiagCodes() {
		return diagCodes;
	}
	public void setDiagCodes(String diagCodes) {
		this.diagCodes = diagCodes;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
package com.skmns.ccmp.lora.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.ibatis.type.Alias;

@Alias(value = "Notice")
public class Notice extends CommonResult implements Serializable {

	private static final long serialVersionUID = -1269515742505559642L;

	private String noticeId = "";
	private String corpId = "";
	private String grpName = "";
	private String corpName = "";
	private String category = "";
	private String imgHomePcPath = "";
	private String imgHomeMobilePath = "";
	private String imgContentPcPath = "";
	private String imgContentMobilePath = "";
	private String subject = "";
	private String notice = "";
	private Date createdt;
	private String updatedt = "";
	private String startdt = "";
	private String enddt = "";
	private String maxCnt = "";
	private String maxPage = "";

	private String device = "";
	private String search = "";
	private String page = "1";
	private String cnt = "10";

	private String popupId = "";
	private String pcImgPath = "";
	private String mobileImgPath = "";
	private String link = "";
	private String comment = "";
	private String isMainOpen = "";

	/**
	 * @return the page
	 */
	public String getPage() {
		return this.page;
	}

	/**
	 * @param page
	 *            the page to set
	 */
	public void setPage(final String page) {
		this.page = page;
	}

	/**
	 * @return the cnt
	 */
	public String getCnt() {
		return this.cnt;
	}

	/**
	 * @param cnt
	 *            the cnt to set
	 */
	public void setCnt(final String cnt) {
		this.cnt = cnt;
	}

	/**
	 * @return the mobileImgPath
	 */
	public String getMobileImgPath() {
		return this.mobileImgPath;
	}

	/**
	 * @param mobileImgPath
	 *            the mobileImgPath to set
	 */
	public void setMobileImgPath(final String mobileImgPath) {
		this.mobileImgPath = mobileImgPath;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return this.link;
	}

	/**
	 * @param link
	 *            the link to set
	 */
	public void setLink(final String link) {
		this.link = link;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return this.comment;
	}

	/**
	 * @param comment
	 *            the comment to set
	 */
	public void setComment(final String comment) {
		this.comment = comment;
	}

	public String getNoticeId() {
		return this.noticeId;
	}

	public void setNoticeId(final String noticeId) {
		this.noticeId = noticeId;
	}

	public String getCorpId() {
		return this.corpId;
	}

	public void setCorpId(final String corpId) {
		this.corpId = corpId;
	}

	public String getGrpName() {
		return this.grpName;
	}

	public void setGrpName(final String grpName) {
		this.grpName = grpName;
	}

	public String getCorpName() {
		return this.corpName;
	}

	public void setCorpName(final String corpName) {
		this.corpName = corpName;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(final String category) {
		this.category = category;
	}

	public String getImgHomePcPath() {
		return this.imgHomePcPath;
	}

	public void setImgHomePcPath(final String imgHomePcPath) {
		this.imgHomePcPath = imgHomePcPath;
	}

	public String getImgHomeMobilePath() {
		return this.imgHomeMobilePath;
	}

	public void setImgHomeMobilePath(final String imgHomeMobilePath) {
		this.imgHomeMobilePath = imgHomeMobilePath;
	}

	public String getImgContentPcPath() {
		return this.imgContentPcPath;
	}

	public void setImgContentPcPath(final String imgContentPcPath) {
		this.imgContentPcPath = imgContentPcPath;
	}

	public String getImgContentMobilePath() {
		return this.imgContentMobilePath;
	}

	public void setImgContentMobilePath(final String imgContentMobilePath) {
		this.imgContentMobilePath = imgContentMobilePath;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(final String subject) {
		this.subject = subject;
	}

	public String getNotice() {
		return this.notice;
	}

	public void setNotice(final String notice) {
		this.notice = notice;
	}

	// @JsonFormat(pattern = "yyyy.MM.dd")
	public Date getCreatedt() {
		return this.createdt;
	}

	public void setCreatedt(final Date createdt) {
		this.createdt = createdt;
	}

	public String getUpdatedt() {
		return this.updatedt;
	}

	public void setUpdatedt(final String updatedt) {
		this.updatedt = updatedt;
	}

	public String getStartdt() {
		return this.startdt;
	}

	public void setStartdt(final String startdt) {
		this.startdt = startdt;
	}

	public String getEnddt() {
		return this.enddt;
	}

	public void setEnddt(final String enddt) {
		this.enddt = enddt;
	}

	public String getMaxCnt() {
		return this.maxCnt;
	}

	public void setMaxCnt(final String maxCnt) {
		this.maxCnt = maxCnt;
	}

	public String getMaxPage() {
		return this.maxPage;
	}

	public void setMaxPage(final String maxPage) {
		this.maxPage = maxPage;
	}

	public String getDevice() {
		return this.device;
	}

	public void setDevice(final String device) {
		this.device = device;
	}

	public String getSearch() {
		return this.search;
	}

	public void setSearch(final String search) {
		this.search = search;
	}

	/**
	 * @return the isMainOpen
	 */
	public String getIsMainOpen() {
		return this.isMainOpen;
	}

	/**
	 * @param isMainOpen
	 *            the isMainOpen to set
	 */
	public void setIsMainOpen(final String isMainOpen) {
		this.isMainOpen = isMainOpen;
	}

	/**
	 * @return the popupId
	 */
	public String getPopupId() {
		return this.popupId;
	}

	/**
	 * @param popupId
	 *            the popupId to set
	 */
	public void setPopupId(final String popupId) {
		this.popupId = popupId;
	}

	/**
	 * @return the pcImgPath
	 */
	public String getPcImgPath() {
		return this.pcImgPath;
	}

	/**
	 * @param pcImgPath
	 *            the pcImgPath to set
	 */
	public void setPcImgPath(final String pcImgPath) {
		this.pcImgPath = pcImgPath;
	}

}

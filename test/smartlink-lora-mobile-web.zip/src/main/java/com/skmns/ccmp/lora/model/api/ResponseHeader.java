package com.skmns.ccmp.lora.model.api;

public class ResponseHeader {

	private String code;
	private String message;

	ResponseHeader() {
		this.code = "0";
		this.message = "success";
	}

	ResponseHeader(final String c, final String m) {
		this.code = c;
		this.message = m;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(final String code) {
		this.code = code;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(final String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseHeader [code=");
		builder.append(code);
		builder.append(", message=");
		builder.append(message);
		builder.append("]");
		return builder.toString();
	}

	
}

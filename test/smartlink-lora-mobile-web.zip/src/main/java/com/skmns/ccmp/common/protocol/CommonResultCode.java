package com.skmns.ccmp.common.protocol;

public enum CommonResultCode {
	SUCCESS_NORMAL("S000", "성공"),

	ERROR_SYSTEM_ERROR("E000", "시스템에러"),

	ERROR_INVALID_REQUEST("E001", "올바르지 않은 요청"),

	ERROR_INVALID_COMMON_PARAMETER("E002", "올바르지 않은 공통 파라미터"),

	ERROR_INVALID_PARAMETER("E003", "올바르지 않은 파라미터"),

	ERROR_NOT_ALLOWED_MEMBER("E004", "허용되지 않은 유저"),

	ERROR_FILE_NOT_FOUND("E005", "파일이 존재하지 않습니다."),

	ERROR_PATH_NOT_FOUND("E006", "경로가 존재하지 않습니다"),

	ERROR_NO_DATA_SUCCESS("E100", "처리건 없음.");

	private String code;
	private String message;

	private CommonResultCode(final String code, final String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return this.code;
	}

	public String getMessage() {
		return this.message;
	}
}

package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResFrstLstDrvDt")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResFrstLstDrvDt implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4761776059072699426L;

	private String frstDrvDt;
	private String lstDrvDt;
	
	
	public String getFrstDrvDt() {
		return frstDrvDt;
	}
	public void setFrstDrvDt(String frstDrvDt) {
		this.frstDrvDt = frstDrvDt;
	}
	public String getLstDrvDt() {
		return lstDrvDt;
	}
	public void setLstDrvDt(String lstDrvDt) {
		this.lstDrvDt = lstDrvDt;
	}
		
}
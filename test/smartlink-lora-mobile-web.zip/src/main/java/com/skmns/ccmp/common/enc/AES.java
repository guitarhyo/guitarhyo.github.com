package com.skmns.ccmp.common.enc;

import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class AES {
	private static final String ALGORITHM = "AES";
	private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
	private static final String KEY = "SkMnS";

	protected AES() {
		throw new UnsupportedOperationException();
	}

	public static String decrypt(final String text) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		byte[] keyBytes = new byte[16];
		byte[] getKeyBytes = KEY.getBytes(StandardCharsets.UTF_8);
		int len = getKeyBytes.length;
		if (len > keyBytes.length) {
			len = keyBytes.length;
		}
		System.arraycopy(getKeyBytes, 0, keyBytes, 0, len);
		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, ALGORITHM);
		IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
		cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);

		byte[] results = cipher.doFinal(Base64.decodeBase64(text));
		return new String(results, StandardCharsets.UTF_8);
	}

	public static String encrypt(final String text) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		byte[] keyBytes = new byte[16];
		byte[] getKeyBytes = KEY.getBytes(StandardCharsets.UTF_8);
		int len = getKeyBytes.length;
		if (len > keyBytes.length) {
			len = keyBytes.length;
		}
		System.arraycopy(getKeyBytes, 0, keyBytes, 0, len);
		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, ALGORITHM);
		IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
		cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

		return Base64.encodeBase64String(cipher.doFinal(text.getBytes(StandardCharsets.UTF_8)));
	}
}

package com.skmns.ccmp.lora.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Member;

@Repository
public class MypageDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = MypageDAO.class.getPackage().getName() + ".";

	public Member usp_api_Member_FindByUserId(final Member member) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_api_Member_FindByUserId", member);
	}

	public CommonResult usp_api_Member_Update(final Member member) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_api_Member_Update", member);
	}

	

	public CommonResult usp_api_Member_Update_UserPass(final Member member) throws CommonResponseException {
		if (member.getUserPass() != null) {
			member.setUserPass(this.changeDefaultXss(member.getUserPass()));
		}
		if (member.getOldUserPass() != null) {
			member.setOldUserPass(this.changeDefaultXss(member.getOldUserPass()));
		}
		return this.sqlSession.selectOne(NS + "usp_api_Member_Update_UserPass", member);
	}

	public CommonResult usp_api_Member_UnRegist(final Member member) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_api_Member_UnRegist", member);
	}

	public String changeDefaultXss(String str) {
		if (str == null) {
			return null;
		}

		str = str.replaceAll("&amp;", "&");
		str = str.replaceAll("&#35;", "#");
		str = str.replaceAll("&lt;", "<");
		str = str.replaceAll("&gt;", ">");
		str = str.replaceAll("&#40;", "\\(");
		str = str.replaceAll("&#41;", "\\)");
		str = str.replaceAll("&#39;", "'");
		str = str.replaceAll("&quot;", "\"");

		return str;
	}
}

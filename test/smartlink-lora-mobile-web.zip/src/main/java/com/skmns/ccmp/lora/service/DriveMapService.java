package com.skmns.ccmp.lora.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.dao.DriveMapDAO;
import com.skmns.ccmp.lora.model.DriveMap;

@Service
public class DriveMapService {

	@Autowired
	private DriveMapDAO driveMapDAO;

	@Autowired
	private SessionManager sessionManager;

	@Autowired
	private HttpServletRequest request;

	public List<DriveMap> selectDriveMapList(final DriveMap param) throws CommonResponseException {
		return this.driveMapDAO.usp_Lora_DriveMap_SearchList(param);
	}
	public List<DriveMap> selectDriveGpsList(final DriveMap param) throws CommonResponseException {
		return this.driveMapDAO.usp_Lora_DriveMap_LogGps_Req(param);
	}
	
	public DriveMap selectAuthKeyCheck(final DriveMap param) throws CommonResponseException {
		return this.driveMapDAO.usp_Lora_DriveMap_AuthKey_Check(param);
	}
	
}

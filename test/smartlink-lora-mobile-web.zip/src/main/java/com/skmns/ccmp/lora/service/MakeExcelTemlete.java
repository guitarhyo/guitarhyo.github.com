package com.skmns.ccmp.lora.service;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.core.io.ClassPathResource;

import net.sf.jxls.exception.ParsePropertyException;
import net.sf.jxls.transformer.XLSTransformer;

public class MakeExcelTemlete {

    public void download(HttpServletRequest request, HttpServletResponse response,
            Map<String, Object> bean, String fileName, String templateFile)
            throws Exception, ParsePropertyException, InvalidFormatException {

    	String fileAndPath = "/excel/"+templateFile;
    	
    	InputStream isA = null;

		try {
		
			isA = new ClassPathResource(fileAndPath).getInputStream();
			
		    //InputStream is = new BufferedInputStream(new FileInputStream(tempPath + "\\" + templateFile));
			InputStream is = new BufferedInputStream(isA);
		    XLSTransformer xls = new XLSTransformer();

		    Workbook workbook = xls.transformXLS(is, bean);

		    response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + ".xlsx\"");
		    
		    OutputStream os = response.getOutputStream();
		    
		    workbook.write(os);
		} catch (IOException e) {
		    e.printStackTrace();
		}
    }
}

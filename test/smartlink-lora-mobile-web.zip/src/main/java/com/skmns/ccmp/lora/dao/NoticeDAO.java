package com.skmns.ccmp.lora.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.Notice;

@Repository
public class NoticeDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = NoticeDAO.class.getPackage().getName() + ".";

	/**
	 * usp_api_Notice_FindByPage
	 *
	 * <pre>
	 * CorpId		int	= 0				-- 고객사아이디
	 * Category	varchar(10)	= ''	-- 카테고리(공지사항/이벤트)
	 * Device	varchar(10)	= ''	-- 촐력매체(전체,PC,모바일)
	 * PageNum	int	= 1				-- 페이지번호 (1부터 시작)
	 * PageRows	int	= 10			-- 한페이지에 출력될 라인수
	 * Search	varchar(20) = ''	-- 검색어(제목,공지내용에서 검색)
	 * </pre>
	 *
	 * @param map
	 * @return
	 * @throws CommonResponseException
	 */
	public List<Notice> usp_api_Notice_FindByPage(final Map<String, Object> map) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_api_Notice_FindByPage", map);
	}

	public List<Notice> usp_api_Popup_FindByDevice(final Notice notice) throws CommonResponseException {
		return this.sqlSession.selectList(NS + "usp_api_Popup_FindByDevice", notice);
	}

}

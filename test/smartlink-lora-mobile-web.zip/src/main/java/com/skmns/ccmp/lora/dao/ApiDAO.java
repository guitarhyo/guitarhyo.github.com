package com.skmns.ccmp.lora.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.api.JigCommand;

@Repository
public class ApiDAO {

	@Autowired
	@Qualifier(value = "sqlSession")
	private SqlSession sqlSession;

	private static final String NS = ApiDAO.class.getPackage().getName() + ".";
	
	public CommonResult usp_Lora_Web_PhoneMacAddr_Update(final Map<String, String> map) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_PhoneMacAddr_Update", map);
	}

	/**
	 * 최근 앱버전 정보 찾기
	 *
	 * @param deviceType
	 * @param serviceType
	 * @return
	 * @throws CommonResponseException
	 */
	public Map<String, String> usp_api_AppVersion_FindByLastVersion(final String deviceType, final String serviceType) throws CommonResponseException {
		Map<String, String> m = new HashMap<>();
		m.put("deviceType", deviceType);
		m.put("serviceType", serviceType);

		return this.sqlSession.selectOne(NS + "usp_api_AppVersion_FindByLastVersion", m);
	}
	
	/**
	 * JIG Util 로깅
	 * 
	 * @param map
	 * @return
	 * @throws CommonResponseException
	 */
	public CommonResult usp_Lora_Web_Jig_LogCmd_Ins(final JigCommand jigCommand) throws CommonResponseException {
		return this.sqlSession.selectOne(NS + "usp_Lora_Web_Jig_LogCmd_Ins", jigCommand);
	}
}

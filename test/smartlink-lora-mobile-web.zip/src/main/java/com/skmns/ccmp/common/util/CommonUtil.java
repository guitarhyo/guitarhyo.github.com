package com.skmns.ccmp.common.util;

import org.apache.commons.codec.Charsets;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.skmns.ccmp.common.constant.ConstantCode4Application;

public class CommonUtil {

	public static String getHttpBody(final String url) {
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);

		// SkmnsMapperUtil.getGsonObject().fromJson(response.getBody(), Map.class);
		return response.getBody();
	}

	/**
	 * 문자열을 바이트 길이로 자르고 추가 문자열을 붙임 - 한글(2 BYTE), 그외(1 BYTE)
	 *
	 * @param str
	 *            문자열
	 * @param len
	 *            바이트 길이
	 * @param appendString
	 *            추가 문자열
	 * @return
	 */
	public static String substringByByte(final String str, final int len, final String appendString) {
		String resultStr = ConstantCode4Application.BLANK;
		if (StringUtils.isNotEmpty(str)) {
			byte[] tmpByte = str.getBytes(Charsets.toCharset(ConstantCode4Application.SUBJECT_ENCODE_CHARSET));
			if (tmpByte.length > len) {
				int subLen = 0; // 자를 문자열 길이
				for (int i = 0; i < len; i++) {
					if (tmpByte[i] < 0) { // 2byte 문자인 경우
						if (i >= len - 1) { // 현재 인덱스가 마지막인 경우
							subLen--;
						}
						i++; // 인덱스를 한번 더 증가
					}
					subLen++;
				}
				resultStr = str.substring(0, subLen).concat(appendString);
			} else {
				resultStr = str;
			}
		}
		return resultStr;
	}

	public static String clearDefaultXss(String str) {
		if (str == null) {
			return null;
		}

		str = str.replaceAll("&amp;", "&");
		str = str.replaceAll("&#35;", "#");
		str = str.replaceAll("&lt;", "<");
		str = str.replaceAll("&gt;", ">");
		str = str.replaceAll("&#40;", "\\(");
		str = str.replaceAll("&#41;", "\\)");
		str = str.replaceAll("&#39;", "'");
		str = str.replaceAll("&quot;", "\"");

		return str;
	}

}

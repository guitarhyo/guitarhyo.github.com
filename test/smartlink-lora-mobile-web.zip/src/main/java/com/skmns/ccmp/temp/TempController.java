package com.skmns.ccmp.temp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Drive;
import com.skmns.ccmp.lora.model.Paging;
import com.skmns.ccmp.lora.service.DriveHistService;

@Controller
@RequestMapping(value="/")
public class TempController {
	
	private static final Logger logger = LoggerFactory.getLogger(TempController.class);
	
	@Autowired
	private DriveHistService drvService;
	
	private static int TEST_MEMBER_ID = 17591;
	private static int TEST_DRV_ID = 1;

	@RequestMapping(value={"testdrv"})
	@ResponseBody 
	public Map<String, Object> testpage() {
		
		
		Map<String, Object> map = new HashMap<>();
		
		logger.info("test page start.");
		
		Drive d = drvService.getDriveInfo(TEST_DRV_ID);
		logger.info("getDriveInfo : {}", d);
		map.put("getDriveInfo", d);
		
		Map<String, Drive> d2 = drvService.getDriveSummary(TEST_MEMBER_ID);
		logger.info("getDriveSummary : {}", d2);
		map.put("getDriveInfo", d2);
		
		d = drvService.getLatestDriveInfo(TEST_MEMBER_ID);
		logger.info("getLatestDriveInfo : {}", d);
		
		Drive criterira = new Drive();
		criterira.setUsgTyp(1);
		criterira.setInsId("dev111");
//		@tmakxm123
		criterira.setDrvId(1);
		
		CommonResult cr = drvService.updateDriveType(criterira);
		logger.info("updateDriveType : {}", cr);
		
		criterira.setDrvrId(TEST_MEMBER_ID);
		criterira.setDrvSts(0);
		criterira.setSearchStartDate("2017-05-08 10:00:00");
		
		Paging paging = new Paging();
		paging.setPageRows(20);
		List<Drive> d4 = drvService.getDriveList(criterira, paging);
		logger.info("getDriveList : {}", d4);
		
		return map;
	}
	
	@RequestMapping(value={"test_stat"})
	public String testStat(Model model) {
		Map<String, Drive> d2 = drvService.getDriveSummary(TEST_MEMBER_ID);
		logger.info("getDriveSummary : {}", d2);
		
		model.addAttribute("summary", d2);
		return "index";
	}
	
}

package com.skmns.ccmp.lora.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.model.MwebCar;
import com.skmns.ccmp.lora.service.MemberService;
import com.skmns.ccmp.lora.service.MwebService;

@Controller
@RequestMapping("/mweb")
public class MwebController {
	private static final Logger logger = LoggerFactory.getLogger(MwebController.class);
	private String jspPath = "/mweb";

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private SessionManager sessionManager;

	@Autowired
	private MemberService memberService;
	
	@Autowired
	private MwebService mwebService;

	@RequestMapping("/login")
	public String login(@RequestParam(required = false) final String searchNoticeId) throws Exception {
		logger.debug("login page start");



		return this.jspPath + "/login";
	}

	@RequestMapping(value = "/doLogin")
	@ResponseBody
	public Member doLogin(final HttpServletRequest request, final Member member, @RequestParam(value = "persist", required = false) final String persist)  throws CommonResponseException{
	
		return this.memberService.doMwebLogin(request, member);
	}
	
	@RequestMapping("/maps")
	public String maps() throws Exception {
		logger.debug("maps page start");

		return this.jspPath + "/maps";
	}
	
	@RequestMapping("/maps/carList")
	@ResponseBody
	public List<MwebCar> carList(MwebCar param) throws Exception {
		Member m = sessionManager.getMwebLoginMember(request);
		
		param.setUserId(m.getUserId());
		List<MwebCar> list = mwebService.selectCarList(param);
		
		return list;
	}

}

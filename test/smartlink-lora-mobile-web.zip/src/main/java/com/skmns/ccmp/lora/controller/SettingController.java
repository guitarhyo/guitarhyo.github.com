package com.skmns.ccmp.lora.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.common.util.SkmnsDebuggingUtil;
import com.skmns.ccmp.lora.service.ApiService;
import com.skmns.ccmp.lora.service.DriveHistService;

@Controller
public class SettingController {
	
	private static final Logger logger = LoggerFactory.getLogger(SettingController.class);
	
	@Autowired
	private ApiService apiService;
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private MessageSourceAccessor msa;

	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private DriveHistService driveHistService;
	/**
	 * 환경설정
	 *
	 * @return
	 */
	@RequestMapping({ "/app/settings", "/app/settings/setting" })
	public String setting() {
		Device device = (Device) this.request.getAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE);
		String newApp = "";
		String os = device.getDevicePlatform().toString();
		String url = "";
		boolean isNewApp = false;

		String currentApp = this.request.getHeader("App-Version");
		if (!StringUtils.isNotBlank(currentApp)) {
			currentApp = "-";
		}

		Map<String, String> appinfo = this.apiService.getAppLastVersion(this.request);
		if (appinfo != null) {
			newApp = String.valueOf(appinfo.get("AppVersion"));
		} else {
			newApp = "-";
		}

		logger.debug("@@@currentApp@" + currentApp + "@@@os@" + os);
		logger.debug("@@@newApp@" + newApp);

		isNewApp = versionCheck(currentApp, newApp);

		if ("ANDROID".equals(os)) {
			url = this.msa.getMessage("con.app.android.update.url");
		} else {
			url = this.msa.getMessage("con.app.ios.update.url");
		}

		logger.info("{}", this.request.getServerName());
		this.request.setAttribute("svrNm", this.request.getServerName());

		this.request.setAttribute("currentApp", currentApp);
		this.request.setAttribute("newApp", newApp);
		this.request.setAttribute("isNewApp", isNewApp);
		this.request.setAttribute("updateUrl", url);
		this.request.setAttribute("toastMsg", SkmnsDebuggingUtil.isStagingServer(this.request) ? "STG" : "");

		return "/app/settings/setting";
	}

	// 버전 체크 (1.0.1 OR 1.20.1)
	public static boolean versionCheck(String strCurrent, String strNew) {
		boolean isNewApp = false;
		// 업데이트버튼 처리 여부 결정
		if (strCurrent != null && !strCurrent.equals(strNew) && !"-".equals(strNew)) {
			try {
				// IOS 최초 버전 1.0.1_1279 때문에 필요
				strCurrent = strCurrent.replaceAll("[^0-9.]", "");
				strNew = strNew.replaceAll("[^0-9.]", "");

				String[] currentArr = strCurrent.split("\\.");
				String[] newArr = strNew.split("\\.");
				int count = strCurrent.length();

				// 갯수가 작은쪽을 기준
				if (strCurrent.length() > strNew.length()) {
					count = strNew.length();
				}

				// DB 수가 높을때 업데이트 노출
				for (int i = 0; i < count; i++) {
					String tempCurrent = currentArr[i];
					String tempNew = newArr[i];
					if (Integer.parseInt(tempNew) > Integer.parseInt(tempCurrent)) {
						isNewApp = true;
						break;
					} else if (Integer.parseInt(tempCurrent) > Integer.parseInt(tempNew)) {
						isNewApp = false;
						break;
					}
				}
			} catch (Exception e) {
				logger.error(e.toString());
				isNewApp = false;
			}
		}
		return isNewApp;
	}
	
	
	/**
	 * 환경설정 > App 설정
	 *
	 * @return
	 */
	@RequestMapping({ "/app/settings/app" })
	public String settingApp() {

		return "/app/settings/app";
	}

	/**
	 * 환경설정 > 연결 차량 정보
	 *
	 * @return
	 */
	@RequestMapping({ "/app/settings/carinfo" })
	public String carinfo() {

		
		return "/app/settings/carinfo";
	}
	
	
}

package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResCarDist")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResCarDist implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5761776059072699426L;

	private Float 	lstDist;
	private String 	distDt;
	
	public Float getLstDist() {
		return lstDist;
	}
	public void setLstDist(Float lstDist) {
		this.lstDist = lstDist;
	}
	public String getDistDt() {
		return distDt;
	}
	public void setDistDt(String distDt) {
		this.distDt = distDt;
	}
			
}
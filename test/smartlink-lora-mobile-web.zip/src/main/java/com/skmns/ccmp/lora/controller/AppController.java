package com.skmns.ccmp.lora.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Drive;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.model.Notice;
import com.skmns.ccmp.lora.service.DriveHistService;
import com.skmns.ccmp.lora.service.MemberService;
import com.skmns.ccmp.lora.service.NoticeService;

@Controller
public class AppController {
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private MessageSourceAccessor msa;

	@Autowired
	private MemberService memberService;
	

	@Autowired
	private NoticeService noticeService;
	
	@Autowired
	private DriveHistService driveHistService;
	
	private static final Logger logger = LoggerFactory.getLogger(AppController.class);

	@RequestMapping({"", "/", "/app"})
	public String mains() {
		return "redirect:/app/main";
	}
	
	/**
	 * 메인
	 *
	 * @return
	 */
	@RequestMapping("/app/main")
	public String mains(final HttpServletRequest request) {
		String memberId = this.sessionManager.getLoginMember(this.request).getMemberId();
		Drive drive = this.driveHistService.getLatestDriveInfo(Integer.parseInt(memberId));
		
		CommonResult commonResult = this.driveHistService.getDriveStatus(Integer.parseInt(memberId));
		this.request.setAttribute("result",  commonResult.getCode());
		this.request.setAttribute("drive",  drive);
		
		return "/app/main/main";
	}
	
	/**
	 * 로그인
	 *
	 * @return
	 */
	@RequestMapping("/app/login")
	public String lgoin(final HttpServletRequest request) {
		logger.info("# appController RequestURL     = {}", request.getRequestURL());
		
		String domain = "";
		try {
			domain = this.msa.getMessage("con.common.domain");
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		String returnUrl = request.getParameter("returnUrl");

		if (this.sessionManager.isLogin(request)) {
			return "redirect:/app/main";
		}
		if (StringUtils.isNotBlank(returnUrl)) {
			if (returnUrl.startsWith("http") || returnUrl.contains(".")) {
				if (!returnUrl.contains(domain)) {
					return "redirect:/app/login";
				}
			}
		}

		String deviceId = request.getHeader("Device-ID");
		request.setAttribute("pushKey", deviceId);

		return "/app/member/login";
	}

	/**
	 * 로그인 처리
	 *
	 * @param reqest
	 * @param member
	 * @return
	 */
	@RequestMapping(value = "/app/doLogin")
	@ResponseBody
	public Member doLogin(final HttpServletRequest request, final Member member, @RequestParam(value = "persist", required = false) final String persist)  throws CommonResponseException{
		//if (StringUtils.isNotBlank(member.getPushKey())) {
			Device device = (Device) request.getAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE);
			logger.debug("isMobile : {}", device.isMobile());
			logger.debug("getDevicePlatform : {}", device.getDevicePlatform());
			String devicePlatform = device.getDevicePlatform().toString();
			if (!"IOS".equals(devicePlatform)) {
				devicePlatform = "Android"; // Push Service에서 대소문자 가림
			}
			member.setPushDevice(devicePlatform);
		//}
		return this.memberService.doLogin(request, member, StringUtils.isNotBlank(persist));
	}

	/**
	 * 자동로그인
	 *
	 * @param request
	 * @param authKey
	 * @return
	 */
	@RequestMapping(value = "/app/autoLogin")
	@ResponseBody
	public Member autoLogin(@RequestParam(value = "authKey", required = false) final String authKey, @RequestParam(value = "pushKey", required = false) final String pushKey)  throws CommonResponseException{
		try {
			logger.debug("@@@authKey@" + authKey);
			logger.debug("@@@pushKey@" + pushKey);
			Member member = this.memberService.doAutoLogin(this.request, authKey, pushKey);
			return member;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 로그아웃
	 *
	 * @param request
	 * @return
	 */
	@RequestMapping("/app/logout")
	@ResponseBody
	public String logout(final HttpServletRequest request) throws CommonResponseException {

		this.memberService.doLogout(request);

		// return "redirect:/app/main";
		return null;
	}
	
	
	/**
	 * 아이디 찾기 발송
	 *
	 * @param member
	 * @return CommonResult
	 */
	@RequestMapping(value = "/app/findId")
	@ResponseBody
	public CommonResult findId(final Member member) throws CommonResponseException {
		return this.memberService.findId(member);

	}

	/**
	 * 비밀번호 초기화 발송
	 *
	 * @param member
	 * @return CommonResult
	 */
	@RequestMapping(value = "/app/initPassword")
	@ResponseBody
	public CommonResult passInit(final Member member)  throws CommonResponseException{
		return this.memberService.passInit(member);

	}

	/**
	 * 핸드폰번호 및 이름 인증번호 발송
	 *
	 * @param member
	 * @return CommonResult
	 */
	@RequestMapping(value = "/app/namePhoneSend")
	@ResponseBody
	public CommonResult namePhoneSend(final Member member)  throws CommonResponseException{
		return this.memberService.namePhoneSend(member);

	}

	/**
	 * 공지사항 팝업
	 *
	 * @param member
	 * @return CommonResult
	 */
	@RequestMapping(value = "/app/mainPop")
	@ResponseBody
	public List<Notice> passInit(final Notice notice)  throws CommonResponseException{
		String corpId = this.sessionManager.getMember(this.request).getCorpId();

		notice.setCorpId(corpId);
		notice.setDevice("MOBILE");
		notice.setCnt("10");
		List<Notice> result = this.noticeService.selectPopNoticeList(notice);
		for (int i = 0; i < result.size(); i++) {
			result.get(i).setSubject(result.get(i).getSubject().replace("\n", "<br/>"));
			result.get(i).setComment(result.get(i).getComment().replace("\n", "<br/>"));
		}

		return result;

	}

	/**
	 * 최초 팝업 닫기 세션 셋팅
	 *
	 */
	@RequestMapping(value = "/app/firstNoti")
	@ResponseBody
	public void setFirstNotiYn()  throws CommonResponseException{
		Member member = this.sessionManager.getMember(this.request);
		member.setFirstNotiYn("Y");
		this.request.setAttribute("member", member);
		this.sessionManager.setMember(this.request, member);
	}
	
	/**
	 * 최초 팝업 닫기 세션 셋팅
	 *
	 */
	@RequestMapping(value = "/app/firstCoach")
	@ResponseBody
	public void setFirstCoachYn() throws CommonResponseException {
		Member member = this.sessionManager.getMember(this.request);
		member.setFirstCoachYn("Y");
		this.request.setAttribute("member", member);
		this.sessionManager.setMember(this.request, member);
	}
	
	
	

	/**
	 * 휴면회원 일반 전환
	 *
	 * @param member
	 * @return CommonResult
	 */
	@RequestMapping(value = "/app/updateHumanLogin")
	@ResponseBody
	public CommonResult updateHumanLogin(final Member member) throws CommonResponseException{

		return this.memberService.updateHumanLogin(member);

	}

	/**
	 * 세션정보 가져오기
	 *
	 * @param member
	 * @return
	 */
	@RequestMapping(value = "/app/getSessionMember")
	@ResponseBody
	public Member getSessionMember(final Member member) throws CommonResponseException {
		logger.debug(this.sessionManager.getMember(this.request).getUserId());
		return this.sessionManager.getMember(this.request);

	}
	
	@RequestMapping(value ="/app/carinfoReload" )
	@ResponseBody
	public Drive carinfoReload(@RequestParam(value = "memberId", required = false,defaultValue ="") final String memberId) throws CommonResponseException {

		Drive drive = this.driveHistService.getLatestDriveInfo(Integer.parseInt(memberId));
		
		CommonResult commonResult = this.driveHistService.getDriveStatus(Integer.parseInt(memberId));
		
		if(drive == null){
			drive = new Drive();
		}
		
		drive.setDrvSts(Integer.parseInt(commonResult.getCode()));

		
		// TODO 테스트용
//		drive.setDrvSts(-2);
		return drive;
	}
	
	@RequestMapping(value ="/app/regIosCarNumber" )
	@ResponseBody
	public CommonResult regIosCarNumber(@RequestParam(value = "carNumber", required = false) final int carNumber
			,@RequestParam(value = "memberId", required = false,defaultValue ="") final String memberId)  throws CommonResponseException{

		CommonResult commonResult = this.driveHistService.regIosCarNumber(carNumber,Integer.parseInt(memberId));
		return commonResult;
	}

	
	
}

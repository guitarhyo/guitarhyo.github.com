package com.skmns.ccmp.lora.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.skmns.ccmp.common.exception.CommonResponseException;
import com.skmns.ccmp.common.session.SessionManager;
import com.skmns.ccmp.lora.model.CommonResult;
import com.skmns.ccmp.lora.model.Member;
import com.skmns.ccmp.lora.service.MypageService;

@Controller
@RequestMapping("/app/mypage")
public class MypageController {

	private static final Logger logger = LoggerFactory.getLogger(MypageController.class);
	private String jspPath = "/app/mypage";
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private MypageService mypageService;
	/*
	 * TODO
	 * 
	 * - 로그아웃
	 * - 회원탈퇴
	 * - 비번, 회원정보, ... 변경
	 */
	
	/**
	 * <PRE> 설명 : 마이페이지 정보 수정 페이지 이동.
	 *
	 * <PRE>
	 *
	 * @param member
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/info")
	public ModelAndView mypageInfo(final Member member) throws Exception {
		logger.debug("info page start");

		ModelMap map = this.mypageService.mypageInfo(member);

		// null일경우 세션 삭제 및 메인 이동
		if (map.get("resultMember") == null) {
			this.sessionManager.removeSession(this.request);
			return new ModelAndView("redirect:/app/main");
		}

		return new ModelAndView(this.jspPath + "/info", map);
	}
	
	/**
	 * <PRE> 설명 : 마이페이지 정보 수정.
	 *
	 * <PRE>
	 *
	 * @param member
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/info/updateMember")
	@ResponseBody
	public CommonResult infoUpdateMember(final Member member) throws CommonResponseException {

		CommonResult result = this.mypageService.infoUpdateMember(member);
		logger.debug("data : {}", result);

		return result;
	}

	
	/**
	 * <PRE> 설명 : 정보수정 비밀번호 수정.
	 *
	 * <PRE>
	 *
	 * @param member
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/info/updatePass")
	@ResponseBody
	public CommonResult updatePass(final Member member) throws CommonResponseException {

		CommonResult result = this.mypageService.updatePass(member);
		logger.debug("data : {}", result);

		return result;
	}

	/**
	 * <PRE> 설명 : 정보수정 회원 탈퇴.
	 *
	 * <PRE>
	 *
	 * @param member
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/info/outMember")
	@ResponseBody
	public CommonResult outMember(final Member member) throws CommonResponseException {

		CommonResult result = this.mypageService.usp_api_Member_UnRegist(member);

		if ("0".equals(result.getCode())) {
			this.sessionManager.removeSession(this.request);
		}

		logger.debug("data : {}", result);

		return result;
	}
}

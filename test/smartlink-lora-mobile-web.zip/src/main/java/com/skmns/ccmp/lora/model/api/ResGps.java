package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResGps")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResGps implements Serializable {


	private static final long serialVersionUID = 2767175696328118476L;
	
	/** gps 등록 시간*/
	private String gpsDt;
	/** 위도 */
	private Float lat;
	/** 경도 */
	private Float lon;
	/** 속도 */
	private Integer speed;
	/** 주행 중 누적거리 */
	private Float runDist;
	public String getGpsDt() {
		return gpsDt;
	}
	public void setGpsDt(String gpsDt) {
		this.gpsDt = gpsDt;
	}

	public Float getLat() {
		return lat;
	}
	public void setLat(Float lat) {
		this.lat = lat;
	}
	public Float getLon() {
		return lon;
	}
	public void setLon(Float lon) {
		this.lon = lon;
	}
	
	public Integer getSpeed() {
		return speed;
	}
	public void setSpeed(Integer speed) {
		this.speed = speed;
	}
	public Float getRunDist() {
		return runDist;
	}
	public void setRunDist(Float runDist) {
		this.runDist = runDist;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Gps [gpsDt=");
		builder.append(gpsDt);
		builder.append(", lat=");
		builder.append(lat);
		builder.append(", lon=");
		builder.append(lon);
		builder.append(", speed=");
		builder.append(speed);
		builder.append(", runDist=");
		builder.append(runDist);
		builder.append("]");
		return builder.toString();
	}
	
	
}
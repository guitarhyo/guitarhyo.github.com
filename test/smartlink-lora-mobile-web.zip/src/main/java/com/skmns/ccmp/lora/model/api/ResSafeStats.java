package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResSafeStats")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResSafeStats implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4761776059072632426L;

	private String name;
	private String sabun;
	private Integer safeIdx;
	private Integer fstAccCnt;
	private Integer fstDecCnt;
	private Integer avgOverSpdRate;
	private Integer avgSafeIdx;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSabun() {
		return sabun;
	}
	public void setSabun(String sabun) {
		this.sabun = sabun;
	}
	public Integer getSafeIdx() {
		return safeIdx;
	}
	public void setSafeIdx(Integer safeIdx) {
		this.safeIdx = safeIdx;
	}
	public Integer getFstAccCnt() {
		return fstAccCnt;
	}
	public void setFstAccCnt(Integer fstAccCnt) {
		this.fstAccCnt = fstAccCnt;
	}
	public Integer getFstDecCnt() {
		return fstDecCnt;
	}
	public void setFstDecCnt(Integer fstDecCnt) {
		this.fstDecCnt = fstDecCnt;
	}
	public Integer getAvgOverSpdRate() {
		return avgOverSpdRate;
	}
	public void setAvgOverSpdRate(Integer avgOverSpdRate) {
		this.avgOverSpdRate = avgOverSpdRate;
	}
	public Integer getAvgSafeIdx() {
		return avgSafeIdx;
	}
	public void setAvgSafeIdx(Integer avgSafeIdx) {
		this.avgSafeIdx = avgSafeIdx;
	}
		
}
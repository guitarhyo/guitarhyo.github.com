package com.skmns.ccmp.lora.model.api;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Alias(value = "ResDrvHst")
@JsonInclude(Include.NON_NULL) //각 항목중 null 일경우 json 리턴 할때 안보냄
public class ResDrvHst implements Serializable {

	/**
	 * 한국 전자금융 운행이력조회 res
	 */
	private static final long serialVersionUID = 1667021089513051341L;
	
	private Integer drvId; // 주행 ID
	private Integer carId;
	private String carNum; //차 번호
	private String drvSts;
	private String drvTyp;  // 운행 용도 (1: 업무용, 2: 출퇴근용, 3: 개인용)
	
	private String onDt; // 시동 ON 일시
	private Float onDist; 			// 운행 시작시 계기판 주행거리
	private String offDt; // 시동 OFF 일시
	private Float offDist; 			// 운행 종료시 계기판 주행거리
	private Float	fuelMlg;			//연비

	
	//안전운전
	private Integer safDrvIdx;    		// 안전 지수 	
	private Integer fstAccelIdx;	 	// 급가속 지수 
	private  Integer fstDecelIdx;		// 급감속 지수 
	private  Integer fstAccelCnt;	 	// 급가속 횟수 
	private  Integer fstDecelCnt; 		// 급감속 횟수
	private  Integer overSpdIdx;	 	// 과속 지수 
	private  Integer overSpdTm;	 	// 과속 시간 
	private  Integer fstAccelTm;	 	// 급가속 시간 
	private  Integer fstDecelTm; 		// 급감속 시간

	//OBD
	private Float fuelAmt; 			//주유잔량
	private Float fuelUseAmt; 	//연료분사량
	private Integer oncnt;				//시동횟수
	private Integer movTm;					//운행시간
	private Integer idleTm;					//공회전시간
	
	public Integer getDrvId() {
		return drvId;
	}


	public void setDrvId(Integer drvId) {
		this.drvId = drvId;
	}


	public Integer getCarId() {
		return carId;
	}


	public void setCarId(Integer carId) {
		this.carId = carId;
	}


	public String getCarNum() {
		return carNum;
	}


	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}


	public String getDrvSts() {
		return drvSts;
	}


	public void setDrvSts(String drvSts) {
		this.drvSts = drvSts;
	}


	public String getDrvTyp() {
		return drvTyp;
	}


	public void setDrvTyp(String drvTyp) {
		this.drvTyp = drvTyp;
	}


	public String getOnDt() {
		return onDt;
	}


	public void setOnDt(String onDt) {
		this.onDt = onDt;
	}


	public Float getOnDist() {
		return onDist;
	}


	public void setOnDist(Float onDist) {
		this.onDist = onDist;
	}


	public String getOffDt() {
		return offDt;
	}


	public void setOffDt(String offDt) {
		this.offDt = offDt;
	}


	public Float getOffDist() {
		return offDist;
	}


	public void setOffDist(Float offDist) {
		this.offDist = offDist;
	}


	public Float getFuelMlg() {
		return fuelMlg;
	}


	public void setFuelMlg(Float fuelMlg) {
		this.fuelMlg = fuelMlg;
	}


	public Integer getSafDrvIdx() {
		return safDrvIdx;
	}


	public void setSafDrvIdx(Integer safDrvIdx) {
		this.safDrvIdx = safDrvIdx;
	}


	public Integer getFstAccelIdx() {
		return fstAccelIdx;
	}


	public void setFstAccelIdx(Integer fstAccelIdx) {
		this.fstAccelIdx = fstAccelIdx;
	}


	public Integer getFstDecelIdx() {
		return fstDecelIdx;
	}


	public void setFstDecelIdx(Integer fstDecelIdx) {
		this.fstDecelIdx = fstDecelIdx;
	}


	public Integer getFstAccelCnt() {
		return fstAccelCnt;
	}


	public void setFstAccelCnt(Integer fstAccelCnt) {
		this.fstAccelCnt = fstAccelCnt;
	}


	public Integer getFstDecelCnt() {
		return fstDecelCnt;
	}


	public void setFstDecelCnt(Integer fstDecelCnt) {
		this.fstDecelCnt = fstDecelCnt;
	}


	public Integer getOverSpdIdx() {
		return overSpdIdx;
	}


	public void setOverSpdIdx(Integer overSpdIdx) {
		this.overSpdIdx = overSpdIdx;
	}


	public Integer getOverSpdTm() {
		return overSpdTm;
	}


	public void setOverSpdTm(Integer overSpdTm) {
		this.overSpdTm = overSpdTm;
	}


	public Integer getFstAccelTm() {
		return fstAccelTm;
	}


	public void setFstAccelTm(Integer fstAccelTm) {
		this.fstAccelTm = fstAccelTm;
	}


	public Integer getFstDecelTm() {
		return fstDecelTm;
	}


	public void setFstDecelTm(Integer fstDecelTm) {
		this.fstDecelTm = fstDecelTm;
	}


	public Float getFuelAmt() {
		return fuelAmt;
	}


	public void setFuelAmt(Float fuelAmt) {
		this.fuelAmt = fuelAmt;
	}


	public Float getFuelUseAmt() {
		return fuelUseAmt;
	}


	public void setFuelUseAmt(Float fuelUseAmt) {
		this.fuelUseAmt = fuelUseAmt;
	}


	public Integer getOncnt() {
		return oncnt;
	}


	public void setOncnt(Integer oncnt) {
		this.oncnt = oncnt;
	}


	public Integer getMovTm() {
		return movTm;
	}


	public void setMovTm(Integer movTm) {
		this.movTm = movTm;
	}


	public Integer getIdleTm() {
		return idleTm;
	}


	public void setIdleTm(Integer idleTm) {
		this.idleTm = idleTm;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResHanKukDrvHst [drvId=");
		builder.append(drvId);
		builder.append(", carId=");
		builder.append(carId);
		builder.append(", carNum=");
		builder.append(carNum);
		builder.append(", drvSts=");
		builder.append(drvSts);
		builder.append(", drvTyp=");
		builder.append(drvTyp);
		builder.append(", onDt=");
		builder.append(onDt);
		builder.append(", onDist=");
		builder.append(onDist);
		builder.append(", offDt=");
		builder.append(offDt);
		builder.append(", offDist=");
		builder.append(offDist);
		builder.append(", safDrvIdx=");
		builder.append(safDrvIdx);
		builder.append(", fstAccelIdx=");
		builder.append(fstAccelIdx);
		builder.append(", fstDecelIdx=");
		builder.append(fstDecelIdx);
		builder.append(", fstAccelCnt=");
		builder.append(fstAccelCnt);
		builder.append(", fstDecelCnt=");
		builder.append(fstDecelCnt);
		builder.append(", overSpdIdx=");
		builder.append(overSpdIdx);
		builder.append(", overSpdTm=");
		builder.append(overSpdTm);
		builder.append(", fstAccelTm=");
		builder.append(fstAccelTm);
		builder.append(", fstDecelTm=");
		builder.append(fstDecelTm);
		builder.append(", fuelAmt=");
		builder.append(fuelAmt);
		builder.append(", fuelUseAmt=");
		builder.append(fuelUseAmt);
		builder.append(", oncnt=");
		builder.append(oncnt);
		builder.append(", movTm=");
		builder.append(movTm);
		builder.append(", idleTm=");
		builder.append(idleTm);
		builder.append("]");
		return builder.toString();
	}
	
	

}

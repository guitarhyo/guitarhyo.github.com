package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "Push")
public class Push implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1869505362875245011L;
	
	private String memberId;
	private String title;
	private String message;
	private String searchStartDate;
	private String searchEndDate;
	private String insDt;
	private String insId;
	private int isNew;
	private String lastCheckDt;
	
	
	/**
	 * @return the lastCheckDt
	 */
	public String getLastCheckDt() {
		return lastCheckDt;
	}
	/**
	 * @param lastCheckDt the lastCheckDt to set
	 */
	public void setLastCheckDt(String lastCheckDt) {
		this.lastCheckDt = lastCheckDt;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSearchStartDate() {
		return searchStartDate;
	}
	public void setSearchStartDate(String searchStartDate) {
		this.searchStartDate = searchStartDate;
	}
	public String getSearchEndDate() {
		return searchEndDate;
	}
	public void setSearchEndDate(String searchEndDate) {
		this.searchEndDate = searchEndDate;
	}
	public int getIsNew() {
		return isNew;
	}
	public void setIsNew(int isNew) {
		this.isNew = isNew;
	}
	public String getInsDt() {
		return insDt;
	}
	public void setInsDt(String insDt) {
		this.insDt = insDt;
	}
	public String getInsId() {
		return insId;
	}
	public void setInsId(String insId) {
		this.insId = insId;
	}
}

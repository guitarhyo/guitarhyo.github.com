package com.skmns.ccmp.lora.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.ibatis.type.Alias;

import com.skmns.ccmp.common.util.SkmnsDateUtil;

@Alias(value = "MaintenanceReport")
public class MaintenanceReport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6222492610294827511L;
	
	// SmartLink
	private String corpId;
	private String mntncostId;
	private String corpName;
	private String userId;
	private String memberName;
	private String imgYn;
	private String paybackSts;
	private int paySts;
	private String insId;
	private String insDt;
	private String item;
	private String itemId = "0";
	private String itemDtlId;
	private double ratio;
	private BigDecimal cost = new BigDecimal(0);
	private String code;
	private String message;
	// 검색
	private String reqType = "M";
	private String reqId;
	private String reqCond;
	private String reqTxt;
	private int pageNo = 1;
	private int pageRows;

	private int maintainId;
	private String rnum;
	private String custId;
	private String custNm;
	private String memberId;
	private String loginId;
	private String loginNm;
	private String carId;
	private String carNo;
	private String carNumber;
	private String carModelNm;
	private String itemCd;
	private String itemNm;
	private String itemDtl;
	private String itemDtlNm;
	private BigDecimal price = new BigDecimal(0);
	private BigDecimal cardPrice = new BigDecimal(0);
	private BigDecimal moneyPrice = new BigDecimal(0);
	private BigDecimal totalPrice = new BigDecimal(0);
	private BigDecimal raceTotalPrice = new BigDecimal(0);
	private BigDecimal maintainTotalPrice = new BigDecimal(0);
	private String payKind;
	private String useDt;
	private int attachFileId;
	private String calculateYn;
	private String memo;
	private String regId;
	private String regDt;
	private String updId;
	private String updDt;
	private String base64Image;
	private String imgNm;
	private String imgPath;
	private String imgJsonStr;
	private String dayKm;
	private BigDecimal unitPrice = new BigDecimal(0);
	private String endDt;
	private int itemCnt;

	// 검색
	private String searchType;
	private String searchString;
	private String searchStartDt;
	private String searchEndDt;

	// 파일
	private String tableNm;
	private String tablePk;
	private String tableSubPk;
	private String serverSavePath;
	private String orignalFileNm;
	private String saveFileNm;
	private long fileSize;
	private String accessUrl;
	private String delFilePath;

	public MaintenanceReport() {
	}

	public MaintenanceReport(final String code, final String message) {
		this.code = code;
		this.message = message;
	}

	
	/**
	 * @return the paySts
	 */
	public int getPaySts() {
		return paySts;
	}

	/**
	 * @param paySts the paySts to set
	 */
	public void setPaySts(int paySts) {
		this.paySts = paySts;
	}

	/**
	 * @return the carNumber
	 */
	public String getCarNumber() {
		return this.carNumber;
	}

	/**
	 * @param carNumber
	 *            the carNumber to set
	 */
	public void setCarNumber(final String carNumber) {
		this.carNumber = carNumber;
	}

	/**
	 * Comment :
	 *
	 * @return the raceTotalPrice
	 */
	public BigDecimal getRaceTotalPrice() {
		return this.raceTotalPrice;
	}

	/**
	 * Comment :
	 *
	 * @param raceTotalPrice
	 *            the raceTotalPrice to set
	 */
	public void setRaceTotalPrice(final BigDecimal raceTotalPrice) {
		this.raceTotalPrice = raceTotalPrice;
	}

	/**
	 * Comment :
	 *
	 * @return the maintainTotalPrice
	 */
	public BigDecimal getMaintainTotalPrice() {
		return this.maintainTotalPrice;
	}

	/**
	 * Comment :
	 *
	 * @param maintainTotalPrice
	 *            the maintainTotalPrice to set
	 */
	public void setMaintainTotalPrice(final BigDecimal maintainTotalPrice) {
		this.maintainTotalPrice = maintainTotalPrice;
	}

	/**
	 * Comment :
	 *
	 * @return the carModelNm
	 */
	public String getCarModelNm() {
		return this.carModelNm;
	}

	/**
	 * Comment :
	 *
	 * @param carModelNm
	 *            the carModelNm to set
	 */
	public void setCarModelNm(final String carModelNm) {
		this.carModelNm = carModelNm;
	}

	/**
	 * Comment :
	 *
	 * @return the cardPrice
	 */
	public BigDecimal getCardPrice() {
		return this.cardPrice;
	}

	/**
	 * Comment :
	 *
	 * @param cardPrice
	 *            the cardPrice to set
	 */
	public void setCardPrice(final BigDecimal cardPrice) {
		this.cardPrice = cardPrice;
	}

	/**
	 * Comment :
	 *
	 * @return the moneyPrice
	 */
	public BigDecimal getMoneyPrice() {
		return this.moneyPrice;
	}

	/**
	 * Comment :
	 *
	 * @param moneyPrice
	 *            the moneyPrice to set
	 */
	public void setMoneyPrice(final BigDecimal moneyPrice) {
		this.moneyPrice = moneyPrice;
	}

	/**
	 * Comment :
	 *
	 * @return the itemCnt
	 */
	public int getItemCnt() {
		return this.itemCnt;
	}

	/**
	 * Comment :
	 *
	 * @param itemCnt
	 *            the itemCnt to set
	 */
	public void setItemCnt(final int itemCnt) {
		this.itemCnt = itemCnt;
	}

	/**
	 * Comment :
	 *
	 * @return the delFilePath
	 */
	public String getDelFilePath() {
		return this.delFilePath;
	}

	/**
	 * Comment :
	 *
	 * @param delFilePath
	 *            the delFilePath to set
	 */
	public void setDelFilePath(final String delFilePath) {
		this.delFilePath = delFilePath;
	}

	/**
	 * Comment :
	 *
	 * @return the dayKm
	 */
	public String getDayKm() {
		return this.dayKm;
	}

	/**
	 * Comment :
	 *
	 * @param dayKm
	 *            the dayKm to set
	 */
	public void setDayKm(final String dayKm) {
		this.dayKm = dayKm;
	}

	/**
	 * Comment :
	 *
	 * @return the unitPrice
	 */
	public BigDecimal getUnitPrice() {
		return this.unitPrice;
	}

	/**
	 * Comment :
	 *
	 * @param unitPrice
	 *            the unitPrice to set
	 */
	public void setUnitPrice(final BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	/**
	 * Comment :
	 *
	 * @return the endDt
	 */
	public String getEndDt() {
		return this.endDt;
	}

	/**
	 * Comment :
	 *
	 * @param endDt
	 *            the endDt to set
	 */
	public void setEndDt(final String endDt) {
		this.endDt = endDt;
	}

	/**
	 * Comment :
	 *
	 * @return the itemDtlNm
	 */
	public String getItemDtlNm() {
		return this.itemDtlNm;
	}

	/**
	 * Comment :
	 *
	 * @param itemDtlNm
	 *            the itemDtlNm to set
	 */
	public void setItemDtlNm(final String itemDtlNm) {
		this.itemDtlNm = itemDtlNm;
	}

	/**
	 * Comment :
	 *
	 * @return the totalPrice
	 */
	public BigDecimal getTotalPrice() {
		return this.totalPrice;
	}

	/**
	 * Comment :
	 *
	 * @param totalPrice
	 *            the totalPrice to set
	 */
	public void setTotalPrice(final BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * Comment :
	 *
	 * @return the imgJsonStr
	 */
	public String getImgJsonStr() {
		return this.imgJsonStr;
	}

	/**
	 * Comment :
	 *
	 * @param imgJsonStr
	 *            the imgJsonStr to set
	 */
	public void setImgJsonStr(final String imgJsonStr) {
		this.imgJsonStr = imgJsonStr;
	}

	/**
	 * Comment :
	 *
	 * @return the tableNm
	 */
	public String getTableNm() {
		return this.tableNm;
	}

	/**
	 * Comment :
	 *
	 * @param tableNm
	 *            the tableNm to set
	 */
	public void setTableNm(final String tableNm) {
		this.tableNm = tableNm;
	}

	/**
	 * Comment :
	 *
	 * @return the tablePk
	 */
	public String getTablePk() {
		return this.tablePk;
	}

	/**
	 * Comment :
	 *
	 * @param tablePk
	 *            the tablePk to set
	 */
	public void setTablePk(final String tablePk) {
		this.tablePk = tablePk;
	}

	/**
	 * Comment :
	 *
	 * @return the tableSubPk
	 */
	public String getTableSubPk() {
		return this.tableSubPk;
	}

	/**
	 * Comment :
	 *
	 * @param tableSubPk
	 *            the tableSubPk to set
	 */
	public void setTableSubPk(final String tableSubPk) {
		this.tableSubPk = tableSubPk;
	}

	/**
	 * Comment :
	 *
	 * @return the serverSavePath
	 */
	public String getServerSavePath() {
		return this.serverSavePath;
	}

	/**
	 * Comment :
	 *
	 * @param serverSavePath
	 *            the serverSavePath to set
	 */
	public void setServerSavePath(final String serverSavePath) {
		this.serverSavePath = serverSavePath;
	}

	/**
	 * Comment :
	 *
	 * @return the orignalFileNm
	 */
	public String getOrignalFileNm() {
		return this.orignalFileNm;
	}

	/**
	 * Comment :
	 *
	 * @param orignalFileNm
	 *            the orignalFileNm to set
	 */
	public void setOrignalFileNm(final String orignalFileNm) {
		this.orignalFileNm = orignalFileNm;
	}

	/**
	 * Comment :
	 *
	 * @return the saveFileNm
	 */
	public String getSaveFileNm() {
		return this.saveFileNm;
	}

	/**
	 * Comment :
	 *
	 * @param saveFileNm
	 *            the saveFileNm to set
	 */
	public void setSaveFileNm(final String saveFileNm) {
		this.saveFileNm = saveFileNm;
	}

	/**
	 * Comment :
	 *
	 * @return the fileSize
	 */
	public long getFileSize() {
		return this.fileSize;
	}

	/**
	 * Comment :
	 *
	 * @param fileSize
	 *            the fileSize to set
	 */
	public void setFileSize(final long fileSize) {
		this.fileSize = fileSize;
	}

	/**
	 * Comment :
	 *
	 * @return the accessUrl
	 */
	public String getAccessUrl() {
		return this.accessUrl;
	}

	/**
	 * Comment :
	 *
	 * @param accessUrl
	 *            the accessUrl to set
	 */
	public void setAccessUrl(final String accessUrl) {
		this.accessUrl = accessUrl;
	}

	/**
	 * Comment :
	 *
	 * @return the imgNm
	 */
	public String getImgNm() {
		return this.imgNm;
	}

	/**
	 * Comment :
	 *
	 * @param imgNm
	 *            the imgNm to set
	 */
	public void setImgNm(final String imgNm) {
		this.imgNm = imgNm;
	}

	/**
	 * Comment :
	 *
	 * @return the imgPath
	 */
	public String getImgPath() {
		return this.imgPath;
	}

	/**
	 * Comment :
	 *
	 * @param imgPath
	 *            the imgPath to set
	 */
	public void setImgPath(final String imgPath) {
		this.imgPath = imgPath;
	}

	/**
	 * Comment :
	 *
	 * @return the base64Image
	 */
	public String getBase64Image() {
		return this.base64Image;
	}

	/**
	 * Comment :
	 *
	 * @param base64Image
	 *            the base64Image to set
	 */
	public void setBase64Image(final String base64Image) {
		this.base64Image = base64Image;
	}

	public int getMaintainId() {
		return this.maintainId;
	}

	public void setMaintainId(final int maintainId) {
		this.maintainId = maintainId;
	}

	public String getCustId() {
		return this.custId;
	}

	public void setCustId(final String custId) {
		this.custId = custId;
	}

	public String getMemberId() {
		return this.memberId;
	}

	public void setMemberId(final String memberId) {
		this.memberId = memberId;
	}

	public String getCarId() {
		return this.carId;
	}

	public void setCarId(final String carId) {
		this.carId = carId;
	}

	public String getItemCd() {
		return this.itemCd;
	}

	public void setItemCd(final String itemCd) {
		this.itemCd = itemCd;
	}

	public String getItemDtl() {
		return this.itemDtl;
	}

	public void setItemDtl(final String itemDtl) {
		this.itemDtl = itemDtl;
	}

	public BigDecimal getPrice() {
		return this.price;
	}

	public void setPrice(final BigDecimal price) {
		this.price = price;
	}

	/**
	 * Comment :
	 *
	 * @return the payKind
	 */
	public String getPayKind() {
		return this.payKind;
	}

	/**
	 * Comment :
	 *
	 * @param payKind
	 *            the payKind to set
	 */
	public void setPayKind(final String payKind) {
		this.payKind = payKind;
	}

	public String getUseDt() {
		return this.useDt;
	}

	public void setUseDt(final String useDt) {
		this.useDt = useDt;
	}

	public int getAttachFileId() {
		return this.attachFileId;
	}

	public void setAttachFileId(final int attachFileId) {
		this.attachFileId = attachFileId;
	}

	public String getCalculateYn() {
		return this.calculateYn;
	}

	public void setCalculateYn(final String calculateYn) {
		this.calculateYn = calculateYn;
	}

	public String getMemo() {
		return this.memo;
	}

	public void setMemo(final String memo) {
		this.memo = memo;
	}

	public String getRegId() {
		return this.regId;
	}

	public void setRegId(final String regId) {
		this.regId = regId;
	}

	public String getRegDt() {
		return this.regDt;
	}

	public void setRegDt(final String regDt) {
		this.regDt = regDt;
	}

	public String getUpdId() {
		return this.updId;
	}

	public void setUpdId(final String updId) {
		this.updId = updId;
	}

	public String getUpdDt() {
		return this.updDt;
	}

	public void setUpdDt(final String updDt) {
		this.updDt = updDt;
	}

	public String getCarNo() {
		return this.carNo;
	}

	public void setCarNo(final String carNo) {
		this.carNo = carNo;
	}

	public String getItemNm() {
		return this.itemNm;
	}

	public void setItemNm(final String itemNm) {
		this.itemNm = itemNm;
	}

	public String getSearchType() {
		return this.searchType;
	}

	public void setSearchType(final String searchType) {
		this.searchType = searchType;
	}

	public String getSearchString() {
		return this.searchString;
	}

	public void setSearchString(final String searchString) {
		this.searchString = searchString;
	}

	public String getSearchStartDt() {
		return this.searchStartDt;
	}

	public void setSearchStartDt(final String searchStartDt) {
		this.searchStartDt = searchStartDt;
	}

	public String getSearchEndDt() {
		return this.searchEndDt;
	}

	public void setSearchEndDt(final String searchEndDt) {
		this.searchEndDt = searchEndDt;
	}

	public String getCustNm() {
		return this.custNm;
	}

	public void setCustNm(final String custNm) {
		this.custNm = custNm;
	}

	public String getRnum() {
		return this.rnum;
	}

	public void setRnum(final String rnum) {
		this.rnum = rnum;
	}

	public String getLoginId() {
		return this.loginId;
	}

	public void setLoginId(final String loginId) {
		this.loginId = loginId;
	}

	public String getLoginNm() {
		return this.loginNm;
	}

	public void setLoginNm(final String loginNm) {
		this.loginNm = loginNm;
	}

	/**
	 * <PRE>
	 * 설명 : .
	 *
	 * <PRE>
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MaintenanceReportVO [maintainId=");
		builder.append(this.maintainId);
		builder.append(", rnum=");
		builder.append(this.rnum);
		builder.append(", custId=");
		builder.append(this.custId);
		builder.append(", custNm=");
		builder.append(this.custNm);
		builder.append(", memberId=");
		builder.append(this.memberId);
		builder.append(", loginId=");
		builder.append(this.loginId);
		builder.append(", loginNm=");
		builder.append(this.loginNm);
		builder.append(", carId=");
		builder.append(this.carId);
		builder.append(", carNo=");
		builder.append(this.carNo);
		builder.append(", itemCd=");
		builder.append(this.itemCd);
		builder.append(", itemNm=");
		builder.append(this.itemNm);
		builder.append(", itemDtl=");
		builder.append(this.itemDtl);
		builder.append(", itemDtlNm=");
		builder.append(this.itemDtlNm);
		builder.append(", price=");
		builder.append(this.price);
		builder.append(", totalPrice=");
		builder.append(this.totalPrice);
		builder.append(", payKind=");
		builder.append(this.payKind);
		builder.append(", useDt=");
		builder.append(this.useDt);
		builder.append(", attachFileId=");
		builder.append(this.attachFileId);
		builder.append(", calculateYn=");
		builder.append(this.calculateYn);
		builder.append(", memo=");
		builder.append(this.memo);
		builder.append(", regId=");
		builder.append(this.regId);
		builder.append(", regDt=");
		builder.append(this.regDt);
		builder.append(", updId=");
		builder.append(this.updId);
		builder.append(", updDt=");
		builder.append(this.updDt);
		builder.append(", base64Image=");
		builder.append(this.base64Image);
		builder.append(", imgNm=");
		builder.append(this.imgNm);
		builder.append(", imgPath=");
		builder.append(this.imgPath);
		builder.append(", imgJsonStr=");
		builder.append(this.imgJsonStr);
		builder.append(", searchType=");
		builder.append(this.searchType);
		builder.append(", searchString=");
		builder.append(this.searchString);
		builder.append(", searchStartDt=");
		builder.append(this.searchStartDt);
		builder.append(", searchEndDt=");
		builder.append(this.searchEndDt);
		builder.append(", tableNm=");
		builder.append(this.tableNm);
		builder.append(", tablePk=");
		builder.append(this.tablePk);
		builder.append(", tableSubPk=");
		builder.append(this.tableSubPk);
		builder.append(", serverSavePath=");
		builder.append(this.serverSavePath);
		builder.append(", orignalFileNm=");
		builder.append(this.orignalFileNm);
		builder.append(", saveFileNm=");
		builder.append(this.saveFileNm);
		builder.append(", fileSize=");
		builder.append(this.fileSize);
		builder.append(", accessUrl=");
		builder.append(this.accessUrl);
		builder.append("]");
		return builder.toString();
	}

	public String getCorpId() {
		return this.corpId;
	}

	public void setCorpId(final String corpId) {
		this.corpId = corpId;
	}

	public String getMntncostId() {
		return this.mntncostId;
	}

	public void setMntncostId(final String mntncostId) {
		this.mntncostId = mntncostId;
	}

	public String getCorpName() {
		return this.corpName;
	}

	public void setCorpName(final String corpName) {
		this.corpName = corpName;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(final String userId) {
		this.userId = userId;
	}

	public String getMemberName() {
		return this.memberName;
	}

	public void setMemberName(final String memberName) {
		this.memberName = memberName;
	}

	public String getImgYn() {
		return this.imgYn;
	}

	public void setImgYn(final String imgYn) {
		this.imgYn = imgYn;
	}

	public String getPaybackSts() {
		return this.paybackSts;
	}

	public void setPaybackSts(final String paybackSts) {
		this.paybackSts = paybackSts;
	}

	public String getInsId() {
		return this.insId;
	}

	public void setInsId(final String insId) {
		this.insId = insId;
	}

	public String getInsDt() {
		return this.insDt;
	}

	public void setInsDt(final String insDt) {
		this.insDt = insDt;
	}

	public String getReqType() {
		return this.reqType;
	}

	public void setReqType(final String reqType) {
		this.reqType = reqType;
	}

	public String getReqId() {
		return this.reqId;
	}

	public void setReqId(final String reqId) {
		this.reqId = reqId;
	}

	public String getReqCond() {
		return this.reqCond;
	}

	public void setReqCond(final String reqCond) {
		this.reqCond = reqCond;
	}

	public String getReqTxt() {
		return this.reqTxt;
	}

	public void setReqTxt(final String reqTxt) {
		this.reqTxt = reqTxt;
	}

	public String getItem() {
		return this.item;
	}

	public void setItem(final String item) {
		this.item = item;
	}

	public double getRatio() {
		return this.ratio;
	}

	public void setRatio(final double ratio) {
		this.ratio = ratio;
	}

	public BigDecimal getCost() {
		return this.cost;
	}

	public void setCost(final BigDecimal cost) {
		this.cost = cost;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(final String code) {
		this.code = code;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(final String message) {
		this.message = message;
	}

	public String getItemId() {
		return this.itemId;
	}

	public void setItemId(final String itemId) {
		this.itemId = itemId;
	}

	public String getItemDtlId() {
		return this.itemDtlId;
	}

	public void setItemDtlId(final String itemDtlId) {
		this.itemDtlId = itemDtlId;
	}

	public int getPageNo() {
		return this.pageNo;
	}

	public void setPageNo(final int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageRows() {
		return this.pageRows;
	}

	public void setPageRows(final int pageRows) {
		this.pageRows = pageRows;
	}

	public void setSearchDate() {
		String useDt = this.getUseDt();
		Calendar cal = Calendar.getInstance();
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
			cal.setTime(sdf.parse(useDt));
		} catch (Exception e) {

		}
		String yyyyMM = SkmnsDateUtil.Date2String(cal.getTime(), "yyyy-MM") + "-";
		this.setSearchStartDt(yyyyMM + "01");
		this.setSearchEndDt(yyyyMM + cal.getActualMaximum(Calendar.DAY_OF_MONTH));
	}
}

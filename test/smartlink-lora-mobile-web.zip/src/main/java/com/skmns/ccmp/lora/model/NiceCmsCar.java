package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "NiceCmsCar")
public class NiceCmsCar implements Serializable {

	/**
	 * 2018.10.24 jgc add
	 */
	private static final long serialVersionUID = -1147603409427607114L;
	
	private int carId = 0;
	private int cashTransportTeamId = 0;
	private int carModelId = 0;
	private String carNumber = "";
	private String transportManager = "";
	private String transportManagerEmpNo = "";
	private String passenger1 = "";
	private String passenger2 = "";
	private String workStartTime = "";
	private String departureAddress = "";
	private String departureLat = "";
	private String departureLon = "";
	private int corpId = 0;
	private String uId = "";
	private int isUse = 1;

	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public int getCashTransportTeamId() {
		return cashTransportTeamId;
	}
	public void setCashTransportTeamId(int cashTransportTeamId) {
		this.cashTransportTeamId = cashTransportTeamId;
	}
	public int getCarModelId() {
		return carModelId;
	}
	public void setCarModelId(int carModelId) {
		this.carModelId = carModelId;
	}
	public String getCarNumber() {
		return carNumber;
	}
	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}
	public String getTransportManager() {
		return transportManager;
	}
	public void setTransportManager(String transportManager) {
		this.transportManager = transportManager;
	}
	public String getTransportManagerEmpNo() {
		return transportManagerEmpNo;
	}
	public void setTransportManagerEmpNo(String transportManagerEmpNo) {
		this.transportManagerEmpNo = transportManagerEmpNo;
	}
	public String getPassenger1() {
		return passenger1;
	}
	public void setPassenger1(String passenger1) {
		this.passenger1 = passenger1;
	}
	public String getPassenger2() {
		return passenger2;
	}
	public void setPassenger2(String passenger2) {
		this.passenger2 = passenger2;
	}
	public String getWorkStartTime() {
		return workStartTime;
	}
	public void setWorkStartTime(String workStartTime) {
		this.workStartTime = workStartTime;
	}
	public String getDepartureAddress() {
		return departureAddress;
	}
	public void setDepartureAddress(String departureAddress) {
		this.departureAddress = departureAddress;
	}
	public String getDepartureLat() {
		return departureLat;
	}
	public void setDepartureLat(String departureLat) {
		this.departureLat = departureLat;
	}
	public String getDepartureLon() {
		return departureLon;
	}
	public void setDepartureLon(String departureLon) {
		this.departureLon = departureLon;
	}
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
	public int getCorpId() {
		return corpId;
	}
	public void setCorpId(int corpId) {
		this.corpId = corpId;
	}
	public int getIsUse() {
		return isUse;
	}
	public void setIsUse(int isUse) {
		this.isUse = isUse;
	}
}

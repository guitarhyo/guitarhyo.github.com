package com.skmns.ccmp.lora.model;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias(value = "DeliveryPlace")
public class DeliveryPlace implements Serializable {

	/**
	 * 2018.10.25 jgc add
	 */
	private static final long serialVersionUID = -1147603409427607114L;
	
	private int deliveryPlaceId = 0;
	private String deliveryPlaceName = "";
	private String deliveryPlaceAddress = "";
	private String deliveryPlaceLat = "";
	private String deliveryPlaceLon = "";
	private String deliveryPlaceDesc = "";
	private String uId = "";
	
	public int getDeliveryPlaceId() {
		return deliveryPlaceId;
	}
	public void setDeliveryPlaceId(int deliveryPlaceId) {
		this.deliveryPlaceId = deliveryPlaceId;
	}
	public String getDeliveryPlaceName() {
		return deliveryPlaceName;
	}
	public void setDeliveryPlaceName(String deliveryPlaceName) {
		this.deliveryPlaceName = deliveryPlaceName;
	}
	public String getDeliveryPlaceAddress() {
		return deliveryPlaceAddress;
	}
	public void setDeliveryPlaceAddress(String deliveryPlaceAddress) {
		this.deliveryPlaceAddress = deliveryPlaceAddress;
	}
	public String getDeliveryPlaceLat() {
		return deliveryPlaceLat;
	}
	public void setDeliveryPlaceLat(String deliveryPlaceLat) {
		this.deliveryPlaceLat = deliveryPlaceLat;
	}
	public String getDeliveryPlaceLon() {
		return deliveryPlaceLon;
	}
	public void setDeliveryPlaceLon(String deliveryPlaceLon) {
		this.deliveryPlaceLon = deliveryPlaceLon;
	}
	public String getDeliveryPlaceDesc() {
		return deliveryPlaceDesc;
	}
	public void setDeliveryPlaceDesc(String deliveryPlaceDesc) {
		this.deliveryPlaceDesc = deliveryPlaceDesc;
	}
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
}

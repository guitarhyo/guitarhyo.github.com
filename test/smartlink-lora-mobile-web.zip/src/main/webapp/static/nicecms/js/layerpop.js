// layer pop system
// 2018-08-30 copyright - namo (seo nam ho) for m.s.p

var $layer = '.layer-pop', // 레이어 팝업 공통 클래스
	onClass = 'now-open', // 레이어 팝업 오픈 시킨 버튼에 지정될 임시 클래스
	$layercnt = '.layer-cnt', // 레이어 팝업 내 컨텐츠 영역 클래스
	$layertop = '.layer-top',
	$layermid = '.layer-mid',
	$closeBtn = '.close-layer';

var nlayer = {
	showBtn : function(e, pageSet, layerSet, topPer){
		var $tg = $('#'+e.attr('data-target')+'');
		e.addClass(onClass);
		showPop($tg, pageSet, layerSet, topPer, e);
	},
	showFunc : function(e, pageSet, layerSet, topPer){
		var $tg = e;
		showPop($tg, pageSet, layerSet, topPer);
	}
}

function showPop(e, pageSet, layerSet, topPer, btn){
	e.css({'display':'block','visibility':'hidden'}) // 팝업 컨텐츠 높이 추출용 설정
		.prepend('<div class="layer-bg"></div>');
	var $cnt = e.find(''+$layercnt+''),
		$top = $cnt.find(''+$layertop+''),
		$mid = $cnt.find(''+$layermid+''),
		wH = $(window).innerHeight(),
		dH = $(document).innerHeight(),
		$close = e.find(''+$closeBtn+'');
	
	var midH; // 레이어팝업 컨텐츠가 window height 보다 클 경우 팝업 내 scroll 추가
	if($top != null) midH = wH - $top.outerHeight() - 20;
	else midH = wH - 20;	
	$mid.css('overflow','hidden auto');
	if(layerSet == 'top') $mid.css('max-height',''+(midH - $cnt.position().top)+'px');
	else $mid.css('max-height',''+midH+'px');
	
	var cntH = $cnt.outerHeight(); 

	if(layerSet == 'top') {
		$cnt.css({'position':'top', 'top':''+topPer+'%', 'margin-top':'0'});
		basePageSet(pageSet);
	} else if(layerSet == 'btn'){
		e.css('position','absolute');
		var btnPos = btn.offset().top +  btn.outerHeight(),
			popH = btnPos + cntH,
			popPos = dH - cntH - 20;
			
		if(popH < dH-20) {
			$cnt.css({'top':''+(btnPos)+'px', 'margin-top':'0'});
		} else {
			$cnt.css({'top':''+(popPos)+'px', 'margin-top':'0'});
		}
		$(window).scrollTop(btn.offset().top);
		basePageSet(null); // 레이어 위치가 btn 일 경우 페이지 높이 설정 무시.
	} else {
		$cnt.css({'top':'50%','margin-top':'-'+ (cntH/2) +'px'});
		basePageSet(pageSet);
	}
	
	e.css('visibility','visible').focus(); // 최종 설정 후 보이기	
	hidePop($close, btn, pageSet);

	//캘린더 제어 
	$('#cal-wrap').removeClass("on");
}

function hidePop(closeBtn, openBtn, pageSet){
	closeBtn.unbind().click(function(){
		var $wrap = $(this).closest($layer);
		$wrap.find('.layer-bg').remove()
		.end().find($layercnt).css({'top':'','margin-top':''})
		.end().find($layermid).css({'max-height':'','overflow':''})
		.end().css({'display':'','visibility':'','position':''});
		if(openBtn != null) {
			openBtn.focus().removeClass(''+onClass+'');
			//$(document).scrollTop(openBtn.offset().top);
		}
		basePageSetOff(pageSet);
		
		
		//캘린더 제어 
		$('#cal-wrap').removeClass("on");

	});
}


// 기본 페이지 설정 함수 - tab 키 요소 제어 및 화면 높이 설정
function basePageSet(set) {
	$('body').find('a, button, input').each(function() { $(this).attr('tabindex','-1'); }); // 화면내 focus 요소 모두 focus 막기
	$(''+$layer+'').find('a, button, input').each(function() { $(this).removeAttr('tabindex'); }); // 레이어 팝업 내 focus 요소만 focus 풀기
	if(set == 'fixed') $('body').css({'position':'fixed','width':'100%'});
	else if (set == 'hidden'){
		var wh = $(window).innerHeight();
		$('body').css({'height':''+wh+'px', 'overflow':'hidden'});
	} else null;
}

function basePageSetOff(set){
	$('body').find('a, button, input').each(function() { $(this).removeAttr('tabindex'); });
	if(set == 'fixed') $('body').css({'position':'','width':''});
	else if (set == 'hidden') $('body').css({'height':'', 'overflow':''});
}
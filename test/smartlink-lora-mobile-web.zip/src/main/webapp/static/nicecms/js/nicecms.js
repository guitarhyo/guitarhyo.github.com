var _user = null;

$(function(){
	$("#userInfo").hide();
	hideLoading();
	
	// 로그아웃 버튼 클릭
	$("#logout").click(function() {
		logout();
	});
	
	getUser();
});

function showLoading() {
	$(".loading-menu").show();
}

function hideLoading() {
	$(".loading-menu").hide();
}

function logout() {
	// ajax
	$.getJSON(
		"/nicecms/logout"
		,function (data) {
			location.href = "login.html";
		} // function
	); // getJSON
} // logout

function getUser() {
	// ajax
	$.getJSON(
		"/nicecms/user"
		,function (data) {
			if ( data.code == 0 ) {
				_user = data;
				
				$("#userName").text(data.memberName);
				$("#userInfo").show();
				
				if ( data.gubun == 1 ) {
					// admin
					$(".adminHide").removeClass("adminHide");
				}
			} else {
				user = null;
				logout();
			}
		} // function
	); // getJSON
} // getUser

function initNavi($navi, $row, fn) {
	$navi.prop("currPage", 1);
	
	$navi.click(function() {
		var txt = $(event.srcElement).text();
		var page = Number($navi.prop("currPage"));
		
		switch ( txt ) {
		case "처음":
			if ( page == 1 ) return;
			
			$navi.prop("currPage", 1);
			break;
		case "이전":
			if ( page == 1 ) return;
			
			$navi.prop("currPage", page - 1);
			break;
		case "다음":
			$navi.prop("currPage", page + 1);
			break;
		case "마지막":
			$navi.prop("currPage", 100000);
			break;
		default:
			if ( txt.length > 3 ) return;
		
			$navi.prop("currPage", txt);
			break;
		}
		
		fn();
	});
	
	$row.on("change", function() {
		fn();
	});
} // initNavi


function navi($table, $row, $count, $navi) {
	var pagePerNavi = 10;
	var rowPerPage = $row.val();
	var currPage = Number($navi.prop("currPage"));
	
	var rowNum = 0;
	
	$table.find("tr:gt(0)").each(function () {
		if( $(this).prop("navi") ) ++rowNum;
	});
	
	var lastPage = (rowNum == 0 ? 1 : Math.floor( (rowNum - 1) / rowPerPage ) + 1);
	
	rowNum = 0;
	
	if ( currPage < 1 ) {
		currPage = 1;
		$navi.prop("currPage", currPage);
	}

	if ( currPage > lastPage ) {
		currPage = lastPage;
		$navi.prop("currPage", currPage);
	}
	
	$table.find("tr:gt(0)").each(function () {
		if ( $(this).prop("fixed") )
			$(this).show();
		else
			$(this).hide();
		
		if( $(this).prop("navi") ) ++rowNum;
		else return;
		
		if ( (currPage - 1) * rowPerPage < rowNum && rowNum <= currPage * rowPerPage ) {
			$(this).show();
		}
	});
	
	if ( $count ) {
		$count.text(rowNum);
	}
	
	var $span = $navi.find("span");
	$span.find("a").remove();
	
	var sPage = 1;
	var fPage = lastPage;
	
	if ( lastPage > pagePerNavi ) {
		var sPage = currPage <= pagePerNavi / 2 ? 1 : currPage - pagePerNavi / 2;
		var fPage = currPage <= pagePerNavi / 2 ? pagePerNavi : currPage + pagePerNavi / 2 - 1;
		
		if ( fPage > lastPage ) {
			sPage -= (fPage - lastPage);
			fPage = lastPage;
		}
	}
	
	for ( var i = sPage ; i <= fPage ; ++i ) {
		$span.append("<a href='javascript:void(0)'>" + i + "</a>");
	}
	
	$span.find("a:eq(" + (currPage - sPage) + ")").addClass("on");
} // navi


function filterSite(centerId, teamId, siteName, $table) {
	$table.find("tr:gt(0)").each( function () {
		$(this).hide();
		
		if ( !$(this).prop("id") || $(this).prop("added") ) return;
		
		if ( (centerId == 0 || $(this).attr("center") == centerId)
				&& (teamId == 0 || $(this).attr("team") == teamId)
				&& (siteName.length == 0 || $(this).children("td:eq(" + $(this).attr("site") + ")").text().indexOf(siteName) != -1) ) {
			$(this).prop("navi", true);
		} else {
			$(this).removeProp("navi");
		}
	});
} // filterSite

function uncheck($chk) {
	$chk.prop('checked',false).next('label').removeClass('on');
}

// min => hh:mm
function min2time(min) {
	var h = Math.floor(min / 60);
	var m = min % 60;
	
	return (h < 10 ? "0" : "") + h + ":" + (m < 10 ? "0" : "") + m;
}

//sec => hh:mm
function sec2time(sec) {
	var h = Math.floor(sec / 3600);
	var m = Math.floor(sec % 3600 / 60);
	
	return (h < 10 ? "0" : "") + h + ":" + (m < 10 ? "0" : "") + m;
}

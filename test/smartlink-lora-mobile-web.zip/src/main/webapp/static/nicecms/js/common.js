//tab-menu 설정
function tabmenu(){
	$('.tab-menu>ul>li>a').click(function(e){
		e.preventDefault();
		var tabCnt = $(this).attr('href');
		$(this).parents('.tab-wrap').find('.tab-cnt').each(function(){$(this).hide();});
		$(this).parents('.tab-wrap').find(''+tabCnt+'').show();
		$(this).parent().siblings('li').removeClass('on');
		$(this).parent().addClass('on');
	});
}

$(document).ready(function(){

	// lnb 설정
	$('.side-wrap').baselnb({
		lnbmenu : '.depth1',
		d1list : ' > li',
		d1btn : ' > a',
		d2 : '.depth2',
		onclass : 'on'
	});

	// tabmenu 적용
	tabmenu();

	//toggle 컨텐츠
	$('.btn-tgl').click(function(){
		$(this).toggleClass('on');
	});

	// 말풍선 요소
	$('.btn-balloon').click(function(){
		var gapT = Number($(this).attr('data-top')),
		gapL = Number($(this).attr('data-left'));
		var btnH = $(this).innerHeight(),
		btnT = $(this).offset().top + btnH + gapT,
		btnL = $(this).offset().left + gapL;

		$(this).next('.cnt-balloon').css({'top':''+btnT+'px','left':''+btnL+'px'}).toggleClass('on');
	});	
	$('.btn-balloon-close').click(function(){
		$(this).parent().toggleClass('on');
	});

	//checkall : 20181213 수정	
	$('.checkAll').on("click",function(){
		var $target = $(this).closest(".tbl-type1");

		if ($(this).next("label").hasClass('on')) {
			$target.find('input:checkbox').prop('checked','checked').next("label").addClass("on").closest("tr").addClass("active");			
		} else {
			$target.find('input:checkbox').prop('checked',false).next("label").removeClass("on").closest("tr").removeClass("active");
		}
	});	

	//input check : 20181213 추가
	$(".tbl-type1 tr td input:checkbox").on("click",function(){
		$(this).each(function(){
			//label active
			if( $(this).next("label").hasClass('on') ) {
				$(this).closest("tr").addClass("active");
			} else {
				$(this).closest("tr").removeClass("active");
			}

			//label length 
			var all = $(this).closest(".tbl-type1").find("tbody input:checkbox").length;

			if ($(this).closest(".tbl-type1").find("tbody input:checkbox + label.on").length == all ) {
				$(this).closest(".tbl-type1").find('.checkAll').prop('checked','checked').next("label").addClass("on").closest("tr").addClass("active");	
			} else if ($(this).closest(".tbl-type1").find("tbody input:checkbox + label.on").length < all ){
				$(this).closest(".tbl-type1").find('.checkAll').prop('checked',false).next("label").removeClass("on").closest("tr").removeClass("active");
			}
		});
	});

	//체크 박스 클릭한 부분 색깔 활성화 - 20181108 수정 
	var $targact = $(".seperate-box table tr td .inp-check label");
	$targact.on("click",function(){
		if (!$(this).hasClass('on')) {
			$(this).closest("tr").addClass("active")
		} else {
			$(this).closest("tr").removeClass("active");
		}	
	});
	//테이블 클릭시 배경 활성화 - 20181108 수정 , 20181116 하이라이트
	$(".table-active tr td").on("click",function(){
		$(this).closest("tr").toggleClass("active").siblings().removeClass("active")
	})
	
});
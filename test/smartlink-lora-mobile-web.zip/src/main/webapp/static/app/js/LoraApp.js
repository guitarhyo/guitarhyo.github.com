/**
 * 
 * LoraApp.js
 * 
 * App 연동 인터페이스
 * 
 * @version 1.0
 * @author sh.yu
 * @since 2016.08.22
 */
;
var LoraApp = {
	protocolType : 'lora://',
	callUrlScheme : function(url, jsonStr) {
		var cmd = this.protocolType + url;
		var param = encodeURIComponent(jsonStr);
		// XXX console 제거
		console.log('callUrlScheme.url : ' + url);
		console.log('callUrlScheme.jsonStr : ' + jsonStr);
		console.log('callUrlScheme.param : ' + param);
		document.location.replace(cmd + "?" + param);
	},
	/**
	 * alert
	 * 
	 * @param title
	 *            {String} Dialog에서 사용될 title
	 * @param message
	 *            {String} Dialog 에서 사용될 message
	 * @param icon
	 *            {String} Dialog에서 사용될 icon
	 * @param callJS
	 *            {String} callback event
	 */
	alert : function(title, message, icon, callJs) {
		var title = title;
		var message = message;
		var icon = icon;
		var buttonScript = new Array();
		var buttonCount = 1;
		var buttonName = [ "확인" ];

		if (title == null) {
			title = "";
		}
		if (message == null) {
			message = "";
		}
		if (icon == null) {
			icon = "";
		}
		if (callJs == null) {
			buttonScript.push("");
		} else {
			buttonScript.push(callJs);
		}

		this.popup(title, message, buttonCount, buttonName, buttonScript, icon);
	},
	/**
	 * confirm
	 * 
	 * @param title
	 *            {String} Dialog에서 사용될 title
	 * @param message
	 *            {String} Dialog 에서 사용될 message
	 * @param icon
	 *            {String} Dialog에서 사용될 icon
	 * @param buttonName1
	 *            {String} Dialog에서 첫번째 버튼 문구(default:취소)
	 * @param buttonScript1
	 *            {String} Dialog에서 첫번째 버튼에 대한 callback event
	 * @param buttonName2
	 *            {String} Dialog에서 두번째 버튼 문구(default:확인)
	 * @param buttonScript2
	 *            {String} Dialog에서 두번째 버튼에 대한 callback event
	 */
	confirm : function(title, message, icon, buttonName1, buttonScript1, buttonName2, buttonScript2) {
		var title = title;
		var message = message;
		var icon = icon;
		var buttonName1 = buttonName1;
		var buttonScript1 = buttonScript1;
		var buttonName2 = buttonName2;
		var buttonScript2 = buttonScript2;
		var buttonCount = 2;
		var buttonName = new Array();
		var buttonScript = new Array();

		if (title == null) {
			title = "";
		}
		if (message == null) {
			message = "";
		}
		if (icon == null) {
			icon = "";
		}
		if (buttonName1 == null) {
			buttonName.push("cancel");
		} else {
			buttonName.push(buttonName1);
		}
		if (buttonName2 == null) {
			buttonName.push("confirm");
		} else {
			buttonName.push(buttonName2);
		}
		if (buttonScript1 == null) {
			buttonScript.push("");
		} else {
			buttonScript.push(buttonScript1);
		}
		if (buttonScript2 == null) {
			buttonScript.push("");
		} else {
			buttonScript.push(buttonScript2);
		}

		this.popup(title, message, buttonCount, buttonName, buttonScript, icon);
	},
	/**
	 * popup
	 * 
	 * @param title
	 *            {String} Dialog에서 사용될 title
	 * @param msg
	 *            {String} Dialog 에서 사용될 message
	 * @param buttonCount
	 *            {String} Dialog에서 버튼 수
	 * @param buttonName
	 *            {String} Dialog에서 버튼 문구 리스트
	 * @param buttonScript
	 *            {String} callback event 리스트
	 * @param icon
	 *            {String} Dialog에서 사용될 icon
	 */
	popup : function(title, message, buttonCount, buttonName, buttonScript, icon) {
		var url = "popup";
		var jsonObj = new Object();

		jsonObj.title = title;
		jsonObj.message = message;
		jsonObj.buttonCount = buttonCount;
		jsonObj.buttonName = buttonName;
		jsonObj.buttonScript = buttonScript;
		jsonObj.icon = icon;

		var jsonStr = JSON.stringify(jsonObj);

		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * 일반 로그인 및 자동 로그인
	 * 
	 * @param jsonStr
	 *            {String} JSON String{autoLogin : {}, loginInfo : {}}
	 */
	login : function(jsonStr) {
		var url = "login";
		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * 로그아웃
	 * 
	 */
	logout : function(logout) {
		var url = "logout";
		this.callUrlScheme(url, "{}");
	},
	/**
	 * 외부링크 오픈
	 * 
	 */
	openBrowser : function(link) {
		var url = "openBrowser";
		var jsonObj = new Object();
		if (link != null && link != "") {
			if (!link.startsWith("http://") && !link.startsWith("https://")) {
				link = "http://" + link;
			}
			jsonObj.url = link;
			var jsonStr = JSON.stringify(jsonObj);
			this.callUrlScheme(url, jsonStr);
		}
	},
	/**
	 * 환경설정 - 앱스토어 이동
	 * 
	 * @param jsonStr
	 *            {String} JSON String
	 */
	goMarket : function(jsonStr) {
		var url = "goMarket";
		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * 환경설정 - APP설정
	 * 
	 * @param jsonStr
	 *            {String} JSON String
	 */
	config : function(jsonStr) {
		var url = "config";
		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * 환경설정 - APP설정 - 연결 차량 정보 페이지 - 새로고침
	 * 
	 */
	carinfo : function() {
		var url = "carinfo";
		this.callUrlScheme(url, '{}');
	},
	/**
	 * 최초 진입 확인
	 * 
	 */
	initApp : function() {
		var url = "initApp";
		this.callUrlScheme(url, '{}');
	},
	/**
	 * 환경설정 - APP설정 - 연결 차량 정보 페이지 - 차량 재연결
	 * 
	 */
	scan : function() {
		var url = "scan";
		this.callUrlScheme(url, '{}');
	},
	/**
	 * camera
	 * 
	 */
	camera : function(jsonStr) {
		var url = "camera";
		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * 
	 * base64Image
	 * 
	 * @param jsonStr
	 *            {String} JSON String
	 */
	base64Image : function(jsonStr) {
		var url = "base64Image";
		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * 차량 블루투스 설정 이동
	 * 
	 */
	connectSetting : function() {
		var url = "connectSetting";
		this.callUrlScheme(url, "{}");
	},
	
	/**
	 * gps
	 * 
	 */
	gps : function() {
		var url = "gps";
		this.callUrlScheme(url, "{}");
	},
	isConnected : false,
	/**
	 * smartkey
	 * 
	 */
	smartkey : function() {
		var url = "smartkey";
		var jsonObj = new Object();
		var jsonStr = JSON.stringify(jsonObj);

		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * controlCar
	 * 
	 * @param cmd
	 *            {String} OPEN, LOCK
	 */
	controlCar : function(cmd) {
		var url = "controlCar";
		var jsonObj = new Object();
		jsonObj.cmd = cmd;
		var jsonStr = JSON.stringify(jsonObj);

		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * reservation
	 * 
	 * @param command
	 *            {String} MAKE, CHANGE, CANCEL
	 * @param reservId
	 *            {String} MAKE일경우 없음
	 * 
	 */
	reservation : function(command, reservId) {
		var url = "reservation";
		var jsonObj = new Object();
		jsonObj.command = command;
		jsonObj.reservId = reservId;
		var jsonStr = JSON.stringify(jsonObj);

		this.callUrlScheme(url, jsonStr);
	},
	/**
	 * toast
	 * 
	 * @param msg
	 *            {String}
	 * 
	 */
	toast : function(msg) {
		var url = "toast";
		var jsonObj = new Object();
		jsonObj.msg = msg;
		var jsonStr = JSON.stringify(jsonObj);

		this.callUrlScheme(url, jsonStr);
	},

	goBack : function() {
		var url = 'goBack';
		this.callUrlScheme(url, '{}');
	},

	devmode : function() {
		var url = 'devmode';
		this.callUrlScheme(url, '{}');
	}

};

/**
 * LoraWeb
 * 
 * 각 페이지에서 필요한 함수를 선언한다.
 */
var LoraWeb = {
	/**
	 * 백키 컨트롤. 전 페이지 공통
	 */
	goBack : function() {

		if (backKeyUrl != '') {
			document.location.replace(backKeyUrl);
		} else {
			if (document.referrer != null && document.referrer != "") {
				location.replace(document.referrer);
			} else {
				if (navigator.userAgent.toLowerCase().indexOf('iphone') > -1) {
					LoraApp.goBack();
				} else {
					window.history.back();
				}
			}
		}

	}
};

// XXX LoraWebView 필요 없을듯
var LoraWebView = {
	appName : 'lora',
	userAgent : navigator.userAgent.toLowerCase(),
	isInApp : false,
	isIOS : false,
	isAndroid : false,

	callback : function(event, data) {
		if (typeof (event) == 'function') {
			event(data);
		} else if (typeof (event) == 'string') {
			this.callbackComplete(event, data);
		}
	},
	callbackComplete : function(event, data) {
		// function to be customized by each page
	},
	updateApp : function() {
		console.log('LoraWebView.updateApp : go market');
		return;
		// TODO check OS
		LoraApp.openBrowser('market url');
	}
};
if (LoraWebView.userAgent.indexOf(LoraWebView.appName.toLowerCase()) > -1) {
	// console.log('LoraWebView.userAgent', LoraWebView.userAgent);
	LoraWebView.isInApp = true;
	if (LoraWebView.userAgent.indexOf('ios') > -1) {
		LoraWebView.isIOS = true;
	} else {
		LoraWebView.isAndroid = true;
	}
}

/**
 * APP 콜백을 위한 Json을 위해 만든 오브젝트 함수
 * 
 */
var LoraObj = {
	obj : null,
	create : function() {
		this.obj = new Object();
	},
	setObj : function(obj) {
		this.obj = obj;
	},
	getObj : function() {
		return this.obj;
	},
	addObj : function(name, value) {
		this.obj['' + name] = value;
	},
	toJsonString : function() {
		var jsonStr = JSON.stringify(this.obj);
		console.log(jsonStr);
		return jsonStr;
	}
};
// EOF

$(function(){
//해당 패이지는 호출하지 않고있음 각 페이지별로 호출하도록 되어있음 2017-06-14
//	 common.slide();
	 common.event();
	 common.calendar();
//	 $(window).on("load resize",common.itemHeight);
	 var curr = new Date().getFullYear(); /* 20160926. 사용하지 않음 */
	 /* 20160926. mobiscroll 관련 사용하지 않는 옵션 제거 후 하나로 합침 */
	 /*
	 var opt = {}
	 opt.date = {preset : 'date'}; // 20160926. 사용하지 않음
	 opt.datetime = { preset : 'datetime', minDate: new Date(2012,3,10,9,22), maxDate: new Date(2014,7,30,15,44), stepMinute: 5  }; // 20160926. 사용하지 않음
 	 opt.time = {preset : 'time', stepMinute: 10  };
	 opt.tree_list = {preset : 'list', labels: ['Region', 'Country', 'City']}; // 20160926. 사용하지 않음
	 opt.image_text = {preset : 'list', labels: ['Cars']}; // 20160926. 사용하지 않음
	 opt.select = {preset : 'select'};  // 20160926. 사용하지 않음
	 if($('.timepicker').length) $('.timepicker').val('00:00 오전').scroller($.extend(opt['time'], { theme:'android-ics light', mode: 'scroller', display: 'bottom', lang:'English' }));
	 */
	 $(".timepicker").mobiscroll().time({
		theme : 'android-ics light',
		stepMinute : 10,
		timeFormat : "A hh:ii",
		timeWheels : "Ahhii",
		mode : 'scroller',
		display : 'bottom',
		lang : 'en-US'
	});

});
var itemNum = 0;
common = {
	photoAdd:function(){  // -  /html/smartkey/photo.html 슬라이드 추가하기
		/* 20160926. 샘플 함수. html에 선언되는것이 바람직함 */
		itemNum++;
		if(itemNum<6){
			var item = '<div class="item"><img src="../../include/img/etc/etc_testimg01.png" /></div>';
			$('.photoSlide').slick('slickAdd', item);
			$('.photoSlide').slick('slickGoTo', itemNum-1);
		}else{
			alert("더이상 올릴수 없습니다.");
		}
	},
	itemHeight:function(){  // -  /html/etc/home.html 슬라이드 영역 채우기
		var h = $(".noticeSlide").height();
		$(".noticeSlide .item, .noticeSlide .nsbox").css("height",h+"px");
	},
	slide:function(){
		$(".photoSlide").slick({    // -  /html/smartkey/photo.html 슬라이드 영역 지정하기
			infinite: false,
			slidesToShow: 2,
			dots: false,
			centerMode: true
		});
		$(".nsbox").slick({  // - /html/etc/home.html 슬라이드 영역 지정하기
			slidesToShow: 1,
			dots: true
		});
		$("body").on("click",".pLeft",function(e){		// - /html/etc/home.html 슬라이드 왼쪽 이동
			$('.nsbox').slick("slickPrev");
		});
		$("body").on("click",".pRight",function(e){		// - /html/etc/home.html 슬라이드 오른쪽 이동
			$('.nsbox').slick("slickNext");
		});
	},
	calendar:function(){  // 공통 달력이벤트
		$(".inpDate").datepicker({
			dateFormat: 'yy-mm-dd',
			prevText: '이전 달',
			nextText: '다음 달',
			monthNames: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
			monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
			dayNames: ['일','월','화','수','목','금','토'],
			dayNamesShort: ['일','월','화','수','목','금','토'],
			dayNamesMin: ['일','월','화','수','목','금','토'],
			showMonthAfterYear: true,
			//changeMonth: true,
			//changeYear: true,
			yearSuffix: '년'
		});
		$('.calendar').MonthPicker({ Button: false });
	},
	event:function(){ /* 20160926. 모든 페이지에 불필요한 이벤트가 너무 많이 할당됨 */

		/* 2017-05-23 수정 */
		if($('.totalMenu').length > 0){
			$('.wrapper').hammer().on('swiperight',function(){
				$(".wrapper").addClass("on");
				$('.totalMenu').stop().animate({"left":"0"},300, 'easeOutQuad');
			});

			$('.wrapper').hammer().on('swipeleft',function(){
				$(".wrapper").removeClass("on");
				$('.totalMenu').stop().animate({"left":"-2000px"},1000, 'easeOutQuad');
			});
		} else {
			null;
		}
		/* // 2017-05-23 수정 */

		$(".aMenu").hammer().on("tap", function(ev){  // 전체메뉴 열기
			$(".wrapper").addClass("on");
			$('.totalMenu').stop().animate({"left":"0"},300, 'easeOutQuad');
		});
		$(".mClose, .totalRight").hammer().on("tap", function(ev){  // 전체메뉴 닫기
			$(".wrapper").removeClass("on");
			$('.totalMenu').stop().animate({"left":"-2000px"},1000, 'easeOutQuad');
		});
		$(".lnb>li>a").hammer().on("tap", function(ev){  // 전체메뉴 안에 서브메뉴있을시 열고닫기 -- 현재 불필요
			ev.stopPropagation();
			var ck = $(this).hasClass("on");
			if(!ck){
				$(this).next("ul").slideDown(300, 'easeOutQuad');
				$(this).addClass("on");
			}else{
				$(this).next("ul").slideUp(300, 'easeOutQuad');
				$(this).removeClass("on");
			}
		});

		$(".timeUp").hammer().on("mousedown", function(ev){ // - 수정으로인해 없어짐  불필요
			var t = $(".scroll").scrollTop() - 10;
			$(this).parents(".timeLayer").eq(0).find(".scroll").scrollTop(t);
		});
		$(".timeDown").hammer().on("mousedown", function(ev){// - 수정으로인해 없어짐  불필요
			var t = $(this).parents(".timeLayer").eq(0).find(".scroll").scrollTop() + 10;
			$(this).parents(".timeLayer").eq(0).find(".scroll").scrollTop(t);
		});
		$(".timeValue").hammer().on("tap", function(ev){// - 수정으로인해 없어짐  불필요
			$(".timeLayer").hide();
			$(this).next(".timeLayer").show();
		});
		$(".timeLayer li").hammer().on("tap", function(ev){// - 수정으로인해 없어짐  불필요
			var v = $(this).text();
			$(this).parents(".timebox").eq(0).find(".timeValue").text(v);
			$(this).parents(".timeLayer").eq(0).hide();
		});

		$(".inpAll").hammer().on("change", function(ev){// - /html/member/join01.html   모두동의 전체 체크하기
			var ck = $(this).prop("checked");
			if(!ck){
				$(".agreeList .inpCk").prop("checked", false);
				$(this).addClass("on");
			}else{
				$(".agreeList .inpCk").prop("checked", true);
				$(this).removeClass("on");
			}
		});
		$(".serviceList dt a").hammer().on("tap", function(ev){// - /html/service/faq.htmll   컨텐츠 토글
			var ck = $(this).hasClass("on");
			if(!ck){
				$(".serviceList dd").slideUp(300, 'easeOutQuad');
				$(".serviceList dt a").removeClass("on");
				$(this).parents("dt").eq(0).next("dd").slideDown(300, 'easeOutQuad');
				$(this).addClass("on");
			}else{
				 $(this).parents("dt").eq(0).next("dd").slideUp(300, 'easeOutQuad');
				$(this).removeClass("on");
			}
		});

		$(".inpDel").hammer().on("tap", function(ev){// - /html/pop/pop_search.html   키워드 삭제
			$("#sKeword").val("");
		});

		$(".joinSelect").hammer().on("click", function(ev){ // - /html/member/join02.html   컨텐츠 토글
			var ck = $(this).hasClass("on");
			if(!ck){
				$("#joinSelectArea").slideDown(300, 'easeOutQuad');
				$(this).addClass("on");
			}else{
				$("#joinSelectArea").slideUp(300, 'easeOutQuad');
				$(this).removeClass("on");
			}
		});

		$(".mainBtn01 a").hammer().on("tap", function(ev){// - 수정으로 인해 없어짐 불필요
			$(".mainBtn01 a").removeClass("on");
			$(this).addClass("on");
		});
		$(".mainBtn02 a").hammer().on("mousedown", function(ev){// - 수정으로 인해 없어짐 불필요
			$(this).removeClass("ani").addClass("on")
		});
		$(".mainBtn02 a").hammer().on("mouseup", function(ev){// - 수정으로 인해 없어짐 불필요
			var ck = $(this).hasClass("play");
			if(ck){
				$(this).removeClass("play on").addClass("stop ani");
			}else{
				$(this).removeClass("stop ani on").addClass("play");
			}
		});
		$(".returnSelect a").hammer().on("tap", function(ev){// - /html/pop/pop_autoReturn.html    버튼토글
			var ck = $(this).hasClass("on");
			if(!ck){
				$(this).addClass("on");
			}else{
				$(this).removeClass("on");
			}
		});
		$(".mannerSelect a").hammer().on("tap", function(ev){// - /html/pop/pop_evaluation.html  라디오 토글
			$(".mannerSelect a").removeClass("on");
			$(this).addClass("on");
		});
		$(".stabs a").hammer().on("tap", function(ev){// - /html/reservation/search_map01.html  탭메뉴
			$(".stabs a").removeClass("on");
			$(this).addClass("on");
		});
//		$("input.inp, textarea").hammer().on("focus", function(ev){ // - 공통 키패드 올라오게
//		/* 20160926. 아이폰에서 오류 발생 */
//			$("html, body").css("height","auto");
//		});
//		$("input.inp, textarea").hammer().on("blur", function(ev){  // - 공통 키패드 올라오게
//		/* 20160926. 아이폰에서 오류 발생 */
//			$("html, body").css("height","100%");
//		});

	}
}

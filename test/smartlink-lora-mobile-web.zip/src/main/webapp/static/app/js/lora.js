$(document).ready(function(){
	var scrollChk = false,
		wT;

	$('.container').scroll(function(){
		wT = $('.container').scrollTop();
			console.log(wT, scrollChk);

		if(scrollChk == false){
			if(wT > 210) {
				scrollChk = true;
				$('.record-now').addClass('fix');
				$('.container').scrollTop(0);
			}
		} 
	});

	var touchMov = false,
		direction;
	
	$('.container').bind('touchstart',function(e){
		var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
		startX = touch.pageX;
		startY = touch.pageY;
		
		direcCount = 0;
	});

	$('.container').bind('touchmove',function(e){
		var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
		endX = touch.pageX;
		endY = touch.pageY;
		
		if(direcCount < 1 ) direcSet();
		
		if(scrollChk == true && wT < 10){
			if(direction == 'down'){
				touchMov = true;
				$('.record-now').removeClass('fix');
				$('.container').scrollTop(210);
				scrollChk = false;
			} else {
				null;
			}
		}
		
	});

	function direcSet(){
		numX = startX - endX;
		numY = startY - endY;
		if(Math.abs(numX) > Math.abs(numY)){
			if(numX > 0) direction = 'left';
			else direction = 'right';
		} else {
			if(numY > 0) direction = 'up';
			else direction = 'down';
		}			
		direcCount ++;
	}
});
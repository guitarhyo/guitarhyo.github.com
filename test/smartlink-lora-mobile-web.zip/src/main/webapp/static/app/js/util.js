/**
 * 
 * util.js
 * 
 */

/**
 * 휴대전화번호 정합성 검증
 * 
 * @param: num
 */
function isUserId(str) {
//	var pattern = /^.*(?=.{8,16})(?=.*[0-9])(?=.*[a-zA-Z]).*$/;
	var pattern = /^[a-zA-Z0-9_-]{8,16}$/;
	return pattern.test(str);
}

/**
 * 휴대전화번호 정합성 검증
 * 
 * @param: num
 */
function isPassword(str) {
	var pattern = /^.*(?=.{10,32})(?=.*[0-9])(?=.*[a-zA-Z]).*$/;
	return pattern.test(str);
}

/**
 * 이메일 정합성 검증
 * 
 * @param: num
 */
function isEmail(str) {
	var pattern = /([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	return pattern.test(str);
}

/**
 * 휴대전화번호 정합성 검증
 * 
 * @param: num
 */
function isMobilePhone(num) {
	var pattern = /^(?:(010-\d{4})|(01[1|6|7|8|9]-\d{3,4}))-(\d{4})$/;
	return pattern.test(num);
}

/**
 * 전화번호 포맷
 * 
 * @param: num
 */
function phoneFormat(num) {
	return num.replace(/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/, "$1-$2-$3");
}

/**
 * 숫자만 입력 체크한다.
 * 
 * @param: e event object
 * @use : onkeydown="onlyNumberCheck(event);"
 */
function onlyNumberCheck(e) {
	var code = e.keyCode;
	var ctrl = (document.all) ? event.ctrlKey : e.modifiers & Event.CONTROL_MASK;

	if (window.event) {
		if (!((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode == 8 || e.keyCode == 9 || e.keyCode == 37 || e.keyCode == 39 || e.keyCode == 46
				|| e.keyCode == 0 || e.keyCode == 13 || e.keyCode == 17 || e.keyCode == 16 || e.keyCode == 35 || e.keyCode == 36 || (ctrl && code == 86))) {
			// alert("숫자만 입력해주세요.");
			event.target.value = event.target.value.replace(/[^0-9]/g, "");
			event.returnValue = false;
		}
	} else {
		if (!((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode == 8 || e.keyCode == 9 || e.keyCode == 37 || e.keyCode == 39 || e.keyCode == 46
				|| e.keyCode == 0 || e.keyCode == 13 || e.keyCode == 17 || e.keyCode == 16 || e.keyCode == 35 || e.keyCode == 36 || (ctrl && code == 86))) {
			// alert("숫자만 입력해주세요.");
			event.target.value = event.target.value.replace(/[^0-9]/g, "");
			e.preventDefault();
		}
	}

}

/**
 * 문자열의 byte값을 반환
 * 
 * @param s
 *            문자열
 * @returns 문자열 byte
 */
function getByteLength(s) {
	var b = 0;
	var i = 0;
	var c = "";
	for (b = i = 0; c = s.charCodeAt(i++); b += c >> 11 ? 3 : c >> 7 ? 2 : 1) {
		;
	}
	return b;
}

/**
 * 최대 byte까지의 문자열을 반환
 * 
 * @param s
 *            문자열
 * @param x
 *            최대 byte
 * @returns 최대 byte까지의 문자열
 */
function getByteData(s, x) {
	var a = 0;
	var b = 0;
	var i = 0;
	var c = "";
	var ret = "";
	for (b = i = 0; c = s.charCodeAt(i++); b += c >> 11 ? 3 : c >> 7 ? 2 : 1) {
		a += c >> 11 ? 3 : c >> 7 ? 2 : 1;
		if (a <= x) {
			ret += s.charAt(i - 1);
		} else {
			break;
		}
	}
	return ret;
}

/**
 * input type=number 일때 maxlength 값 체크하여 자르기
 * 
 * @param this
 */
function maxLengthCheck(object) {
	if (object.value.length > object.maxLength) {
		object.value = object.value.slice(0, object.maxLength);
	}
}

/**
 * 세션데이터 가져오기
 * 
 * @returns member
 */
function getSessionMember() {
	var data;
	$.ajax({
		type : "POST",
		url : "/app/getSessionMember",
		async : false,
		type : "POST",
		data : {},
		success : function(res) {
			data = res;
		},
		error : function(request, status, errorThrown) {
			console.log(request);
		}
	});

	return data;
}

/**
 * 숫자에 1000 단위마다 콤마넣기.
 * 
 * @param expression
 * @return string/false
 */
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * 통합 자바 스크립트 파일.
 */

/**
 * 숫자에 1000 단위마다 콤마넣기.
 * 
 * @param expression
 * @return string/false
 */
function money_format(expression) {
	var numericString;

	if (expression == null) {
		return false;
	}

	numericString = expression;

	if (numericString.length == 0) {
		return "";
	}

	numericString = stripComma(numericString);
	var tempValue = "";

	var iIndex = numericString.indexOf(".");
	if (iIndex == -1) {
		iIndex = numericString.length;
	}

	for (var iIndexComma = iIndex - 3; iIndexComma > 0; iIndexComma = iIndex - 3) {
		tempValue = "";
		tempValue += numericString.substring(0, iIndexComma);
		tempValue += ",";
		tempValue += numericString.substring(iIndexComma);
		numericString = tempValue;
		iIndex = iIndexComma;
	}

	return numericString;
}

/**
 * 숫자에서 콤마 제거.
 * 
 * @param expression
 * @return string/false
 */
function stripComma(expression) {

	var numericString = expression;

	if (numericString == null) {
		return false;
	}
	if (typeof (numericString) != "string") {
		numericString = numericString.toString();
	}
	if (numericString.length == 0) {
		return "";
	}

	numericString = numericString.replace(/,/g, '');

	return numericString;
}

/**
 * 왼쪽채우기
 * 
 * @param str :
 *            String : 문자열
 * @param padLen :
 *            int : 전체 길이
 * @param padStr :
 *            String : 왼쪽에 채울 문자
 * @return String : padLen 길이만큼 padStr 문자로 왼쪽을 채운 str 문자열
 */
function lpad(str, padLen, padStr) {
	str += ""; // toString
	while (str.length < padLen) {
		str = padStr + str;
	}
	return str;
}

/**
 * 이미지 프리로드
 * 
 * @param src :
 *            String : 문자열
 * @return Image
 */
function newImage(src) {
	var tmp = new Image();
	tmp.src = src;
	return tmp;
}

/**
 * 초단위 시간을 시간 분 초 로 변환
 * 
 * @param src :
 *            String : 문자열
 * @return Image
 */
function secondsFormatTime(seconds) {
	  var pad = function(x) { return (x < 10) ? "0"+x : x; }
	  var str = "";
	  var tmp = pad(parseInt(seconds / (60*60)));
	  var hbool = false;
	  if(tmp != "00"){
		  str += tmp + "시간 ";
		  hbool = true;
	  }
	  tmp = pad(parseInt(seconds / 60 % 60));
	  if(tmp != "00" || hbool == true){
		  str += tmp + "분 ";
	  }
	  tmp =  pad(seconds % 60);
	 
		  str += tmp + "초";
	  
	  return  str;
	}


/**
 * 초단위 시간을 00:00 시간분 으로 변환
 * 
 * @param src :
 *            String : 문자열
 * @return Image
 */
function secondsFormatTime2(seconds) {
	  var pad = function(x) { return (x < 10) ? "0"+x : x; }
	  var str = "";
	  var tmp = pad(parseInt(seconds / (60*60)));
	 
	  str += tmp + ": ";
	  tmp = pad(parseInt(seconds / 60 % 60));
	  str += tmp ;
	  
	  
	  return  str;
	}


/**
 * 초단위 시간을 시간 분 로 변환
 * 
 * @param src :
 *            String : 문자열
 * @return Image
 */
function secondsFormatTime3(seconds) {
	  var pad = function(x) { return (x < 10) ? "0"+x : x; }
	  var str = "";
	  var tmp = pad(parseInt(seconds / (60*60)));

	  if(tmp != "00"){
		  str += tmp + "시간 ";
		  hbool = true;
	  }
	  tmp = pad(parseInt(seconds / 60 % 60));
	
	  str += tmp + "분 ";
	  
	
	  
	  return  str;
	}
// EOF

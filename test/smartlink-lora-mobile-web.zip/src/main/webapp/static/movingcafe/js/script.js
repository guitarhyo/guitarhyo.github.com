//메뉴 슬라이드
$(function(){

    // 클릭시 슬라이드
    $('.slide_title span').click(function(){
        $(this).toggleClass('on').parent().next('.slide_cont').slideToggle(200);
    });

    /* 달력 */
    $(".datepicker").datepicker();

    // Q&A 슬라이드
    $('.agree_q').click(function(){
        $(this).parent().toggleClass('on').next('.agree_cont').slideToggle(200);
    });



});
